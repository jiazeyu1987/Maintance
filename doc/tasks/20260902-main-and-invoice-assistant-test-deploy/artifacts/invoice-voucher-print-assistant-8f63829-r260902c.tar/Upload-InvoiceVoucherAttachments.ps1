[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ManifestPath,
    [Parameter(Mandatory = $true)][string]$SummaryJsonPath,
    [Parameter(Mandatory = $true)][string]$BusinessMonth,
    [Parameter(Mandatory = $true)][string]$OrganizationNumber,
    [Parameter(Mandatory = $true)][string]$AccountBookNumber,
    [Parameter(Mandatory = $true)][string]$VoucherGroupNumber,
    [string]$EnvPath = 'D:\fenbeitong\fenbeittong\.env'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-DotEnv {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "ERP connection settings file was not found: $Path"
    }

    $values = @{}
    foreach ($line in [System.IO.File]::ReadAllLines($Path, [System.Text.Encoding]::UTF8)) {
        $trimmed = $line.Trim()
        if ([string]::IsNullOrWhiteSpace($trimmed) -or $trimmed.StartsWith('#')) {
            continue
        }
        $separator = $trimmed.IndexOf('=')
        if ($separator -le 0) {
            continue
        }
        $key = $trimmed.Substring(0, $separator).Trim()
        $value = $trimmed.Substring($separator + 1).Trim()
        $values[$key] = $value
    }
    return $values
}

function Require-Setting {
    param(
        [Parameter(Mandatory = $true)][hashtable]$Settings,
        [Parameter(Mandatory = $true)][string]$Name
    )

    $value = [string]$Settings[$Name]
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "ERP connection setting is missing: $Name"
    }
    return $value
}

function Get-ServiceRoot {
    param([Parameter(Mandatory = $true)][string]$BaseUrl)

    $root = $BaseUrl.TrimEnd('/')
    if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) {
        $root += '/K3Cloud'
    }
    return $root + '/'
}

function Escape-FilterValue {
    param([AllowEmptyString()][string]$Value)
    return ([string]$Value).Replace("'", "''")
}

function Get-ResponseErrorMessage {
    param($Status)

    if ($null -eq $Status) {
        return 'ERP did not return a response status.'
    }
    $messages = @(
        @($Status.Errors) |
            ForEach-Object { [string]($_.Message) } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
    if ($messages.Count -gt 0) {
        return ($messages -join '; ')
    }
    return 'ERP returned a failed response.'
}

function Invoke-KingdeeJson {
    param(
        [Parameter(Mandatory = $true)][string]$Uri,
        [Parameter(Mandatory = $true)][string]$Body,
        [Parameter(Mandatory = $true)][Microsoft.PowerShell.Commands.WebRequestSession]$Session,
        [Parameter(Mandatory = $true)][hashtable]$Headers
    )

    $response = Invoke-WebRequest `
        -UseBasicParsing `
        -Method Post `
        -Uri $Uri `
        -ContentType 'application/json;charset=UTF-8' `
        -Body $Body `
        -WebSession $Session `
        -Headers $Headers `
        -TimeoutSec 90
    if ([string]::IsNullOrWhiteSpace($response.Content)) {
        throw 'ERP returned an empty response.'
    }
    return ($response.Content | ConvertFrom-Json)
}

function Invoke-BillQuery {
    param(
        [Parameter(Mandatory = $true)][string]$ServiceRoot,
        [Parameter(Mandatory = $true)][Microsoft.PowerShell.Commands.WebRequestSession]$Session,
        [Parameter(Mandatory = $true)][hashtable]$Headers,
        [Parameter(Mandatory = $true)][hashtable]$Query
    )

    $body = @{
        data = ($Query | ConvertTo-Json -Depth 10 -Compress)
    } | ConvertTo-Json -Compress
    return Invoke-KingdeeJson `
        -Uri ($ServiceRoot + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.BillQuery.common.kdsvc') `
        -Body $body `
        -Session $Session `
        -Headers $Headers
}

function Write-UploadSummary {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][System.Collections.IEnumerable]$Results,
        [Parameter(Mandatory = $true)][string]$Month,
        [Parameter(Mandatory = $true)][string]$OrgNumber,
        [Parameter(Mandatory = $true)][string]$BookNumber,
        [Parameter(Mandatory = $true)][string]$GroupNumber,
        [Parameter(Mandatory = $true)][int]$VoucherCount
    )

    $resultArray = @($Results)
    $uploadedCount = @($resultArray | Where-Object { $_.Status -eq 'Uploaded' }).Count
    $skippedCount = @($resultArray | Where-Object { $_.Status -eq 'AlreadyExists' }).Count
    $failedCount = @($resultArray | Where-Object { $_.Status -eq 'Failed' }).Count
    $summary = [ordered]@{
        Mode = 'erp-upload'
        AllSuccessful = ($failedCount -eq 0)
        BusinessMonth = $Month
        OrganizationNumber = $OrgNumber
        AccountBookNumber = $BookNumber
        VoucherGroupNumber = $GroupNumber
        QueriedVoucherCount = $VoucherCount
        TotalCount = $resultArray.Count
        UploadedCount = $uploadedCount
        AlreadyExistsCount = $skippedCount
        FailedCount = $failedCount
        CompletedAt = (Get-Date).ToString('s')
        Results = $resultArray
    }
    [System.IO.File]::WriteAllText(
        [System.IO.Path]::GetFullPath($Path),
        ($summary | ConvertTo-Json -Depth 8),
        [System.Text.UTF8Encoding]::new($false)
    )
    return $summary
}

if ($BusinessMonth -notmatch '^(\d{4})-(0[1-9]|1[0-2])$') {
    throw 'BusinessMonth must use yyyy-MM format, for example 2025-12.'
}
if (-not (Test-Path -LiteralPath $ManifestPath -PathType Leaf)) {
    throw "ERP upload manifest was not found: $ManifestPath"
}

$year = [int]$Matches[1]
$period = [int]$Matches[2]
$manifest = Get-Content -LiteralPath $ManifestPath -Encoding UTF8 -Raw | ConvertFrom-Json
$items = @($manifest.Items)
if ($items.Count -eq 0) {
    throw 'The manifest contains no invoices to upload.'
}

$settings = Read-DotEnv -Path $EnvPath
$baseUrl = Require-Setting -Settings $settings -Name 'KINGDEE_BASE_URL'
$acctId = Require-Setting -Settings $settings -Name 'KINGDEE_ACCT_ID'
$username = Require-Setting -Settings $settings -Name 'KINGDEE_USERNAME'
$password = Require-Setting -Settings $settings -Name 'KINGDEE_PASSWORD'
$lcid = [string]$settings['KINGDEE_LCID']
if ([string]::IsNullOrWhiteSpace($lcid)) {
    $lcid = '2052'
}
$authPath = [string]$settings['KINGDEE_AUTH_PATH']
if ([string]::IsNullOrWhiteSpace($authPath)) {
    $authPath = 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc'
}
$switchOrgPath = [string]$settings['KINGDEE_SWITCH_ORG_PATH']
if ([string]::IsNullOrWhiteSpace($switchOrgPath)) {
    $switchOrgPath = 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc'
}
$serviceRoot = Get-ServiceRoot -BaseUrl $baseUrl

$loginResponse = Invoke-WebRequest `
    -UseBasicParsing `
    -Method Post `
    -Uri ($serviceRoot + $authPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{
        acctID = $acctId
        username = $username
        password = $password
        lcid = $lcid
    } `
    -SessionVariable kingdeeSession `
    -TimeoutSec 30
$loginBody = $loginResponse.Content | ConvertFrom-Json
if (-not ($loginBody.LoginResultType -eq 1 -or $loginBody.IsSuccessByAPI -eq $true)) {
    throw 'ERP login failed. Check the Kingdee credentials in the local .env file.'
}

$sessionHeaders = @{}
if ($null -ne $loginBody.Context -and $loginBody.Context.SessionId) {
    $sessionHeaders['SessionId'] = [string]$loginBody.Context.SessionId
}
if ($loginBody.KDSVCSessionId) {
    $sessionHeaders['KDSVCSessionId'] = [string]$loginBody.KDSVCSessionId
}

$switchBody = @{
    data = (@{ OrgNumber = $OrganizationNumber } | ConvertTo-Json -Compress)
}
$switchResponse = Invoke-WebRequest `
    -UseBasicParsing `
    -Method Post `
    -Uri ($serviceRoot + $switchOrgPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body $switchBody `
    -WebSession $kingdeeSession `
    -Headers $sessionHeaders `
    -TimeoutSec 30
$switchStatus = $null
if ($switchResponse.Content -and
    $switchResponse.Headers['Content-Type'] -match 'json|text/plain') {
    try {
        $switchPayload = $switchResponse.Content | ConvertFrom-Json
        $switchStatus = $switchPayload.Result.ResponseStatus
    }
    catch {
        $switchStatus = $null
    }
}
if ($null -ne $switchStatus -and -not $switchStatus.IsSuccess) {
    throw "Failed to switch ERP organization $OrganizationNumber`: $(Get-ResponseErrorMessage -Status $switchStatus)"
}

$safeOrg = Escape-FilterValue $OrganizationNumber
$safeBook = Escape-FilterValue $AccountBookNumber
$safeGroup = Escape-FilterValue $VoucherGroupNumber
$voucherFilter = (
    "FYEAR={0} AND FPERIOD={1} AND FACCBOOKORGID.FNUMBER='{2}' " +
    "AND FACCOUNTBOOKID.FNUMBER='{3}' AND FVOUCHERGROUPID.FNUMBER='{4}'"
) -f $year, $period, $safeOrg, $safeBook, $safeGroup
$voucherQuery = @{
    FormId = 'GL_VOUCHER'
    FieldKeys = 'FVOUCHERID,FBillNo,FVOUCHERGROUPNO,FACCOUNTBOOKID.FNUMBER,FVOUCHERGROUPID.FNUMBER,FYEAR,FPERIOD,FACCBOOKORGID.FNUMBER'
    FilterString = $voucherFilter
    OrderString = 'FVOUCHERGROUPNO ASC'
    TopRowCount = 0
    StartRow = 0
    Limit = 2000
}
$voucherQueryBody = @{
    data = ($voucherQuery | ConvertTo-Json -Depth 8 -Compress)
} | ConvertTo-Json -Compress
$voucherRows = Invoke-KingdeeJson `
    -Uri ($serviceRoot + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.ExecuteBillQuery.common.kdsvc') `
    -Body $voucherQueryBody `
    -Session $kingdeeSession `
    -Headers $sessionHeaders

$voucherError = $null
$firstVoucherRow = @($voucherRows)[0]
if ($null -ne $firstVoucherRow -and
    $firstVoucherRow -isnot [System.Array] -and
    $null -ne $firstVoucherRow.PSObject.Properties['Result']) {
    $voucherError = $firstVoucherRow.Result.ResponseStatus
}
if ($null -ne $voucherError -and -not $voucherError.IsSuccess) {
    throw "Failed to query ERP vouchers: $(Get-ResponseErrorMessage -Status $voucherError)"
}

$voucherMap = @{}
foreach ($row in @($voucherRows)) {
    if ($row -isnot [System.Array] -or $row.Count -lt 3) {
        continue
    }
    $voucherNumber = ([string]$row[2]).Trim()
    if ([string]::IsNullOrWhiteSpace($voucherNumber)) {
        continue
    }
    if (-not $voucherMap.ContainsKey($voucherNumber)) {
        $voucherMap[$voucherNumber] = [System.Collections.Generic.List[object]]::new()
    }
    $voucherMap[$voucherNumber].Add([pscustomobject]@{
        VoucherFid = [string]$row[0]
        BillNumber = [string]$row[1]
        VoucherNumber = $voucherNumber
    })
}

$preflight = [System.Collections.Generic.List[object]]::new()
$attachmentTargets = [System.Collections.Generic.List[object]]::new()
foreach ($item in $items) {
    $invoiceNumber = ([string]$item.InvoiceNumber).Trim()
    $voucherNumber = ([string]$item.VoucherNumber).Trim()
    $filePath = [System.IO.Path]::GetFullPath([string]$item.FilePath)
    $fileName = [System.IO.Path]::GetFileName($filePath)
    $errorMessage = ''
    $voucherTarget = $null

    if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
        $errorMessage = 'The renamed PDF was not found.'
    }
    elseif ([System.IO.Path]::GetExtension($filePath) -ne '.pdf') {
        $errorMessage = 'The source file is not a PDF.'
    }
    elseif (-not $voucherMap.ContainsKey($voucherNumber)) {
        $errorMessage = "Voucher $voucherNumber was not found in the selected ERP account book and period."
    }
    elseif ($voucherMap[$voucherNumber].Count -ne 1) {
        $errorMessage = "Voucher $voucherNumber is not unique in the selected ERP scope."
    }
    else {
        $voucherTarget = $voucherMap[$voucherNumber][0]
    }

    if (-not [string]::IsNullOrWhiteSpace($errorMessage)) {
        $preflight.Add([pscustomobject]@{
            InvoiceNumber = $invoiceNumber
            VoucherNumber = $voucherNumber
            VoucherFid = ''
            FileName = $fileName
            Status = 'Failed'
            Success = $false
            Note = $errorMessage
        })
        continue
    }

    $attachmentTargets.Add([pscustomobject]@{
        InvoiceNumber = $invoiceNumber
        VoucherNumber = $voucherNumber
        VoucherFid = $voucherTarget.VoucherFid
        BillNumber = $voucherTarget.BillNumber
        FilePath = $filePath
        FileName = $fileName
    })
}

$existingAttachments = [System.Collections.Generic.HashSet[string]]::new(
    [System.StringComparer]::OrdinalIgnoreCase
)
$targetFids = @(
    $attachmentTargets |
        ForEach-Object { [string]$_.VoucherFid } |
        Sort-Object -Unique
)
for ($offset = 0; $offset -lt $targetFids.Count; $offset += 50) {
    $lastIndex = [math]::Min($offset + 49, $targetFids.Count - 1)
    $chunk = @($targetFids[$offset..$lastIndex])
    $fidList = ($chunk | ForEach-Object { "'$(Escape-FilterValue $_)'" }) -join ','
    $attachmentQuery = @{
        FormId = 'BOS_Attachment'
        FieldKeys = 'FFileId,FAttachmentName,FInterID,FBillType'
        TopRowCount = 0
        Limit = 2000
        StartRow = 0
        FilterString = "FBillType='GL_VOUCHER' AND FInterID IN ($fidList)"
        OrderString = ''
    }
    $attachmentRows = @(Invoke-BillQuery `
        -ServiceRoot $serviceRoot `
        -Session $kingdeeSession `
        -Headers $sessionHeaders `
        -Query $attachmentQuery)
    foreach ($attachment in $attachmentRows) {
        if ($null -ne $attachment.PSObject.Properties['Result'] -and
            $null -ne $attachment.Result.ResponseStatus) {
            $attachmentStatus = $attachment.Result.ResponseStatus
            if (-not $attachmentStatus.IsSuccess) {
                throw "Failed to query existing ERP attachments: $(Get-ResponseErrorMessage -Status $attachmentStatus)"
            }
            continue
        }
        $existingKey = '{0}|{1}' -f ([string]$attachment.FInterID).Trim(), ([string]$attachment.FAttachmentName).Trim()
        [void]$existingAttachments.Add($existingKey)
    }
}

$results = [System.Collections.Generic.List[object]]::new()
foreach ($failed in $preflight) {
    $results.Add($failed)
}

foreach ($target in $attachmentTargets) {
    $existingKey = '{0}|{1}' -f $target.VoucherFid, $target.FileName
    if ($existingAttachments.Contains($existingKey)) {
        $results.Add([pscustomobject]@{
            InvoiceNumber = $target.InvoiceNumber
            VoucherNumber = $target.VoucherNumber
            VoucherFid = $target.VoucherFid
            FileName = $target.FileName
            Status = 'AlreadyExists'
            Success = $true
            Note = 'The same attachment already exists in ERP and was skipped.'
        })
        continue
    }

    $uploadError = ''
    $attachmentId = ''
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            $uploadData = @{
                FileName = $target.FileName
                FormId = 'GL_VOUCHER'
                IsLast = $true
                InterId = $target.VoucherFid
                Entrykey = ''
                EntryinterId = '-1'
                BillNO = $target.BillNumber
                AliasFileName = [System.IO.Path]::GetFileNameWithoutExtension($target.FileName)
                SendByte = [Convert]::ToBase64String(
                    [System.IO.File]::ReadAllBytes($target.FilePath)
                )
            }
            $uploadBody = @{
                data = ($uploadData | ConvertTo-Json -Depth 6 -Compress)
            } | ConvertTo-Json -Compress
            $uploadResponse = Invoke-KingdeeJson `
                -Uri ($serviceRoot + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.AttachmentUpLoad.common.kdsvc') `
                -Body $uploadBody `
                -Session $kingdeeSession `
                -Headers $sessionHeaders
            $uploadStatus = $uploadResponse.Result.ResponseStatus
            if (-not $uploadStatus.IsSuccess) {
                throw (Get-ResponseErrorMessage -Status $uploadStatus)
            }
            $attachmentId = [string]$uploadStatus.SuccessEntitys[0].Id
            $uploadError = ''
            break
        }
        catch {
            $uploadError = $_.Exception.Message
            if ($attempt -lt 3) {
                Start-Sleep -Milliseconds (500 * $attempt)
            }
        }
    }

    if ([string]::IsNullOrWhiteSpace($uploadError)) {
        [void]$existingAttachments.Add($existingKey)
        $results.Add([pscustomobject]@{
            InvoiceNumber = $target.InvoiceNumber
            VoucherNumber = $target.VoucherNumber
            VoucherFid = $target.VoucherFid
            FileName = $target.FileName
            AttachmentId = $attachmentId
            Status = 'Uploaded'
            Success = $true
            Note = 'Saved to the ERP voucher attachments.'
        })
    }
    else {
        $results.Add([pscustomobject]@{
            InvoiceNumber = $target.InvoiceNumber
            VoucherNumber = $target.VoucherNumber
            VoucherFid = $target.VoucherFid
            FileName = $target.FileName
            Status = 'Failed'
            Success = $false
            Note = $uploadError
        })
    }
}

$summary = Write-UploadSummary `
    -Path $SummaryJsonPath `
    -Results $results `
    -Month $BusinessMonth `
    -OrgNumber $OrganizationNumber `
    -BookNumber $AccountBookNumber `
    -GroupNumber $VoucherGroupNumber `
    -VoucherCount @($voucherRows).Count

Write-Output (
    'ERP attachment processing completed: uploaded {0}, already existed {1}, failed {2}.' -f
    $summary.UploadedCount,
    $summary.AlreadyExistsCount,
    $summary.FailedCount
)
