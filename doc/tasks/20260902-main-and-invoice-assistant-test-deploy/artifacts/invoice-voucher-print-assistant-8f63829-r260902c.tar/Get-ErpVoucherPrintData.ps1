[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$BusinessMonth,
    [Parameter(Mandatory = $true)][string]$OrganizationNumber,
    [Parameter(Mandatory = $true)][string]$AccountBookNumber,
    [Parameter(Mandatory = $true)][string]$VoucherGroupNumber,
    [Parameter(Mandatory = $true)][string]$VoucherNumber,
    [Parameter(Mandatory = $true)][string]$OutputJsonPath,
    [Parameter(Mandatory = $true)][string]$EnvPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-DotEnv {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "ERP configuration file does not exist: $Path"
    }
    $settings = @{}
    foreach ($line in Get-Content -LiteralPath $Path -Encoding UTF8) {
        if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') {
            $settings[$Matches[1]] = $Matches[2].Trim()
        }
    }
    return $settings
}

function Require-Setting {
    param([hashtable]$Settings, [string]$Name)
    $value = [string]$Settings[$Name]
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "ERP configuration is missing: $Name"
    }
    return $value
}

function Get-ServiceRoot {
    param([string]$BaseUrl)
    $root = $BaseUrl.TrimEnd('/')
    if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) {
        $root += '/K3Cloud'
    }
    return $root + '/'
}

function Escape-FilterValue {
    param([string]$Value)
    return $Value.Replace("'", "''")
}

function Get-LocalizedText {
    param($Object, [string]$PropertyName = 'Name')
    if ($null -eq $Object) {
        return ''
    }
    $property = $Object.PSObject.Properties[$PropertyName]
    if ($null -eq $property -or $null -eq $property.Value) {
        return ''
    }
    $value = $property.Value
    if ($value -is [string]) {
        return $value.Trim()
    }
    $items = @($value)
    $localized = @(
        $items |
            Where-Object {
                ($_.PSObject.Properties['Key'] -and [string]$_.Key -eq '2052') -or
                ($_.PSObject.Properties['LocaleId'] -and [string]$_.LocaleId -eq '2052')
            }
    ) | Select-Object -First 1
    if ($null -eq $localized) {
        $localized = $items | Select-Object -First 1
    }
    if ($null -eq $localized) {
        return ''
    }
    foreach ($candidate in @('Value', 'Name', 'FullName')) {
        $candidateProperty = $localized.PSObject.Properties[$candidate]
        if ($null -ne $candidateProperty -and
            -not [string]::IsNullOrWhiteSpace([string]$candidateProperty.Value)) {
            return ([string]$candidateProperty.Value).Trim()
        }
    }
    return ''
}

function Get-ObjectPropertyText {
    param($Object, [string]$PropertyName)
    if ($null -eq $Object) {
        return ''
    }
    $property = $Object.PSObject.Properties[$PropertyName]
    if ($null -eq $property -or $null -eq $property.Value) {
        return ''
    }
    return ([string]$property.Value).Trim()
}

function Get-FlexDetailText {
    param($DetailObject)
    if ($null -eq $DetailObject) {
        return ''
    }
    $values = @(
        foreach ($property in $DetailObject.PSObject.Properties) {
            if ($property.Name -in @('Id', 'OPCODE') -or
                $property.Name.EndsWith('_Id') -or
                $null -eq $property.Value) {
                continue
            }
            $number = Get-ObjectPropertyText -Object $property.Value -PropertyName 'Number'
            $name = Get-LocalizedText -Object $property.Value -PropertyName 'Name'
            if (-not [string]::IsNullOrWhiteSpace($number) -and
                -not [string]::IsNullOrWhiteSpace($name)) {
                "$number/$name"
            }
            elseif (-not [string]::IsNullOrWhiteSpace($name)) {
                $name
            }
            elseif (-not [string]::IsNullOrWhiteSpace($number)) {
                $number
            }
        }
    )
    return (@($values | Select-Object -Unique) -join ' / ')
}

function Get-ResponseErrorMessage {
    param($Status)
    $messages = @(
        @($Status.Errors) |
            ForEach-Object { [string]$_.Message } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
    if ($messages.Count -eq 0) {
        return 'Kingdee did not return an error message.'
    }
    return $messages -join '; '
}

if ($BusinessMonth -notmatch '^(\d{4})-(0[1-9]|1[0-2])$') {
    throw 'Business month must use yyyy-MM format.'
}
$year = [int]$Matches[1]
$period = [int]$Matches[2]
if ($VoucherNumber -notmatch '^\d{1,12}$') {
    throw 'Voucher number must contain digits only.'
}

$settings = Read-DotEnv -Path $EnvPath
$baseUrl = Require-Setting -Settings $settings -Name 'KINGDEE_BASE_URL'
$acctId = Require-Setting -Settings $settings -Name 'KINGDEE_ACCT_ID'
$username = Require-Setting -Settings $settings -Name 'KINGDEE_USERNAME'
$password = Require-Setting -Settings $settings -Name 'KINGDEE_PASSWORD'
$lcid = [string]$settings['KINGDEE_LCID']
if ([string]::IsNullOrWhiteSpace($lcid)) {
    $lcid = '2052'
}
$authPath = [string]$settings['KINGDEE_AUTH_PATH']
if ([string]::IsNullOrWhiteSpace($authPath)) {
    $authPath = 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc'
}
$serviceRoot = Get-ServiceRoot -BaseUrl $baseUrl

$loginResponse = Invoke-WebRequest `
    -UseBasicParsing `
    -Method Post `
    -Uri ($serviceRoot + $authPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{
        acctID = $acctId
        username = $username
        password = $password
        lcid = $lcid
    } `
    -SessionVariable kingdeeSession `
    -TimeoutSec 30
$loginBody = $loginResponse.Content | ConvertFrom-Json
if (-not ($loginBody.LoginResultType -eq 1 -or $loginBody.IsSuccessByAPI -eq $true)) {
    throw 'ERP login failed. Check the local ERP account configuration.'
}

$sessionHeaders = @{}
if ($null -ne $loginBody.Context -and $loginBody.Context.SessionId) {
    $sessionHeaders['SessionId'] = [string]$loginBody.Context.SessionId
}
if ($loginBody.KDSVCSessionId) {
    $sessionHeaders['KDSVCSessionId'] = [string]$loginBody.KDSVCSessionId
}

$safeOrg = Escape-FilterValue $OrganizationNumber
$safeBook = Escape-FilterValue $AccountBookNumber
$safeGroup = Escape-FilterValue $VoucherGroupNumber
$voucherFilter = (
    "FYEAR={0} AND FPERIOD={1} AND FACCBOOKORGID.FNUMBER='{2}' " +
    "AND FACCOUNTBOOKID.FNUMBER='{3}' AND FVOUCHERGROUPID.FNUMBER='{4}' " +
    "AND FVOUCHERGROUPNO={5}"
) -f $year, $period, $safeOrg, $safeBook, $safeGroup, ([int]$VoucherNumber)
$queryData = @{
    FormId = 'GL_VOUCHER'
    FieldKeys = 'FVOUCHERID,FBillNo,FVOUCHERGROUPNO,FDATE'
    FilterString = $voucherFilter
    OrderString = ''
    TopRowCount = 0
    StartRow = 0
    Limit = 10
}
$queryBody = @{
    data = ($queryData | ConvertTo-Json -Depth 8 -Compress)
} | ConvertTo-Json -Compress
$queryRows = Invoke-RestMethod `
    -Method Post `
    -Uri ($serviceRoot + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.ExecuteBillQuery.common.kdsvc') `
    -ContentType 'application/json;charset=UTF-8' `
    -Body $queryBody `
    -WebSession $kingdeeSession `
    -Headers $sessionHeaders `
    -TimeoutSec 60
$validRows = @(
    @($queryRows) |
        Where-Object { $_ -is [System.Array] -and $_.Count -ge 4 }
)
if ($validRows.Count -eq 0) {
    throw "Voucher $VoucherNumber was not found in ERP. Check month, organization, account book, and voucher group."
}
if ($validRows.Count -gt 1) {
    throw "ERP returned multiple records for voucher $VoucherNumber. Check the filter settings."
}
$voucherFid = [string]$validRows[0][0]

$viewData = @{
    Number = ''
    Id = $voucherFid
    CreateOrgId = 0
}
$viewBody = @{
    formid = 'GL_VOUCHER'
    data = ($viewData | ConvertTo-Json -Compress)
} | ConvertTo-Json -Compress
$view = Invoke-RestMethod `
    -Method Post `
    -Uri ($serviceRoot + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.View.common.kdsvc') `
    -ContentType 'application/json;charset=UTF-8' `
    -Body $viewBody `
    -WebSession $kingdeeSession `
    -Headers $sessionHeaders `
    -TimeoutSec 60
$status = $view.Result.ResponseStatus
if (-not $status.IsSuccess) {
    throw "ERP voucher view failed: $(Get-ResponseErrorMessage -Status $status)"
}
$model = $view.Result.Result
if ($null -eq $model) {
    throw "ERP did not return content for voucher $VoucherNumber."
}

$entries = @(
    foreach ($entry in @($model.GL_VOUCHERENTRY)) {
        $debit = [decimal]$entry.DEBIT
        $credit = [decimal]$entry.FCREDIT
        if ($null -eq $entry.FACCOUNTID -and
            [string]::IsNullOrWhiteSpace([string]$entry.FEXPLANATION) -and
            $debit -eq 0 -and $credit -eq 0) {
            continue
        }
        [ordered]@{
            Sequence = [int]$entry.Seq
            Explanation = ([string]$entry.FEXPLANATION).Trim()
            AccountNumber = Get-ObjectPropertyText -Object $entry.FACCOUNTID -PropertyName 'Number'
            AccountName = Get-LocalizedText -Object $entry.FACCOUNTID -PropertyName 'Name'
            AccountFullName = Get-LocalizedText -Object $entry.FACCOUNTID -PropertyName 'FullName'
            DetailText = Get-FlexDetailText -DetailObject $entry.DetailID
            CurrencyNumber = Get-ObjectPropertyText -Object $entry.FCURRENCYID -PropertyName 'Number'
            CurrencyName = Get-LocalizedText -Object $entry.FCURRENCYID -PropertyName 'Name'
            Debit = $debit
            Credit = $credit
            BusinessNumber = ([string]$entry.BUSNO).Trim()
        }
    }
)
if ($entries.Count -eq 0) {
    throw "ERP voucher $VoucherNumber contains no printable entries."
}

$result = [ordered]@{
    Source = 'ERP_DIRECT_VIEW'
    VoucherFid = $voucherFid
    BillNumber = ([string]$model.BillNo).Trim()
    VoucherNumber = ([string]$model.VOUCHERGROUPNO).Trim()
    VoucherGroupNumber = Get-ObjectPropertyText -Object $model.VOUCHERGROUPID -PropertyName 'Number'
    VoucherGroupName = Get-LocalizedText -Object $model.VOUCHERGROUPID -PropertyName 'Name'
    Date = ([string]$model.Date).Trim()
    BusinessDate = ([string]$model.BUSDATE).Trim()
    Year = [int]$model.YEAR
    Period = [int]$model.PERIOD
    OrganizationNumber = Get-ObjectPropertyText -Object $model.ACCBOOKORGID -PropertyName 'Number'
    OrganizationName = Get-LocalizedText -Object $model.ACCBOOKORGID -PropertyName 'Name'
    AccountBookNumber = Get-ObjectPropertyText -Object $model.AccountBookID -PropertyName 'Number'
    AccountBookName = Get-LocalizedText -Object $model.AccountBookID -PropertyName 'Name'
    DebitTotal = [decimal]$model.DEBITTOTAL
    CreditTotal = [decimal]$model.FCREDITTOTAL
    AttachmentCount = [int]$model.ATTACHMENTS
    Creator = Get-ObjectPropertyText -Object $model.FCreatorId -PropertyName 'Name'
    Checker = Get-ObjectPropertyText -Object $model.CHECKERID -PropertyName 'Name'
    Poster = Get-ObjectPropertyText -Object $model.POSTERID -PropertyName 'Name'
    Cashier = Get-ObjectPropertyText -Object $model.CASHIERID -PropertyName 'Name'
    EntryCount = $entries.Count
    Entries = $entries
    RetrievedAt = [DateTime]::Now.ToString('s')
}
[System.IO.File]::WriteAllText(
    [System.IO.Path]::GetFullPath($OutputJsonPath),
    ($result | ConvertTo-Json -Depth 12),
    [System.Text.UTF8Encoding]::new($false)
)

[pscustomobject]@{
    VoucherNumber = $result.VoucherNumber
    VoucherFid = $result.VoucherFid
    EntryCount = $result.EntryCount
    OutputJsonPath = [System.IO.Path]::GetFullPath($OutputJsonPath)
}
