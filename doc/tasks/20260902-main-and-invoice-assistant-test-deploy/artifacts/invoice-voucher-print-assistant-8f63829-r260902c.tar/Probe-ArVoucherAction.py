import argparse
import asyncio
import base64
import json
import time
from pathlib import Path
from urllib.parse import quote

from playwright.async_api import async_playwright


def read_env(path: str) -> dict[str, str]:
    values = {}
    for raw in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if line and not line.startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return values


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", required=True)
    parser.add_argument("--invoice", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--pkid", default="")
    args = parser.parse_args()
    env = read_env(args.env)
    base = env["KINGDEE_BASE_URL"].rstrip("/")
    if not base.lower().endswith("/k3cloud"):
        base += "/K3Cloud"

    requests = []
    responses = []
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            executable_path=r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            headless=True,
            args=["--disable-gpu", "--no-sandbox"],
        )
        context = await browser.new_context(viewport={"width": 1280, "height": 720})
        page = await context.new_page()

        def on_request(request) -> None:
            if request.resource_type in {"xhr", "fetch"}:
                requests.append({"url": request.url, "postData": request.post_data or ""})

        async def on_response(response) -> None:
            if response.request.resource_type not in {"xhr", "fetch"}:
                return
            try:
                body = await response.text()
            except Exception:
                body = ""
            responses.append(
                {
                    "url": response.url,
                    "postData": response.request.post_data or "",
                    "status": response.status,
                    "body": body[:5_000_000],
                }
            )

        page.on("request", on_request)
        page.on("response", lambda response: asyncio.create_task(on_response(response)))
        timestamp = env["KINGDEE_TIMESTAMP"]
        login_arg = {
            "dbid": env["KINGDEE_ACCT_ID"],
            "username": env["KINGDEE_USERNAME"],
            "appid": env["KINGDEE_APP_ID"],
            "signeddata": env["KINGDEE_SIGNED_DATA"],
            "timestamp": timestamp, "lcid": env.get("KINGDEE_LCID", "2052"),
            "origintype": "SimPas", "entryrole": "", "formid": "AR_receivable",
            "formtype": "bill" if args.pkid else "list",
            "pkid": args.pkid if args.pkid else "", "otherargs": "", "openmode": None,
            "loginthen": "",
        }
        ud = base64.b64encode(
            json.dumps(login_arg, ensure_ascii=False, separators=(",", ":")).encode()
        ).decode()
        await page.goto(
            f"{base}/html5/index.aspx?ud={quote(ud)}",
            wait_until="domcontentloaded",
            timeout=60_000,
        )
        await page.wait_for_timeout(15_000)
        if not args.pkid:
            await page.mouse.click(511, 23)
            await page.wait_for_timeout(1_000)
            await page.mouse.click(420, 96)
            await page.wait_for_timeout(12_000)
        await page.screenshot(path=args.output + ".initial.png")

        if args.pkid:
            await page.screenshot(path=args.output + ".bill.png")
            voucher_menu = page.get_by_text("\u51ed\u8bc1", exact=True).filter(visible=True)
            voucher_menu_count = await voucher_menu.count()
            action_count = 0
            if voucher_menu_count:
                await voucher_menu.first.click()
                await page.wait_for_timeout(1_000)
                await page.screenshot(path=args.output + ".bill-voucher-menu.png")
                action = page.get_by_text("\u67e5\u770b\u603b\u8d26\u51ed\u8bc1", exact=True).filter(visible=True)
                action_count = await action.count()
                if action_count:
                    await action.last.click()
                    await page.wait_for_timeout(10_000)
                    await page.screenshot(path=args.output + ".bill-after-action.png")
            result = {
                "invoiceCellCount": 1,
                "voucherMenuCount": voucher_menu_count,
                "actionCount": action_count,
                "url": page.url,
                "bodyText": (await page.locator("body").inner_text())[:20_000],
                "requests": requests,
                "responses": responses,
            }
            Path(args.output).write_text(
                json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            await browser.close()
            return

        picker = page.locator(
            "input.k-input.defaultQuikerRowEmptyShow.kd-defaultQuikerRow-partFileds"
        ).first
        picker_wrapper = picker.locator("xpath=..").locator(".k-select")
        if await picker_wrapper.count():
            await picker_wrapper.click()
        else:
            await picker.click()
        await page.wait_for_timeout(800)
        await page.screenshot(path=args.output + ".dropdown.png")
        dropdown_items = page.locator("li.k-item:visible")
        item_texts = await dropdown_items.all_inner_texts()
        target_item = page.locator("li.k-item:visible", has_text="\u53d1\u7968\u53f7")
        exact_target = target_item.filter(has_text="\u53d1\u7968\u53f7")
        selection = {
            "ok": False,
            "reason": "option-not-visible",
            "visibleItems": item_texts,
            "pickerHtml": await picker.evaluate("(el) => el.parentElement.parentElement.outerHTML"),
        }
        if await exact_target.count():
            for index in range(await exact_target.count()):
                candidate = exact_target.nth(index)
                if (await candidate.inner_text()).strip() == "\u53d1\u7968\u53f7":
                    await candidate.click()
                    selection = {"ok": True, "method": "visible-list-item"}
                    break
        Path(args.output + ".selection.json").write_text(
            json.dumps(selection, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        if not selection.get("ok"):
            raise RuntimeError("Invoice-number quick-filter option was not selected")
        await page.wait_for_timeout(800)
        await page.screenshot(path=args.output + ".field-selected.png")
        value_input = page.locator(
            "div[id$='FQKFILTERPANEL_dfr_PPART_Value_P'] input:visible"
        ).last
        if await value_input.count() == 0:
            controls = await page.evaluate(
                """() => Array.from(document.querySelectorAll('input,div,span,a')).map((el) => {
                    const r = el.getBoundingClientRect();
                    return {tag:el.tagName,id:el.id||'',className:String(el.className||''),
                        value:'value' in el?String(el.value||''):'',
                        text:String(el.innerText||el.textContent||'').trim().slice(0,120),
                        x:Math.round(r.x),y:Math.round(r.y),w:Math.round(r.width),h:Math.round(r.height)};
                }).filter((x) => x.w > 0 && x.h > 0 && x.y >= 120 && x.y <= 190)"""
            )
            Path(args.output + ".controls.json").write_text(
                json.dumps(controls, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            raise RuntimeError("Invoice-number value input was not found")
        await value_input.fill(args.invoice)
        await page.locator("a[id$='FQKFILTERPANEL_search']").last.click()
        await page.wait_for_timeout(15_000)
        await page.screenshot(path=args.output + ".searched.png")

        invoice_cell = page.get_by_text(args.invoice, exact=True)
        invoice_cell_count = await invoice_cell.count()
        action_count = 0
        if invoice_cell_count:
            await invoice_cell.first.click()
            voucher_menu = page.get_by_text("\u51ed\u8bc1", exact=True)
            if await voucher_menu.count():
                await voucher_menu.first.click()
                await page.wait_for_timeout(800)
                await page.screenshot(path=args.output + ".voucher-menu.png")
                action = page.get_by_text("\u67e5\u770b\u603b\u8d26\u51ed\u8bc1", exact=True)
                action_count = await action.count()
                if action_count:
                    await action.last.click()
                    await page.wait_for_timeout(10_000)
                    await page.screenshot(path=args.output + ".after-action.png")

        body_text = await page.locator("body").inner_text()
        result = {
            "invoiceCellCount": invoice_cell_count,
            "actionCount": action_count,
            "url": page.url,
            "bodyText": body_text[:20_000],
            "requests": requests,
            "responses": responses,
        }
        Path(args.output).write_text(
            json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
