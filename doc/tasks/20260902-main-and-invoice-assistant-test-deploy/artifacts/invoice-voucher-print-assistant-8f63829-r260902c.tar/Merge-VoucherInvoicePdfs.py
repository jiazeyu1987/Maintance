from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


HERE = Path(__file__).resolve().parent
if sys.platform == "win32":
    sys.path.insert(0, str(HERE / "vendor"))

from pypdf import PdfReader, PdfWriter, Transformation
from pypdf._page import PageObject
from pypdf.generic import NameObject, RectangleObject


A5_LANDSCAPE_WIDTH = 595.2756
A5_LANDSCAPE_HEIGHT = 419.5276
A5_PORTRAIT_WIDTH = A5_LANDSCAPE_HEIGHT
A5_PORTRAIT_HEIGHT = A5_LANDSCAPE_WIDTH
POINTS_PER_MM = 72 / 25.4
INVOICE_SAFE_MARGIN = 6 * POINTS_PER_MM


def transform_page_annotations(
    page: PageObject,
    scale: float,
    offset_x: float,
    offset_y: float,
) -> None:
    """Keep stamp/widget annotations aligned with scaled page content."""
    for annotation_reference in page.get("/Annots") or []:
        annotation = annotation_reference.get_object()
        rectangle = annotation.get("/Rect")
        if not rectangle or len(rectangle) != 4:
            continue
        left, bottom, right, top = (float(value) for value in rectangle)
        annotation[NameObject("/Rect")] = RectangleObject(
            (
                left * scale + offset_x,
                bottom * scale + offset_y,
                right * scale + offset_x,
                top * scale + offset_y,
            )
        )


def add_as_a5(
    writer: PdfWriter,
    source_page: PageObject,
    safe_margin: float = 0,
    orientation_mode: str = "auto",
) -> tuple[str, float]:
    if source_page.rotation:
        source_page.transfer_rotation_to_content()
    source_width = float(source_page.mediabox.width)
    source_height = float(source_page.mediabox.height)
    if source_width <= 0 or source_height <= 0:
        raise RuntimeError("PDF page has an invalid size.")

    if orientation_mode == "landscape":
        orientation = "landscape"
    elif orientation_mode == "portrait":
        orientation = "portrait"
    elif orientation_mode == "auto":
        orientation = "landscape" if source_width >= source_height else "portrait"
    else:
        raise RuntimeError(f"Unsupported A5 orientation mode: {orientation_mode}")

    if orientation == "landscape":
        target_width = A5_LANDSCAPE_WIDTH
        target_height = A5_LANDSCAPE_HEIGHT
    else:
        target_width = A5_PORTRAIT_WIDTH
        target_height = A5_PORTRAIT_HEIGHT

    usable_width = target_width - 2 * safe_margin
    usable_height = target_height - 2 * safe_margin
    if usable_width <= 0 or usable_height <= 0:
        raise RuntimeError("PDF safe print margin is too large.")
    scale = min(
        usable_width / source_width,
        usable_height / source_height,
    )
    offset_x = (target_width - source_width * scale) / 2
    offset_y = (target_height - source_height * scale) / 2
    target_page = PageObject.create_blank_page(
        width=target_width,
        height=target_height,
    )
    target_page.merge_transformed_page(
        source_page,
        Transformation().scale(scale).translate(offset_x, offset_y),
    )
    transform_page_annotations(target_page, scale, offset_x, offset_y)
    writer.add_page(target_page)
    return orientation, scale


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--summary", required=True)
    args = parser.parse_args()

    manifest_path = Path(args.manifest).resolve()
    output_path = Path(args.output).resolve()
    summary_path = Path(args.summary).resolve()

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    items = list(manifest.get("Items") or [])
    if not items:
        raise RuntimeError("No invoice PDF files were supplied.")

    writer = PdfWriter()
    result_items = []
    page_number = 0
    last_voucher = None
    voucher_pdf_count = 0
    invoice_file_count = 0
    landscape_page_count = 0
    portrait_page_count = 0

    for item in items:
        item_type = str(item.get("Type") or "invoice").strip().lower()
        voucher_number = str(item.get("VoucherNumber") or "").strip()
        file_path = Path(str(item.get("FilePath") or "")).resolve()
        if not file_path.is_file():
            raise FileNotFoundError(str(file_path))
        if file_path.suffix.lower() != ".pdf":
            raise RuntimeError(f"Not a PDF file: {file_path}")

        reader = PdfReader(str(file_path), strict=False)
        if reader.is_encrypted:
            decrypt_result = reader.decrypt("")
            if decrypt_result == 0:
                raise RuntimeError(f"Encrypted PDF cannot be opened: {file_path.name}")

        start_page = page_number + 1
        page_orientations = []
        page_scales = []
        for page in reader.pages:
            orientation, scale = add_as_a5(
                writer,
                page,
                safe_margin=0 if item_type == "voucher" else INVOICE_SAFE_MARGIN,
                orientation_mode="landscape" if item_type == "voucher" else "auto",
            )
            page_orientations.append(orientation)
            page_scales.append(round(scale, 4))
            if orientation == "portrait":
                portrait_page_count += 1
            else:
                landscape_page_count += 1
            page_number += 1

        if item_type == "voucher":
            voucher_pdf_count += 1
        else:
            invoice_file_count += 1

        if voucher_number != last_voucher:
            try:
                writer.add_outline_item(f"Voucher {voucher_number}", start_page - 1)
            except Exception:
                pass
            last_voucher = voucher_number

        result_items.append(
            {
                "VoucherNumber": voucher_number,
                "Type": item_type,
                "FileName": file_path.name,
                "PageCount": len(reader.pages),
                "StartPage": start_page,
                "EndPage": page_number,
                "SafeMarginMm": 0 if item_type == "voucher" else 6,
                "PrintOrientations": page_orientations,
                "ScaleFactors": page_scales,
            }
        )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    writer.add_metadata(
        {
            "/Title": "Voucher and invoice print pack",
            "/Subject": "ERP voucher followed by its invoice PDFs",
            "/Creator": "ERP invoice renamer",
        }
    )
    with output_path.open("wb") as output_file:
        writer.write(output_file)

    summary = {
        "VoucherCount": len(
            {str(item.get("VoucherNumber") or "").strip() for item in items}
        ),
        "VoucherPdfCount": voucher_pdf_count,
        "InvoiceFileCount": invoice_file_count,
        "MergedFileCount": len(result_items),
        "PageCount": page_number,
        "PageSize": "A5 mixed orientation",
        "OrientationRule": (
            "Voucher pages use landscape; invoice pages automatically follow "
            "the source PDF page orientation."
        ),
        "LandscapePageCount": landscape_page_count,
        "PortraitPageCount": portrait_page_count,
        "InvoiceSafeMarginMm": 6,
        "OutputPath": str(output_path),
        "Items": result_items,
    }
    summary_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
