[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$settings = @{}
foreach ($line in Get-Content -LiteralPath $EnvPath -Encoding UTF8) {
    if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') {
        $settings[$Matches[1]] = $Matches[2].Trim()
    }
}
$root = ([string]$settings.KINGDEE_BASE_URL).TrimEnd('/')
if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) {
    $root += '/K3Cloud'
}
$root += '/'
$authPath = [string]$settings.KINGDEE_AUTH_PATH
if ([string]::IsNullOrWhiteSpace($authPath)) {
    $authPath = 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc'
}
$login = Invoke-WebRequest -UseBasicParsing -Method Post -Uri ($root + $authPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{
        acctID = [string]$settings.KINGDEE_ACCT_ID
        username = [string]$settings.KINGDEE_USERNAME
        password = [string]$settings.KINGDEE_PASSWORD
        lcid = if ($settings.KINGDEE_LCID) { [string]$settings.KINGDEE_LCID } else { '2052' }
    } -SessionVariable session -TimeoutSec 30
$loginBody = $login.Content | ConvertFrom-Json
$headers = @{}
if ($loginBody.Context.SessionId) { $headers.SessionId = [string]$loginBody.Context.SessionId }
if ($loginBody.KDSVCSessionId) { $headers.KDSVCSessionId = [string]$loginBody.KDSVCSessionId }

$switchResponse = Invoke-WebRequest -UseBasicParsing -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc') `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{ data = '{"OrgNumber":"881"}' } `
    -WebSession $session -Headers $headers -TimeoutSec 30
$switchBody = $switchResponse.Content | ConvertFrom-Json
if ($switchBody.Result.ResponseStatus -and -not $switchBody.Result.ResponseStatus.IsSuccess) {
    throw 'ERP organization switch failed.'
}

$queryUri = $root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.ExecuteBillQuery.common.kdsvc'
$candidates = @('BAS_BizVoucherLink', 'BAS_BizVoucher', 'BAS_BillVchInfo')
$fieldSets = @(
    'FID',
    'FNUMBER',
    'FBILLNO',
    'FDATE',
    'FYEAR',
    'FPERIOD',
    'FVOUCHERNO',
    'FVOUCHERNUMBER',
    'FVOUCHERGROUPNO',
    'FVOUCHERGROUPID',
    'FVOUCHERGROUPID.FNUMBER',
    'FVOUCHERGROUPID.FNAME',
    'FSOURCEBILLFORMID',
    'FSOURCEBILLFORMID.FNUMBER',
    'FSOURCEBILLNO',
    'FSOURCEBILLID',
    'FSOURCEFORMID',
    'FBILLID',
    'FBIZVOUCHERID',
    'FBIZVOUCHERID.FBILLNO',
    'FGLVOUCHERID',
    'FGLVOUCHERID.FBILLNO',
    'FVOUCHERBILLNO',
    'FVOUCHERDATE',
    'FVOUCHERYEARPERIOD',
    'FBOOKID.FNUMBER',
    'FBOOKID.FNAME',
    'FACCTSYSTEMID.FNUMBER',
    'FACCTSYSTEMID.FNAME'
)
$results = foreach ($formId in $candidates) {
    foreach ($fieldKeys in $fieldSets) {
        $query = @{
            FormId = $formId
            FieldKeys = $fieldKeys
            FilterString = ''
            OrderString = ''
            TopRowCount = 1
            StartRow = 0
            Limit = 100
        }
        $body = @{ data = ($query | ConvertTo-Json -Depth 8 -Compress) } |
            ConvertTo-Json -Compress
        try {
            $response = Invoke-RestMethod -Method Post -Uri $queryUri `
                -ContentType 'application/json;charset=UTF-8' -Body $body `
                -WebSession $session -Headers $headers -TimeoutSec 60
            [pscustomobject]@{ FormId = $formId; FieldKeys = $fieldKeys; Response = $response }
        }
        catch {
            [pscustomobject]@{ FormId = $formId; FieldKeys = $fieldKeys; Error = $_.Exception.Message }
        }
    }
}
$results | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
