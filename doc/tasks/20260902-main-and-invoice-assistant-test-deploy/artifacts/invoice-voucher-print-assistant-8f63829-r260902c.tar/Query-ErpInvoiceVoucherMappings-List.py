import argparse
import asyncio
import base64
import gzip
import json
import os
import re
import sys
from pathlib import Path
from urllib.parse import quote, unquote

from playwright.async_api import async_playwright


# Use the ERP interface user's own receivable list.  Personal schemes owned by
# another ERP user (for example JYY) are not visible to the interface login.
DEFAULT_SCHEME = "\u9ed8\u8ba4\u65b9\u6848\uff08\u4e2a\u4eba\uff09"


def read_env(path: str) -> dict[str, str]:
    env_path = Path(path)
    if not env_path.is_file():
        raise FileNotFoundError(f"ERP配置文件不存在：{path}")
    values: dict[str, str] = {}
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def decode_argument(value: str) -> str:
    return gzip.decompress(base64.b64decode(unquote(value))).decode("utf-8")


def encode_argument(value: str) -> str:
    compressed = gzip.compress(value.encode("utf-8"), mtime=0)
    return quote(base64.b64encode(compressed).decode("ascii"), safe="")


def decode_response(value: str) -> str:
    if not value.startswith("H4sI"):
        return value
    return gzip.decompress(base64.b64decode(value)).decode("utf-8")


def make_sso_url(env: dict[str, str]) -> str:
    base_url = env["KINGDEE_BASE_URL"].rstrip("/")
    if not base_url.lower().endswith("/k3cloud"):
        base_url += "/K3Cloud"
    dbid = env["KINGDEE_ACCT_ID"]
    username = env["KINGDEE_USERNAME"]
    appid = env["KINGDEE_APP_ID"]
    signeddata = env["KINGDEE_SIGNED_DATA"]
    timestamp = env["KINGDEE_TIMESTAMP"]
    login_arg = {
        "dbid": dbid,
        "username": username,
        "appid": appid,
        "signeddata": signeddata,
        "timestamp": timestamp,
        "lcid": env.get("KINGDEE_LCID", "2052"),
        "origintype": "SimPas",
        "entryrole": "",
        # Start at the ERP home page. The organization must be selected before
        # the receivable-list form is created, otherwise Kingdee binds that form
        # to the login account's previous organization for its whole lifetime.
        "formid": "",
        "formtype": "",
        "pkid": "",
        "otherargs": "",
        "openmode": None,
        "loginthen": "",
    }
    encoded = base64.b64encode(
        json.dumps(login_arg, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).decode("ascii")
    return f"{base_url}/html5/index.aspx?ud={quote(encoded)}"


def kingdee_base_url(env: dict[str, str]) -> str:
    base_url = env["KINGDEE_BASE_URL"].rstrip("/")
    if not base_url.lower().endswith("/k3cloud"):
        base_url += "/K3Cloud"
    return base_url


def extract_entry_request(captured: list[dict]) -> tuple[str, dict] | None:
    for item in reversed(captured):
        post_data = item.get("postData")
        if not post_data or "CallByUrl.common.kdsvc" not in item.get("url", ""):
            continue
        try:
            envelope = json.loads(post_data)
            decoded = decode_argument(envelope.get("ap0", ""))
        except Exception:
            continue
        if "GetEntryData" in decoded and "ListService" in decoded:
            return item["url"], envelope
    return None


def invoice_and_voucher(row: list) -> tuple[str, str, str, str]:
    if len(row) < 20:
        return "", "", "", ""

    def display_text(value) -> str:
        if isinstance(value, list):
            return str(value[0] if value else "").strip()
        return str(value or "").strip()

    invoice = display_text(row[2])
    bill_number = display_text(row[3])
    voucher_number = display_text(row[19])
    date_value = row[1]
    if isinstance(date_value, list) and len(date_value) > 1:
        date_text = str(date_value[1] or "")[:10]
    else:
        date_text = str(date_value or "")[:10]
    return invoice, voucher_number, bill_number, date_text


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--business-month", required=True)
    parser.add_argument("--organization-number", required=True)
    parser.add_argument("--account-book-number", required=True)
    parser.add_argument("--voucher-group-number", required=True)
    parser.add_argument("--invoice-numbers", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--env", required=True)
    args = parser.parse_args()

    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", args.business_month):
        raise RuntimeError("Business month must use yyyy-MM format.")
    if args.organization_number != "881":
        raise RuntimeError("The shared-list query is only configured for organization 881.")

    invoice_numbers = {
        str(value).strip()
        for value in json.loads(Path(args.invoice_numbers).read_text(encoding="utf-8"))
        if re.fullmatch(r"\d{8,30}", str(value).strip())
    }
    if not invoice_numbers:
        raise RuntimeError("No valid invoice number was provided.")

    env = read_env(args.env)
    year, month = args.business_month.split("-")
    captured_requests: list[dict] = []
    entry_payloads: list[dict] = []

    async with async_playwright() as playwright:
        executable = os.environ.get("PLAYWRIGHT_CHROMIUM_EXECUTABLE", "").strip() or None
        if executable is None and os.name == "nt":
            chrome = Path(r"C:\Program Files\Google\Chrome\Application\chrome.exe")
            if chrome.exists():
                executable = str(chrome)
        launch_options = {"headless": True, "args": ["--disable-gpu", "--no-sandbox"]}
        if executable:
            launch_options["executable_path"] = executable
        browser = await playwright.chromium.launch(**launch_options)
        context = await browser.new_context(viewport={"width": 1280, "height": 720})
        page = await context.new_page()

        def record_request(request) -> None:
            if request.resource_type in {"xhr", "fetch"}:
                captured_requests.append(
                    {"url": request.url, "postData": request.post_data or ""}
                )

        async def record_response(response) -> None:
            if response.request.resource_type not in {"xhr", "fetch"}:
                return
            if "CallByUrl.common.kdsvc" not in response.url:
                return
            try:
                body = decode_response(await response.text())
                payload = json.loads(body)
            except Exception:
                return
            if isinstance(payload, dict) and isinstance(payload.get("rows"), list):
                entry_payloads.append(payload)

        page.on("request", record_request)
        page.on("response", lambda response: asyncio.create_task(record_response(response)))
        base_url = kingdee_base_url(env)
        auth_path = env.get("KINGDEE_AUTH_PATH", "").strip() or (
            "Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc"
        )
        auth_response = await context.request.post(
            f"{base_url}/{auth_path}",
            form={
                "acctID": env["KINGDEE_ACCT_ID"],
                "username": env["KINGDEE_USERNAME"],
                "password": env["KINGDEE_PASSWORD"],
                "lcid": env.get("KINGDEE_LCID", "2052"),
            },
            timeout=30_000,
        )
        auth_result = await auth_response.json()
        if not (
            auth_result.get("LoginResultType") == 1
            or auth_result.get("IsSuccessByAPI") is True
        ):
            raise RuntimeError("ERP interface login failed.")
        switch_response = await context.request.post(
            f"{base_url}/Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc",
            form={"data": json.dumps({"OrgNumber": args.organization_number})},
            timeout=30_000,
        )
        switch_result = await switch_response.json()
        status = switch_result.get("Result", {}).get("ResponseStatus", {})
        if status and status.get("IsSuccess") is False:
            raise RuntimeError("ERP organization switch failed.")
        await page.goto(make_sso_url(env), wait_until="domcontentloaded", timeout=60_000)
        await page.wait_for_timeout(15_000)

        # SwitchOrg above belongs to the WebAPI cookie session. Kingdee's HTML5
        # SSO creates a separate UI session and otherwise keeps the user's
        # default organization (892), which makes valid 881 receivables appear
        # as an empty result. Explicitly switch the visible HTML5 session too.
        body_text = await page.locator("body").inner_text()
        if not re.search(r"(?:^|\s)881\s+\u4e0a\u6d77\u745b\u6cf0\u533b\u7597\u5668\u68b0\u80a1\u4efd\u6709\u9650\u516c\u53f8", body_text):
            await page.mouse.click(500, 24)
            await page.wait_for_timeout(1_000)
            target_org = page.get_by_text(
                re.compile(r"881\s+\u4e0a\u6d77\u745b\u6cf0\u533b\u7597\u5668\u68b0\u80a1\u4efd\u6709\u9650\u516c\u53f8")
            ).filter(visible=True)
            if await target_org.count():
                await target_org.last.click()
            else:
                # The current Kingdee build renders this menu as a canvas-like
                # list in headless Chromium, so retain its stable first-row hit
                # target as a fallback.
                await page.mouse.click(420, 96)
            await page.wait_for_timeout(15_000)

        body_text = await page.locator("body").inner_text()
        if not re.search(r"(?:^|\s)881\s+\u4e0a\u6d77\u745b\u6cf0\u533b\u7597\u5668\u68b0\u80a1\u4efd\u6709\u9650\u516c\u53f8", body_text):
            await page.screenshot(path=args.output + ".organization.png")
            raise RuntimeError("ERP HTML5 session did not switch to organization 881.")

        # The SSO navigation creates a new HTML5 session after the WebAPI
        # session was switched above.  Switch that *current browser session*
        # explicitly as well.  Otherwise the header can display 881 while the
        # subsequent list service still queries the user's previous org and
        # returns an empty receivable grid.
        html5_switch_result = await page.evaluate(
            """async ({url, orgNumber}) => {
                const body = new URLSearchParams({
                    data: JSON.stringify({OrgNumber: orgNumber}),
                });
                const response = await fetch(url, {
                    method: 'POST',
                    credentials: 'include',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'},
                    body: body.toString(),
                });
                return {status: response.status, text: await response.text()};
            }""",
            {
                "url": f"{base_url}/Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc",
                "orgNumber": args.organization_number,
            },
        )
        if int(html5_switch_result.get("status", 0)) != 200:
            raise RuntimeError("ERP HTML5 organization switch request failed.")

        # Open the list only after the organization switch. Use Kingdee's global
        # search so this works without relying on a customized left-side menu.
        await page.mouse.click(1066, 23)
        await page.wait_for_timeout(700)
        search_inputs = page.locator("input:visible")
        search_input = None
        for index in range(await search_inputs.count()):
            candidate = search_inputs.nth(index)
            placeholder = (await candidate.get_attribute("placeholder") or "").strip()
            if "\u641c\u7d22" in placeholder or "\u83dc\u5355" in placeholder:
                search_input = candidate
                break
        if search_input is None:
            await page.screenshot(path=args.output + ".global-search.png")
            raise RuntimeError("ERP global menu search was not found.")
        await search_input.fill("\u5e94\u6536\u5355\u5217\u8868")
        await page.wait_for_timeout(1_500)
        receivable_result = page.get_by_text("\u5e94\u6536\u5355\u5217\u8868", exact=True).filter(visible=True)
        if await receivable_result.count() == 0:
            await page.screenshot(path=args.output + ".global-search-result.png")
            raise RuntimeError("ERP receivable list was not found in global search.")
        await receivable_result.last.click()
        await page.wait_for_timeout(15_000)

        # Use the interface account's own scheme. Personal/shared schemes from
        # desktop ERP users are not guaranteed to exist in a server session.
        scheme = page.get_by_text(DEFAULT_SCHEME, exact=True).filter(visible=True)
        if await scheme.count() == 0:
            await page.screenshot(path=args.output + ".scheme-picker.png")
            raise RuntimeError("ERP receivable-list default scheme was not found.")
        await scheme.first.click()
        await page.wait_for_timeout(12_000)

        # Work from the interface user's default receivable-list scheme. Its
        # first quick-filter row is normally "bill number", so explicitly turn
        # that row into "business date / month" before searching. This avoids
        # depending on another employee's private saved scheme and keeps the
        # query on the receivable list where 881's voucher column is calculated.
        entry_payloads.clear()
        before_search_request_count = len(captured_requests)
        field_picker = page.locator(
            "input.k-input.defaultQuikerRowEmptyShow.kd-defaultQuikerRow-partFileds"
        ).first
        if await field_picker.count() == 0:
            raise RuntimeError("ERP receivable-list quick-filter field was not found.")
        debug_bill_number = os.environ.get("ERP_LIST_DEBUG_BILL_NUMBER", "").strip()
        debug_invoice_number = os.environ.get("ERP_LIST_DEBUG_INVOICE_NUMBER", "").strip()
        field_picker_button = field_picker.locator("xpath=..").locator(".k-select")
        if await field_picker_button.count():
            await field_picker_button.click()
        else:
            await field_picker.click()
        await page.wait_for_timeout(800)
        # Always load the complete business month. In organization 881 the
        # invoice number is a custom list field, and using it as a quick filter
        # can return zero rows although the receivable bill is visible in ERP.
        desired_field = (
            "\u5355\u636e\u7f16\u53f7"
            if debug_bill_number
            else "\u53d1\u7968\u53f7"
            if debug_invoice_number
            else "\u4e1a\u52a1\u65e5\u671f"
        )
        field_choices = page.locator("li.k-item:visible")
        selected_field = False
        for index in range(await field_choices.count()):
            choice = field_choices.nth(index)
            if (await choice.inner_text()).strip() == desired_field:
                await choice.click()
                selected_field = True
                break
        if not selected_field:
            await page.screenshot(path=args.output + ".field-picker.png")
            raise RuntimeError(f"ERP receivable-list field was not found: {desired_field}")
        await page.wait_for_timeout(700)
        if not debug_bill_number and not debug_invoice_number:
            period_picker = page.locator(
            "span.kd-defaultQuikerRow-partCompareType[role='listbox']"
            ).first
            if await period_picker.count() == 0:
                raise RuntimeError("ERP business-date period selector was not found.")
            await period_picker.click()
            await page.wait_for_timeout(400)
            month_choice = page.locator("li.k-item:visible").filter(has_text="月")
            if await month_choice.count() == 0:
                month_choice = page.get_by_text("月", exact=True).filter(visible=True)
            if await month_choice.count() == 0:
                await page.screenshot(path=args.output + ".month-picker.png")
                Path(args.output + ".month-picker.html").write_text(
                    await page.content(), encoding="utf-8"
                )
                raise RuntimeError("ERP business-date month option was not found.")
            await month_choice.last.click()
            await page.wait_for_timeout(400)
        quick_filter_value = page.locator(
            "div[id$='FQKFILTERPANEL_dfr_PPART_Value_P'] input:visible"
        ).first
        if await quick_filter_value.count() == 0:
            raise RuntimeError("ERP business-date quick filter was not found.")
        filter_text = debug_bill_number or debug_invoice_number or f"{year}-{month}"
        await quick_filter_value.click()
        await quick_filter_value.press("Control+A")
        await quick_filter_value.type(filter_text, delay=25)
        # Kingdee's Kendo date editor does not commit a programmatic fill until
        # the input loses focus.  Without this, the box visibly shows the new
        # month while the request still uses the saved scheme's old month.
        # Commit the Kendo value, then click the same blue search button used in
        # ERP. Enter alone can leave the grid on its stale saved-scheme result.
        await quick_filter_value.press("Tab")
        await page.wait_for_timeout(500)
        search_button = page.locator("a[id$='FQKFILTERPANEL_search']").last
        if await search_button.count() == 0:
            raise RuntimeError("ERP quick-filter search button was not found.")
        await search_button.click()
        await page.wait_for_timeout(15_000)

        debug_controls_path = os.environ.get("ERP_LIST_DEBUG_CONTROLS", "").strip()
        if debug_controls_path:
            controls = await page.evaluate(
                """() => Array.from(document.querySelectorAll('*')).map((el) => {
                    const r = el.getBoundingClientRect();
                    return {
                        tag: el.tagName, id: el.id || '',
                        className: String(el.className || ''),
                        text: String(el.innerText || el.textContent || '').trim().slice(0, 200),
                        value: 'value' in el ? String(el.value || '') : '',
                        x: Math.round(r.x), y: Math.round(r.y),
                        width: Math.round(r.width), height: Math.round(r.height),
                    };
                }).filter((x) => x.width > 0 && x.height > 0 && x.y >= 110 && x.y <= 190)"""
            )
            Path(debug_controls_path).write_text(
                json.dumps(controls, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            await page.screenshot(path=debug_controls_path + ".png")

        request_info = extract_entry_request(captured_requests[before_search_request_count:])
        if request_info is None:
            request_info = extract_entry_request(captured_requests)
        if request_info is None:
            raise RuntimeError("ERP list data request was not captured.")
        request_url, request_envelope = request_info

        # Fetch larger pages directly.  The grid itself uses 200-row pages;
        # replaying thousands of those requests is unnecessarily slow and can
        # also loop when Kingdee reuses a stale page.  A monthly receivable
        # result comfortably fits in 10,000-row pages.
        rows: list[list] = []
        page_size = 10_000
        start_row = 0
        previous_signature = None
        while start_row <= 100_000:
            decoded_url = decode_argument(request_envelope["ap0"])
            raw_url = unquote(decoded_url)
            raw_url = re.sub(
                r'paramdata=\["FLIST",\d+,\d+,null\]',
                f'paramdata=["FLIST",{start_row},{page_size},null]',
                raw_url,
            )
            envelope = dict(request_envelope)
            envelope["ap0"] = encode_argument(quote(raw_url, safe=""))
            result = await page.evaluate(
                """async ({url, body}) => {
                    const response = await fetch(url, {
                        method: 'POST', credentials: 'include',
                        headers: {'Content-Type': 'application/json;charset=UTF-8'}, body
                    });
                    return {status: response.status, text: await response.text()};
                }""",
                {
                    "url": request_url,
                    "body": json.dumps(envelope, ensure_ascii=False, separators=(",", ":")),
                },
            )
            payload = json.loads(decode_response(result["text"]))
            page_rows = payload.get("rows", []) if isinstance(payload, dict) else []
            signature = json.dumps(page_rows[:2], ensure_ascii=False, sort_keys=True)
            if start_row > 0 and signature == previous_signature:
                break
            previous_signature = signature
            rows.extend(page_rows)
            if len(page_rows) < page_size:
                break
            start_row += page_size

        await browser.close()

    debug_rows_path = os.environ.get("ERP_LIST_DEBUG_ROWS", "").strip()
    if debug_rows_path:
        Path(debug_rows_path).write_text(
            json.dumps(rows, ensure_ascii=False), encoding="utf-8"
        )

    mappings = {
        invoice: {"vouchers": set(), "bills": set(), "dates": set(), "rows": 0}
        for invoice in invoice_numbers
    }
    for row in rows:
        invoice_text, voucher, bill_number, date_text = invoice_and_voucher(row)
        row_invoices = set(re.findall(r"\d{20}", invoice_text))
        matched_invoices = row_invoices.intersection(mappings)
        if not matched_invoices or not date_text.startswith(f"{year}-{month}"):
            continue
        for invoice in matched_invoices:
            item = mappings[invoice]
            item["rows"] += 1
            if voucher and voucher != "0":
                item["vouchers"].add(voucher)
            if bill_number:
                item["bills"].add(bill_number)
            if date_text:
                item["dates"].add(date_text)

    items = []
    for invoice in sorted(invoice_numbers):
        item = mappings[invoice]
        items.append(
            {
                "InvoiceNumber": invoice,
                "Rows": item["rows"],
                "VoucherNumbers": sorted(
                    item["vouchers"],
                    key=lambda x: (0, int(x)) if x.isdigit() else (1, x),
                ),
                "BillNumbers": sorted(item["bills"]),
                "Dates": sorted(item["dates"]),
            }
        )
    result = {
        "Source": "ERP_RECEIVABLE_SHARED_LIST",
        "BusinessMonth": args.business_month,
        "OrganizationNumber": args.organization_number,
        "AccountBookNumber": args.account_book_number,
        "VoucherGroupNumber": args.voucher_group_number,
        "InputInvoiceCount": len(invoice_numbers),
        "MatchedInvoiceCount": sum(bool(item["VoucherNumbers"]) for item in items),
        "QueriedReceivableRows": len(rows),
        "Items": items,
    }
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({key: value for key, value in result.items() if key != "Items"}, ensure_ascii=False))


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except FileNotFoundError as exc:
        print(str(exc), file=sys.stderr)
        raise SystemExit(1)
