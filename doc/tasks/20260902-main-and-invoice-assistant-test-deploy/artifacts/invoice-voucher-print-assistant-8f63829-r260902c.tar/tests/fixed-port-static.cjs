const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')

const projectRoot = path.resolve(__dirname, '..')
const serverSource = fs.readFileSync(path.join(projectRoot, 'server.js'), 'utf8')
const envExample = fs.readFileSync(path.join(projectRoot, '.env.example'), 'utf8')
const dockerfile = fs.readFileSync(path.join(projectRoot, 'Dockerfile'), 'utf8')

assert.match(serverSource, /const FIXED_PORT = 18733/)
assert.match(serverSource, /INVOICE_RENAMER_PORT/)
assert.match(serverSource, /configuredPort/)
assert.match(serverSource, /fixed port must be 18733/i)
assert.doesNotMatch(serverSource, /const port = Number\(process\.env\.INVOICE_RENAMER_PORT \|\| 18733\)/)
assert.match(envExample, /^INVOICE_RENAMER_PORT=18733$/m)
assert.match(dockerfile, /EXPOSE 18733/)
assert.doesNotMatch(dockerfile, /INVOICE_RENAMER_PORT=\$\{/)

console.log('fixed port static contract passed')
