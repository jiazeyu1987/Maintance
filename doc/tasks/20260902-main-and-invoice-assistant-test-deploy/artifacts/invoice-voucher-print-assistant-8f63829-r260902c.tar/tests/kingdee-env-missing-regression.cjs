const assert = require('node:assert/strict')
const fs = require('node:fs')
const os = require('node:os')
const path = require('node:path')
const { spawnSync } = require('node:child_process')

const projectRoot = path.resolve(__dirname, '..')
const scriptPath = path.join(projectRoot, 'Query-ErpInvoiceVoucherMappings-List.py')

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'kingdee-env-missing-'))
const invoiceNumbersPath = path.join(tempRoot, 'invoice-numbers.json')
const outputPath = path.join(tempRoot, 'output.json')
const missingEnvPath = path.join(tempRoot, '.env.kingdee')

fs.writeFileSync(invoiceNumbersPath, JSON.stringify(['25312000000436879981']), 'utf8')

const result = spawnSync(
  'python',
  [
    scriptPath,
    '--business-month', '2025-12',
    '--organization-number', '881',
    '--account-book-number', '002',
    '--voucher-group-number', 'PZZ9',
    '--invoice-numbers', invoiceNumbersPath,
    '--output', outputPath,
    '--env', missingEnvPath,
  ],
  {
    encoding: 'utf8',
    env: {
      ...process.env,
      PYTHONUTF8: '1',
      PYTHONIOENCODING: 'utf-8',
    },
  }
)

assert.notStrictEqual(result.status, 0, 'script should fail when the Kingdee env file is missing')
assert.match(
  result.stderr,
  /ERP配置文件不存在|ERP configuration file does not exist/,
  'stderr should report the missing configuration file clearly'
)
assert.doesNotMatch(
  result.stderr,
  /Traceback \(most recent call last\):/,
  'stderr should not expose a Python traceback for this validation failure'
)

console.log('kingdee env missing regression passed')
