const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')

const projectRoot = path.resolve(__dirname, '..')

function readUtf8(relativePath) {
  return fs.readFileSync(path.join(projectRoot, relativePath), 'utf8')
}

const expectedName = '上海瑛泰医疗器械股份有限公司'
const previousName = ['上海璞', '泰医疗器械股份有限公司'].join('')

const indexSource = readUtf8('public/index.html')
const probeSource = readUtf8('Probe-SsoBrowser.py')

assert.match(indexSource, new RegExp(expectedName), 'sales organization option must use the new company name')
assert.doesNotMatch(indexSource, new RegExp(previousName), 'page must not show the previous company name')
assert.match(probeSource, new RegExp(expectedName), 'SSO probe target must use the new company name')
assert.doesNotMatch(probeSource, new RegExp(previousName), 'SSO probe must not target the previous company name')

console.log('sales organization copy static contract passed')
