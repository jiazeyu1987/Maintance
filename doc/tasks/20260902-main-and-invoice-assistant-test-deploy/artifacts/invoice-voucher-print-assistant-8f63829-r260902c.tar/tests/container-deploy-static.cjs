const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')

const projectRoot = path.resolve(__dirname, '..')

function readUtf8(relativePath) {
  return fs.readFileSync(path.join(projectRoot, relativePath), 'utf8')
}

const dockerfile = readUtf8('Dockerfile')
const dockerignore = readUtf8('.dockerignore')
const readme = readUtf8('README.md')

assert.match(dockerfile, /^ARG PLAYWRIGHT_VERSION=1\.62\.0/m)
assert.match(dockerfile, /^FROM mcr\.microsoft\.com\/playwright:v\$\{PLAYWRIGHT_VERSION\}-noble/m)
assert.match(dockerfile, /WORKDIR \/opt\/invoice-voucher-print-assistant\/app/)
assert.match(dockerfile, /packages\.microsoft\.com\/ubuntu\/24\.04\/prod noble main/)
assert.match(dockerfile, /apt-get install[\s\S]*powershell/)
assert.match(dockerfile, /python3 -m venv \/opt\/invoice-assistant-venv/)
assert.match(dockerfile, /pip install --no-cache-dir "playwright==\$\{PLAYWRIGHT_VERSION\}"/)
assert.match(dockerfile, /grep -v -i '\^playwright\$' requirements\.txt/)
assert.doesNotMatch(dockerfile, /playwright install --with-deps chromium/)
assert.match(dockerfile, /INVOICE_RENAMER_HOST=0\.0\.0\.0/)
assert.match(dockerfile, /INVOICE_RENAMER_PORT=18733/)
assert.match(dockerfile, /PYTHON_COMMAND=\/opt\/invoice-assistant-venv\/bin\/python/)
assert.match(dockerfile, /POWERSHELL_COMMAND=\/usr\/bin\/pwsh/)
assert.match(dockerfile, /KINGDEE_RUNTIME_DIR=\/opt\/invoice-voucher-print-assistant\/runtime/)
assert.doesNotMatch(dockerfile, /KINGDEE_ENV_PATH/)
assert.match(dockerfile, /EXPOSE 18733/)
assert.match(dockerfile, /CMD \["node", "server\.js"\]/)

assert.match(dockerignore, /^node_modules\//m)
assert.match(dockerignore, /^vendor\//m)
assert.match(dockerignore, /^浏览器运行结果\//m)
assert.match(dockerignore, /^服务器上传发票\//m)

assert.match(readme, /短期票据校验成功后把当前生效 Kingdee 配置快照发给助手/)
assert.match(readme, /会话专用 `runtime\/<session>\.env\.kingdee`/)
assert.match(readme, /不要再配置或依赖全局 `runtime\/\.env\.kingdee` \/ `KINGDEE_ENV_PATH`/)
