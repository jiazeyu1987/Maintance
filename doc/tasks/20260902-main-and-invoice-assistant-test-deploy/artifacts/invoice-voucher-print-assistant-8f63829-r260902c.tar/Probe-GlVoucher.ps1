[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [string]$OrganizationNumber = '881',
    [string]$AccountBookNumber = '002',
    [string]$VoucherNumber = '1510',
    [string]$InvoiceNumber = '',
    [int]$Year = 0,
    [int]$Period = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$settings = @{}
foreach ($line in Get-Content -LiteralPath $EnvPath -Encoding UTF8) {
    if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') { $settings[$Matches[1]] = $Matches[2].Trim() }
}
$root = ([string]$settings.KINGDEE_BASE_URL).TrimEnd('/')
if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) { $root += '/K3Cloud' }
$root += '/'
$authPath = [string]$settings.KINGDEE_AUTH_PATH
if ([string]::IsNullOrWhiteSpace($authPath)) { $authPath = 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc' }
$login = Invoke-WebRequest -UseBasicParsing -Method Post -Uri ($root + $authPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{ acctID=[string]$settings.KINGDEE_ACCT_ID; username=[string]$settings.KINGDEE_USERNAME; password=[string]$settings.KINGDEE_PASSWORD; lcid='2052' } `
    -SessionVariable session -TimeoutSec 30
$loginBody = $login.Content | ConvertFrom-Json
$headers = @{}
if ($loginBody.Context.SessionId) { $headers.SessionId = [string]$loginBody.Context.SessionId }
if ($loginBody.KDSVCSessionId) { $headers.KDSVCSessionId = [string]$loginBody.KDSVCSessionId }

$query = @{
    FormId = 'GL_VOUCHER'
    FieldKeys = 'FVOUCHERID,FBillNo,FVOUCHERGROUPNO,FVOUCHERGROUPID.FNUMBER,FVOUCHERGROUPID.FNAME,FYEAR,FPERIOD,FDATE,FEXPLANATION,FACCBOOKORGID.FNUMBER,FACCOUNTBOOKID.FNUMBER'
    FilterString = if ($Year -gt 0 -and $Period -gt 0) {
        "FACCBOOKORGID.FNUMBER='$OrganizationNumber' AND FACCOUNTBOOKID.FNUMBER='$AccountBookNumber' AND FYEAR=$Year AND FPERIOD=$Period AND FVOUCHERGROUPNO=$VoucherNumber"
    } elseif (-not [string]::IsNullOrWhiteSpace($InvoiceNumber)) {
        "FACCBOOKORGID.FNUMBER='$OrganizationNumber' AND FEXPLANATION LIKE '%$($InvoiceNumber.Replace("'", "''"))%'"
    } elseif ($AccountBookNumber -eq '*') {
        "FACCBOOKORGID.FNUMBER='$OrganizationNumber' AND FVOUCHERGROUPNO=$VoucherNumber"
    } else {
        "FACCBOOKORGID.FNUMBER='$OrganizationNumber' AND FACCOUNTBOOKID.FNUMBER='$AccountBookNumber' AND FVOUCHERGROUPNO=$VoucherNumber"
    }
    OrderString = 'FYEAR ASC,FPERIOD ASC,FVOUCHERGROUPID.FNUMBER ASC'
    TopRowCount = 0
    StartRow = 0
    Limit = 2000
}
$body = @{ data = ($query | ConvertTo-Json -Depth 8 -Compress) } | ConvertTo-Json -Compress
$rows = Invoke-RestMethod -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.ExecuteBillQuery.common.kdsvc') `
    -ContentType 'application/json;charset=UTF-8' -Body $body -WebSession $session -Headers $headers -TimeoutSec 60
$rows | ConvertTo-Json -Depth 15
