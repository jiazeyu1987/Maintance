from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path


HERE = Path(__file__).resolve().parent
if sys.platform == "win32":
    sys.path.insert(0, str(HERE / "vendor"))

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A5, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, Table, TableStyle


FONT_REGULAR = "VoucherCN"
FONT_BOLD = "VoucherCNBold"


def register_fonts() -> None:
    candidates = [
        (
            Path("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc"),
            Path("/usr/share/fonts/truetype/wqy/wqy-microhei.ttc"),
        ),
        (
            HERE / "fonts" / "NotoSansCJKsc-Regular.otf",
            HERE / "fonts" / "NotoSansCJKsc-Bold.otf",
        ),
        (
            Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
            Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
        ),
        (
            Path(r"C:\Windows\Fonts\simsun.ttc"),
            Path(r"C:\Windows\Fonts\simhei.ttf"),
        ),
        (
            Path(r"C:\Windows\Fonts\msyh.ttc"),
            Path(r"C:\Windows\Fonts\msyhbd.ttc"),
        ),
    ]
    for regular, bold in candidates:
        if regular.is_file() and bold.is_file():
            try:
                regular_options = {"subfontIndex": 0} if regular.suffix.lower() == ".ttc" else {}
                bold_options = {"subfontIndex": 0} if bold.suffix.lower() == ".ttc" else {}
                pdfmetrics.registerFont(TTFont(FONT_REGULAR, str(regular), **regular_options))
                pdfmetrics.registerFont(TTFont(FONT_BOLD, str(bold), **bold_options))
                return
            except Exception:
                continue
    raise RuntimeError("Chinese fonts were not found on this computer.")


def localized_date(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""

    # Kingdee may return an ISO timestamp or a date formatted with the
    # application server's regional settings.  Always normalize it before
    # drawing so the voucher never falls back to an English 11/10/2025 date.
    candidates = [text, text.replace("Z", "+00:00")]
    for candidate in candidates:
        try:
            parsed = datetime.fromisoformat(candidate)
            return f"{parsed.year} 年 {parsed.month} 月 {parsed.day} 日"
        except ValueError:
            pass

    date_part = text.split("T", 1)[0].split(" ", 1)[0].strip()
    for date_format in (
        "%m/%d/%Y",
        "%Y/%m/%d",
        "%Y-%m-%d",
        "%Y.%m.%d",
        "%Y年%m月%d日",
    ):
        try:
            parsed = datetime.strptime(date_part, date_format)
            return f"{parsed.year} 年 {parsed.month} 月 {parsed.day} 日"
        except ValueError:
            pass

    return text[:10]


def money(value: object, blank_zero: bool = False) -> str:
    amount = Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if blank_zero and amount == 0:
        return ""
    return f"{amount:,.2f}"


CN_DIGITS = "零壹贰叁肆伍陆柒捌玖"
SMALL_UNITS = ("", "拾", "佰", "仟")
GROUP_UNITS = ("", "万", "亿", "兆")


def section_to_cn(section: int) -> str:
    if section == 0:
        return ""
    result = ""
    zero_pending = False
    unit_index = 0
    while section:
        digit = section % 10
        if digit == 0:
            if result:
                zero_pending = True
        else:
            prefix = CN_DIGITS[digit] + SMALL_UNITS[unit_index]
            if zero_pending:
                result = "零" + result
                zero_pending = False
            result = prefix + result
        unit_index += 1
        section //= 10
    return result


def integer_to_cn(value: int) -> str:
    if value == 0:
        return CN_DIGITS[0]
    groups: list[int] = []
    number = value
    while number:
        groups.append(number % 10000)
        number //= 10000

    result = ""
    previous_group = 0
    for index in range(len(groups) - 1, -1, -1):
        section = groups[index]
        if section == 0:
            previous_group = section
            continue
        if result and (section < 1000 or previous_group == 0):
            if not result.endswith("零"):
                result += "零"
        result += section_to_cn(section) + GROUP_UNITS[index]
        previous_group = section
    return result.rstrip("零")


def financial_upper(value: object) -> str:
    amount = Decimal(str(value or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if amount < 0:
        return "负" + financial_upper(-amount)
    fen_total = int(amount * 100)
    integer, fraction = divmod(fen_total, 100)
    jiao, fen = divmod(fraction, 10)
    result = integer_to_cn(integer) + "元"
    if jiao == 0 and fen == 0:
        return result + "整"
    if jiao:
        result += CN_DIGITS[jiao] + "角"
    elif integer:
        result += "零"
    if fen:
        result += CN_DIGITS[fen] + "分"
    return result


def safe_text(value: object) -> str:
    return str(value or "").strip()


def build_pdf(data: dict, output_path: Path) -> dict:
    register_fonts()
    entries = list(data.get("Entries") or [])
    if not entries:
        raise RuntimeError("ERP voucher data contains no printable entries.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    page_size = landscape(A5)
    page_width, page_height = page_size

    pdf = canvas.Canvas(str(output_path), pagesize=page_size, pageCompression=1)
    pdf.setTitle(
        f"凭证{safe_text(data.get('VoucherNumber'))}_ERP自动生成"
    )
    pdf.setAuthor("发票凭证号改名工具")
    pdf.setSubject("从 ERP 凭证数据生成并用于配套发票连续打印")

    body_style = ParagraphStyle(
        "voucher-body",
        fontName=FONT_REGULAR,
        fontSize=9,
        leading=10.5,
        alignment=TA_LEFT,
        wordWrap="CJK",
    )
    body_center = ParagraphStyle(
        "voucher-body-center",
        parent=body_style,
        alignment=TA_CENTER,
    )
    body_right = ParagraphStyle(
        "voucher-body-right",
        parent=body_style,
        alignment=TA_RIGHT,
    )
    header_style = ParagraphStyle(
        "voucher-header",
        parent=body_center,
        fontName=FONT_BOLD,
        fontSize=10,
        leading=12,
    )

    content_width = 190 * mm
    col_widths = [
        52 * mm,
        40 * mm,
        40 * mm,
        29 * mm,
        29 * mm,
    ]
    entry_area_height = 65 * mm
    minimum_entry_height = 13 * mm

    def build_entry_layout(entry: dict) -> dict:
        values = [
            safe_text(entry.get("Explanation")),
            safe_text(entry.get("AccountFullName"))
            or safe_text(entry.get("AccountName")),
            safe_text(entry.get("DetailText")),
            money(entry.get("Debit"), blank_zero=True),
            money(entry.get("Credit"), blank_zero=True),
        ]
        # Start with the normal readable size. Only unusually long ERP content
        # is reduced, in small steps, until the complete row fits one A5 page.
        for font_size in (9, 8.5, 8, 7.5, 7, 6.5, 6, 5.5, 5, 4.5):
            leading = max(font_size + 1.2, font_size * 1.18)
            left_style = ParagraphStyle(
                f"voucher-entry-left-{font_size}",
                fontName=FONT_REGULAR,
                fontSize=font_size,
                leading=leading,
                alignment=TA_LEFT,
                wordWrap="CJK",
            )
            right_style = ParagraphStyle(
                f"voucher-entry-right-{font_size}",
                parent=left_style,
                alignment=TA_RIGHT,
            )
            cells = [
                Paragraph(values[0], left_style),
                Paragraph(values[1], left_style),
                Paragraph(values[2], left_style),
                Paragraph(values[3], right_style),
                Paragraph(values[4], right_style),
            ]
            cell_heights = [
                cell.wrap(max(1, width - 5), entry_area_height)[1]
                for cell, width in zip(cells, col_widths)
            ]
            required_height = max(
                minimum_entry_height,
                max(cell_heights, default=0) + 4,
            )
            if required_height <= entry_area_height:
                return {
                    "Cells": cells,
                    "Height": required_height,
                    "FontSize": font_size,
                }
        raise RuntimeError("ERP 凭证单行内容过长，无法完整排入一张 A5 纸。")

    entry_layouts = [build_entry_layout(entry) for entry in entries]
    page_entry_layouts: list[list[dict]] = []
    current_page: list[dict] = []
    current_height = 0.0
    for layout in entry_layouts:
        row_height = float(layout["Height"])
        if current_page and current_height + row_height > entry_area_height + 0.1:
            page_entry_layouts.append(current_page)
            current_page = []
            current_height = 0.0
        current_page.append(layout)
        current_height += row_height
    if current_page:
        page_entry_layouts.append(current_page)
    page_count = len(page_entry_layouts)

    voucher_number = safe_text(data.get("VoucherNumber"))
    group_name = safe_text(data.get("VoucherGroupName")) or safe_text(
        data.get("VoucherGroupNumber")
    )
    organization = safe_text(data.get("OrganizationName"))
    date_text = localized_date(safe_text(data.get("Date")))
    debit_total = Decimal(str(data.get("DebitTotal") or 0))
    credit_total = Decimal(str(data.get("CreditTotal") or 0))
    attachment_count = int(data.get("AttachmentCount") or 0)
    for page_index, page_layouts in enumerate(page_entry_layouts):
        pdf.setFillColor(colors.black)
        pdf.setFont(FONT_BOLD, 20)
        pdf.drawCentredString(page_width / 2, page_height - 12 * mm, "记 账 凭 证")
        pdf.setLineWidth(0.9)
        pdf.line(65 * mm, page_height - 20 * mm, page_width - 65 * mm, page_height - 20 * mm)

        pdf.setFont(FONT_REGULAR, 10.5)
        pdf.drawCentredString(page_width / 2, page_height - 27 * mm, date_text)
        pdf.setFont(FONT_REGULAR, 8.5)
        pdf.drawString(8 * mm, page_height - 37 * mm, f"公司名称：{organization}")
        pdf.drawRightString(
            page_width - 9 * mm,
            page_height - 37 * mm,
            f"第 {page_index + 1}/{page_count} 页    {group_name}  {voucher_number}",
        )

        table_rows: list[list[object]] = [
            [
                Paragraph("摘要", header_style),
                Paragraph("会 计 科 目", header_style),
                "",
                Paragraph("借 方", header_style),
                Paragraph("贷 方", header_style),
            ],
            [
                "",
                Paragraph("一级科目", header_style),
                Paragraph("明细科目", header_style),
                "",
                "",
            ],
        ]
        entry_row_heights = [float(layout["Height"]) for layout in page_layouts]
        for layout in page_layouts:
            table_rows.append(list(layout["Cells"]))

        unused_entry_height = entry_area_height - sum(entry_row_heights)
        if unused_entry_height > 0.5:
            table_rows.append(["", "", "", "", ""])
            entry_row_heights.append(unused_entry_height)
        table_rows.append(
            [
                Paragraph("合      计", header_style),
                Paragraph(
                    financial_upper(debit_total),
                    ParagraphStyle(
                        "voucher-total-upper",
                        parent=body_center,
                        fontSize=8.5,
                        leading=10,
                    ),
                ),
                "",
                Paragraph(money(debit_total), body_right),
                Paragraph(money(credit_total), body_right),
            ]
        )

        table = Table(
            table_rows,
            colWidths=col_widths,
            rowHeights=[10 * mm, 7 * mm] + entry_row_heights + [8 * mm],
        )
        table.setStyle(
            TableStyle(
                [
                    ("GRID", (0, 0), (-1, -1), 0.85, colors.black),
                    ("SPAN", (0, 0), (0, 1)),
                    ("SPAN", (1, 0), (2, 0)),
                    ("SPAN", (3, 0), (3, 1)),
                    ("SPAN", (4, 0), (4, 1)),
                    ("SPAN", (1, -1), (2, -1)),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("LEFTPADDING", (0, 0), (-1, -1), 1.5),
                    ("RIGHTPADDING", (0, 0), (-1, -1), 1.5),
                    ("TOPPADDING", (0, 0), (-1, -1), 1),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
                ]
            )
        )
        table_x = 8 * mm
        # Lift the table to reduce the unused band below the company/page line.
        # This also leaves a safer printable margin for the footer on A5 paper.
        table_y = page_height - 132 * mm
        table.wrapOn(pdf, content_width, 91 * mm)
        table.drawOn(pdf, table_x, table_y)

        attachment_x = table_x + content_width + 2.5 * mm
        attachment_y = table_y + 53 * mm
        pdf.setFont(FONT_REGULAR, 8)
        for offset, label in enumerate(("附", "件", str(attachment_count), "张")):
            pdf.drawCentredString(
                attachment_x,
                attachment_y - offset * 7 * mm,
                label,
            )

        pdf.setFont(FONT_REGULAR, 9)
        footer_y = 7 * mm
        footer_items = [
            f"会计主管：{safe_text(data.get('Poster'))}",
            f"复核：{safe_text(data.get('Checker'))}",
            f"制单：{safe_text(data.get('Creator'))}",
        ]
        positions = [12 * mm, 82 * mm, 151 * mm]
        for x, label in zip(positions, footer_items):
            pdf.drawString(x, footer_y, label)
        pdf.showPage()

    pdf.save()
    return {
        "OutputPath": str(output_path),
        "VoucherNumber": voucher_number,
        "EntryCount": len(entries),
        "PageCount": page_count,
        "DebitTotal": money(debit_total),
        "CreditTotal": money(credit_total),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    input_path = Path(args.input).resolve()
    output_path = Path(args.output).resolve()
    data = json.loads(input_path.read_text(encoding="utf-8"))
    result = build_pdf(data, output_path)
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
