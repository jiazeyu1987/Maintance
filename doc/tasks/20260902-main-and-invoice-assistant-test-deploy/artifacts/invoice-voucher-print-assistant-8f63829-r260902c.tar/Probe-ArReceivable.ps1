[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [Parameter(Mandatory = $true)][string]$BillNumber,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$settings = @{}
foreach ($line in Get-Content -LiteralPath $EnvPath -Encoding UTF8) {
    if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') {
        $settings[$Matches[1]] = $Matches[2].Trim()
    }
}
$root = ([string]$settings.KINGDEE_BASE_URL).TrimEnd('/')
if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) {
    $root += '/K3Cloud'
}
$root += '/'
$authPath = [string]$settings.KINGDEE_AUTH_PATH
if ([string]::IsNullOrWhiteSpace($authPath)) {
    $authPath = 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc'
}
$login = Invoke-WebRequest -UseBasicParsing -Method Post -Uri ($root + $authPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{
        acctID = [string]$settings.KINGDEE_ACCT_ID
        username = [string]$settings.KINGDEE_USERNAME
        password = [string]$settings.KINGDEE_PASSWORD
        lcid = if ($settings.KINGDEE_LCID) { [string]$settings.KINGDEE_LCID } else { '2052' }
    } -SessionVariable session -TimeoutSec 30
$loginBody = $login.Content | ConvertFrom-Json
if (-not ($loginBody.LoginResultType -eq 1 -or $loginBody.IsSuccessByAPI -eq $true)) {
    throw 'ERP login failed.'
}
$headers = @{}
if ($loginBody.Context.SessionId) { $headers.SessionId = [string]$loginBody.Context.SessionId }
if ($loginBody.KDSVCSessionId) { $headers.KDSVCSessionId = [string]$loginBody.KDSVCSessionId }

$switchResponse = Invoke-WebRequest -UseBasicParsing -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc') `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{ data = '{"OrgNumber":"881"}' } `
    -WebSession $session -Headers $headers -TimeoutSec 30
$switchBody = $switchResponse.Content | ConvertFrom-Json
if ($switchBody.Result.ResponseStatus -and -not $switchBody.Result.ResponseStatus.IsSuccess) {
    throw 'ERP organization switch failed.'
}

$viewData = @{
    Number = $BillNumber
    Id = ''
    CreateOrgId = 0
} | ConvertTo-Json -Compress
$body = @{
    formid = 'AR_receivable'
    data = $viewData
} | ConvertTo-Json -Compress
$result = Invoke-RestMethod -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.View.common.kdsvc') `
    -ContentType 'application/json;charset=UTF-8' -Body $body `
    -WebSession $session -Headers $headers -TimeoutSec 60
$result | ConvertTo-Json -Depth 50 | Set-Content -LiteralPath $OutputPath -Encoding UTF8

$queryUri = $root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.ExecuteBillQuery.common.kdsvc'
$candidateFields = @(
    'FVOUCHERNO',
    'FVOUCHERNUMBER',
    'FVOUCHERGROUPNO',
    'F_VOUCHERNO',
    'FBUSINESSNO',
    'FSOURCEBILLNO',
    'F_PAEZ_Text',
    'FACCTSYSTEMID_VchInfo.FName',
    'FBOOKID_VchInfo.FName',
    'FBIZVOUCHERID_VchInfo.FBillNo',
    'FVOUCHERGROUPID_VchInfo.FName',
    'FVOUCHERGROUPNO_VCHINFO',
    'FVOUCHERBILLNO_VCHINFO',
    'FVOUCHERYEARPERIOD_VCHINFO',
    'FVOUCHERCREATORID_VchInfo.Name',
    'FVOUCHERDATE_VCHINFO'
)
$candidateResults = foreach ($candidate in $candidateFields) {
    $query = @{
        FormId = 'AR_receivable'
        FieldKeys = "FID,FBillNo,FDATE,F_PAEZ_Text,$candidate"
        FilterString = "FBillNo='$($BillNumber.Replace("'", "''"))'"
        OrderString = ''
        TopRowCount = 0
        StartRow = 0
        Limit = 10
    }
    $queryBody = @{
        data = ($query | ConvertTo-Json -Depth 8 -Compress)
    } | ConvertTo-Json -Compress
    try {
        $rows = Invoke-RestMethod -Method Post -Uri $queryUri `
            -ContentType 'application/json;charset=UTF-8' -Body $queryBody `
            -WebSession $session -Headers $headers -TimeoutSec 60
        [pscustomobject]@{ Field = $candidate; Response = $rows }
    }
    catch {
        [pscustomobject]@{ Field = $candidate; Error = $_.Exception.Message }
    }
}
$candidateResults | ConvertTo-Json -Depth 15 | Set-Content `
    -LiteralPath ($OutputPath + '.fields.json') -Encoding UTF8

$voucherQuery = @{
    FormId = 'GL_VOUCHER'
    FieldKeys = 'FVOUCHERID,FBillNo,FVOUCHERGROUPNO,FVOUCHERGROUPID.FNUMBER,FVOUCHERGROUPID.FNAME,FDATE,FEXPLANATION'
    FilterString = "FYEAR=2026 AND FPERIOD=7 AND FACCBOOKORGID.FNUMBER='881' AND FACCOUNTBOOKID.FNUMBER='002' AND FVOUCHERGROUPNO=1510"
    OrderString = 'FVOUCHERGROUPID.FNUMBER ASC'
    TopRowCount = 0
    StartRow = 0
    Limit = 100
}
$voucherBody = @{
    data = ($voucherQuery | ConvertTo-Json -Depth 8 -Compress)
} | ConvertTo-Json -Compress
$voucherRows = Invoke-RestMethod -Method Post -Uri $queryUri `
    -ContentType 'application/json;charset=UTF-8' -Body $voucherBody `
    -WebSession $session -Headers $headers -TimeoutSec 60
$voucherJson = $voucherRows | ConvertTo-Json -Depth 15
$voucherJson | Set-Content -LiteralPath ($OutputPath + '.voucher.json') -Encoding UTF8
Write-Output $voucherJson

# Business vouchers link to receivables by either the bill header id or one of
# its detail-entry ids.  Query both forms here so an 881 receivable can be
# traced without relying on the HTML5 list's computed voucher column.
$sourceIds = @('259917', '843595', '843596', '843597', '843598')
$sourceIdFilter = (($sourceIds | ForEach-Object { "FSOURCEBILLID=$_" }) -join ' OR ')
$sourceFilters = @(
    "FSOURCEBILLNO='$($BillNumber.Replace("'", "''"))'",
    "FSOURCEBILLNO='881XSCKD119791'",
    "FYEAR=2026 AND FPERIOD=7 AND FVOUCHERGROUPNO=1510 AND FACCOUNTBOOKID.FNUMBER='002'",
    "FYEAR=2026 AND FPERIOD=7 AND FVOUCHERGROUPNO=1510",
    "FYEAR=2026 AND FPERIOD=7 AND FACCOUNTBOOKID.FNUMBER='002'",
    $sourceIdFilter
)
$businessVoucherResults = foreach ($formId in @('BAS_BusinessVoucher', 'BAS_BizVoucherLink')) {
    foreach ($filter in $sourceFilters) {
        $query = @{
            FormId = $formId
            FieldKeys = 'FBILLNO,FDATE,FVOUCHERGROUPID.FNUMBER,FVOUCHERGROUPID.FNAME,FVOUCHERGROUPNO,FGLVOUCHERID,FGLVOUCHERID.FBILLNO,FGLVOUCHERID.FVOUCHERGROUPNO,FSOURCEBILLKEY.FNAME,FSOURCEBILLNO,FSOURCEBILLID,FACCOUNTBOOKID.FNUMBER,FYEAR,FPERIOD,FEXPLANATION'
            FilterString = $filter
            OrderString = ''
            TopRowCount = 0
            StartRow = if ($filter -eq "FYEAR=2026 AND FPERIOD=7 AND FACCOUNTBOOKID.FNUMBER='002'") { 3250 } else { 0 }
            Limit = 100
        }
        $queryBody = @{ data = ($query | ConvertTo-Json -Depth 8 -Compress) } | ConvertTo-Json -Compress
        try {
            $rows = Invoke-RestMethod -Method Post -Uri $queryUri `
                -ContentType 'application/json;charset=UTF-8' -Body $queryBody `
                -WebSession $session -Headers $headers -TimeoutSec 60
            [pscustomobject]@{ FormId = $formId; Filter = $filter; Response = $rows }
        }
        catch {
            [pscustomobject]@{ FormId = $formId; Filter = $filter; Error = $_.Exception.Message }
        }
    }
}
$businessVoucherResults | ConvertTo-Json -Depth 20 | Set-Content `
    -LiteralPath ($OutputPath + '.business-vouchers.json') -Encoding UTF8
