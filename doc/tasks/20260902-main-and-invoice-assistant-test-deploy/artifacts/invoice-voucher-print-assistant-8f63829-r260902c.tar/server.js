import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const toolRoot = path.dirname(here);
const publicDirectory = path.join(here, 'public');
const templatePath = path.join(toolRoot, '发票凭证号改名模板.xlsx');
const importTemplatePath = path.join(toolRoot, '发票号导入模板.xlsx');
const selectFolderScript = path.join(here, 'Select-Folder.ps1');
const workflowScript = path.join(here, 'Invoke-BrowserWorkflow.ps1');
const uploadScript = path.join(here, 'Upload-InvoiceVoucherAttachments.ps1');
const voucherPrintDataScript = path.join(here, 'Get-ErpVoucherPrintData.ps1');
const receivableListQueryScript = path.join(
  here,
  'Query-ErpInvoiceVoucherMappings-List.py'
);
const extractInvoiceNumbersScript = path.join(here, 'Extract-InvoiceNumbers.py');
const generateVoucherPdfScript = path.join(here, 'Generate-ErpVoucherPdf.py');
const mergeInvoicePdfsScript = path.join(here, 'Merge-VoucherInvoicePdfs.py');
const resultRoot = path.join(toolRoot, '浏览器运行结果');
const uploadRoot = path.join(toolRoot, '服务器上传发票');
const statePath = path.join(resultRoot, '.last-result.json');
const defaultPdfDirectory =
  process.env.INVOICE_PDF_DIRECTORY || 'D:\\jijiejie\\2025.12月份发票 1708';
const kingdeeRuntimeDirectory = process.env.KINGDEE_RUNTIME_DIR || path.join(toolRoot, 'runtime');
const host =
  process.env.INVOICE_RENAMER_HOST ||
  (process.platform === 'win32' ? '127.0.0.1' : '0.0.0.0');
const FIXED_PORT = 18733;
const configuredPort = process.env.INVOICE_RENAMER_PORT;
if (configuredPort !== undefined && Number(configuredPort) !== FIXED_PORT) {
  throw new Error('Invoice voucher print assistant fixed port must be 18733.');
}
const port = FIXED_PORT;
const ticketValidateUrl = String(process.env.INVOICE_VOUCHER_PRINT_TICKET_VALIDATE_URL || '').trim();
const assistantSessionCookieName = 'invoice_voucher_print_session';
const assistantSessionHeaderName = 'x-invoice-voucher-print-session';
const assistantSessionQueryName = 'assistantSession';
const assistantSessionTtlSeconds = Number(
  process.env.INVOICE_VOUCHER_PRINT_SESSION_TTL_SECONDS || 4 * 60 * 60
);
const powershellCommand =
  process.env.POWERSHELL_COMMAND ||
  (process.platform === 'win32' ? 'powershell.exe' : 'pwsh');
const pythonCommand =
  process.env.PYTHON_COMMAND ||
  (process.platform === 'win32' ? 'python.exe' : 'python3');

fs.mkdirSync(resultRoot, { recursive: true });
fs.mkdirSync(uploadRoot, { recursive: true });
fs.mkdirSync(kingdeeRuntimeDirectory, { recursive: true });
cleanupStaleAssistantSessionEnvFiles();

let busy = false;
let lastResult = null;
const printPacks = new Map();
const uploadSessions = new Map();
const assistantSessions = new Map();

try {
  const savedResult = JSON.parse(fs.readFileSync(statePath, 'utf8'));
  if (
    savedResult &&
    savedResult.resultWorkbookPath &&
    fs.existsSync(savedResult.resultWorkbookPath)
  ) {
    lastResult = savedResult;
  }
} catch {
  lastResult = null;
}

function findLatestGeneratedFolder() {
  const rememberedPaths = [
    lastResult?.generatedFolderPath,
    lastResult?.summary?.GeneratedFolder,
  ].filter(Boolean);
  for (const rememberedPath of rememberedPaths) {
    if (fs.existsSync(rememberedPath) && fs.statSync(rememberedPath).isDirectory()) {
      return rememberedPath;
    }
  }

  const sourceDirectory = lastResult?.pdfDirectory || defaultPdfDirectory;
  if (!fs.existsSync(sourceDirectory) || !fs.statSync(sourceDirectory).isDirectory()) {
    return '';
  }
  return fs
    .readdirSync(sourceDirectory, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && entry.name.startsWith('凭证号命名后_'))
    .map((entry) => {
      const fullPath = path.join(sourceDirectory, entry.name);
      return { fullPath, modifiedAt: fs.statSync(fullPath).mtimeMs };
    })
    .sort((left, right) => right.modifiedAt - left.modifiedAt)[0]?.fullPath || '';
}

function sendJson(response, statusCode, payload) {
  const body = JSON.stringify(payload);
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  response.end(body);
}

function sendFile(response, filePath, contentType, downloadName = '') {
  if (!fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
    sendJson(response, 404, { ok: false, error: '文件不存在。' });
    return;
  }
  const headers = {
    'Content-Type': contentType,
    'Content-Length': fs.statSync(filePath).size,
    'Cache-Control': 'no-store',
  };
  if (downloadName) {
    headers['Content-Disposition'] =
      `attachment; filename*=UTF-8''${encodeURIComponent(downloadName)}`;
  }
  response.writeHead(200, headers);
  fs.createReadStream(filePath).pipe(response);
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function sendAssistantForbidden(response, message = '没有发票凭证打印权限，请从 ERP 系统入口重新进入。', statusCode = 403) {
  const body = `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>无权访问发票凭证打印助手</title>
  <style>
    body { margin: 0; min-height: 100vh; display: grid; place-items: center; font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; background: #f6f7f9; color: #1f2937; }
    main { width: min(520px, calc(100vw - 48px)); background: #fff; border: 1px solid #d9dee7; border-radius: 8px; padding: 28px; box-shadow: 0 16px 40px rgba(31, 41, 55, .08); }
    h1 { margin: 0 0 12px; font-size: 22px; font-weight: 700; }
    p { margin: 0; line-height: 1.7; color: #4b5563; }
  </style>
</head>
<body>
  <main>
    <h1>无权访问发票凭证打印助手</h1>
    <p>${escapeHtml(message)}</p>
  </main>
</body>
</html>`;
  response.writeHead(statusCode, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  response.end(body);
}

async function readJson(request) {
  const chunks = [];
  let length = 0;
  for await (const chunk of request) {
    length += chunk.length;
    if (length > 40 * 1024 * 1024) {
      throw new Error('请求内容过大。');
    }
    chunks.push(chunk);
  }
  const text = Buffer.concat(chunks).toString('utf8');
  return text ? JSON.parse(text) : {};
}

function parseCookies(cookieHeader) {
  const cookies = {};
  for (const pair of String(cookieHeader || '').split(';')) {
    const index = pair.indexOf('=');
    if (index <= 0) continue;
    const name = pair.slice(0, index).trim();
    const value = pair.slice(index + 1).trim();
    if (name) {
      cookies[name] = decodeURIComponent(value);
    }
  }
  return cookies;
}

function getAssistantSessionId(request, requestUrl) {
  const headerSession = request.headers[assistantSessionHeaderName];
  if (headerSession) {
    return String(Array.isArray(headerSession) ? headerSession[0] : headerSession).trim();
  }
  const querySession = requestUrl.searchParams.get(assistantSessionQueryName);
  if (querySession) {
    return querySession.trim();
  }
  return parseCookies(request.headers.cookie)[assistantSessionCookieName] || '';
}

function cleanupExpiredAssistantSessions() {
  const now = Date.now();
  for (const [sessionId, session] of assistantSessions.entries()) {
    if (!session || session.expiresAt <= now) {
      deleteAssistantSessionEnvFile(session?.kingdeeEnvPath);
      assistantSessions.delete(sessionId);
    }
  }
}

function getAssistantSession(request, requestUrl) {
  cleanupExpiredAssistantSessions();
  const sessionId = getAssistantSessionId(request, requestUrl);
  if (!sessionId) {
    return null;
  }
  return assistantSessions.get(sessionId) || null;
}

function normalizeKingdeeConfig(kingdeeConfig) {
  if (!kingdeeConfig || typeof kingdeeConfig !== 'object') {
    throw new Error('ERP 授权响应缺少金蝶配置快照。');
  }
  return {
    baseUrl: requireKingdeeConfigField(kingdeeConfig.baseUrl, 'baseUrl'),
    acctId: requireKingdeeConfigField(kingdeeConfig.acctId, 'acctId'),
    username: requireKingdeeConfigField(kingdeeConfig.username, 'username'),
    password: requireKingdeeConfigField(kingdeeConfig.password, 'password'),
    appId: requireKingdeeConfigField(kingdeeConfig.appId, 'appId'),
    signedData: requireKingdeeConfigField(kingdeeConfig.signedData, 'signedData'),
    timestamp: requireKingdeeConfigField(kingdeeConfig.timestamp, 'timestamp'),
    lcid: requireKingdeeConfigLcid(kingdeeConfig.lcid),
  };
}

function requireKingdeeConfigField(value, fieldName) {
  const text = String(value ?? '').trim();
  if (!text) {
    throw new Error(`ERP 授权响应缺少金蝶配置快照字段：${fieldName}`);
  }
  if (/[\r\n]/.test(text)) {
    throw new Error(`ERP 配置字段包含非法换行：${fieldName}`);
  }
  return text;
}

function requireKingdeeConfigLcid(value) {
  const lcid = Number(value);
  if (!Number.isInteger(lcid) || lcid <= 0) {
    throw new Error('ERP 授权响应缺少有效的语言 LCID。');
  }
  return String(lcid);
}

function buildKingdeeEnvContent(kingdeeConfig) {
  const entries = [
    ['KINGDEE_BASE_URL', kingdeeConfig.baseUrl],
    ['KINGDEE_ACCT_ID', kingdeeConfig.acctId],
    ['KINGDEE_USERNAME', kingdeeConfig.username],
    ['KINGDEE_PASSWORD', kingdeeConfig.password],
    ['KINGDEE_APP_ID', kingdeeConfig.appId],
    ['KINGDEE_SIGNED_DATA', kingdeeConfig.signedData],
    ['KINGDEE_TIMESTAMP', kingdeeConfig.timestamp],
    ['KINGDEE_LCID', kingdeeConfig.lcid],
  ];
  return entries.map(([key, value]) => `${key}=${value}`).join('\n') + '\n';
}

function writeKingdeeEnvFile(sessionId, kingdeeConfig) {
  const runtimeRoot = path.resolve(kingdeeRuntimeDirectory);
  const envPath = path.join(runtimeRoot, `${sessionId}.env.kingdee`);
  const relative = path.relative(runtimeRoot, envPath);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error('ERP 配置文件路径无效。');
  }
  fs.mkdirSync(runtimeRoot, { recursive: true });
  fs.writeFileSync(envPath, buildKingdeeEnvContent(kingdeeConfig), {
    encoding: 'utf8',
    mode: 0o600,
  });
  return envPath;
}

function deleteAssistantSessionEnvFile(envPath) {
  if (!envPath) {
    return;
  }
  const runtimeRoot = path.resolve(kingdeeRuntimeDirectory);
  const resolvedEnvPath = path.resolve(envPath);
  const relative = path.relative(runtimeRoot, resolvedEnvPath);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
    return;
  }
  try {
    fs.rmSync(resolvedEnvPath, { force: true });
  } catch (error) {
    console.warn(`ERP 会话配置文件清理失败：${resolvedEnvPath}，${error.message}`);
  }
}

function cleanupStaleAssistantSessionEnvFiles() {
  const runtimeRoot = path.resolve(kingdeeRuntimeDirectory);
  try {
    for (const item of fs.readdirSync(runtimeRoot, { withFileTypes: true })) {
      if (item.isFile() && /^[0-9a-f-]{36}\.env\.kingdee$/i.test(item.name)) {
        deleteAssistantSessionEnvFile(path.join(runtimeRoot, item.name));
      }
    }
  } catch (error) {
    console.warn(`ERP 会话配置目录清理失败：${runtimeRoot}，${error.message}`);
  }
}

function requireAssistantKingdeeEnvPath(assistantSession) {
  const envPath = String(assistantSession?.kingdeeEnvPath || '').trim();
  if (!envPath) {
    throw new Error('ERP会话配置缺失，请从 ERP 系统入口重新进入发票凭证打印助手。');
  }
  const runtimeRoot = path.resolve(kingdeeRuntimeDirectory);
  const resolvedEnvPath = path.resolve(envPath);
  const relative = path.relative(runtimeRoot, resolvedEnvPath);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error('ERP会话配置路径无效，请从 ERP 系统入口重新进入发票凭证打印助手。');
  }
  if (!fs.existsSync(resolvedEnvPath) || !fs.statSync(resolvedEnvPath).isFile()) {
    throw new Error('ERP会话配置文件不存在，请从 ERP 系统入口重新进入发票凭证打印助手。');
  }
  return resolvedEnvPath;
}

function createAssistantSession(validation) {
  cleanupExpiredAssistantSessions();
  const sessionId = randomUUID();
  const kingdeeConfig = normalizeKingdeeConfig(validation.kingdeeConfig);
  const kingdeeEnvPath = writeKingdeeEnvFile(sessionId, kingdeeConfig);
  assistantSessions.set(sessionId, {
    userId: validation.userId,
    permission: validation.permission,
    kingdeeConfig,
    kingdeeEnvPath,
    expiresAt: Date.now() + assistantSessionTtlSeconds * 1000,
  });
  return sessionId;
}

async function validateAssistantTicket(ticket) {
  if (!ticketValidateUrl) {
    throw new Error('打印助手授权校验地址未配置，请配置 INVOICE_VOUCHER_PRINT_TICKET_VALIDATE_URL。');
  }
  const validateResponse = await fetch(ticketValidateUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ticket }),
  });
  if (!validateResponse.ok) {
    throw new Error(`ERP 授权校验失败：HTTP ${validateResponse.status}`);
  }
  const data = await validateResponse.json();
  if (data?.code !== 0) {
    return { valid: false, reason: data?.msg || 'erp_rejected' };
  }
  return data.data || { valid: false, reason: 'empty_response' };
}

async function handleAssistantAuthCallback(request, response, requestUrl) {
  const ticket = String(requestUrl.searchParams.get('ticket') || '').trim();
  if (!ticket) {
    sendAssistantForbidden(response, '没有取得 ERP 授权票据，请从 ERP 系统入口重新进入。');
    return;
  }
  let validation;
  try {
    validation = await validateAssistantTicket(ticket);
  } catch (error) {
    sendAssistantForbidden(response, error.message, 503);
    return;
  }
  if (!validation.valid) {
    sendAssistantForbidden(response, '没有发票凭证打印权限，请从 ERP 系统入口重新进入。');
    return;
  }

  let sessionId;
  try {
    sessionId = createAssistantSession(validation);
  } catch (error) {
    sendAssistantForbidden(response, String(error?.message || error), 503);
    return;
  }
  response.writeHead(302, {
    Location: `/?${assistantSessionQueryName}=${encodeURIComponent(sessionId)}`,
    'Set-Cookie':
      `${assistantSessionCookieName}=${encodeURIComponent(sessionId)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${assistantSessionTtlSeconds}`,
    'Cache-Control': 'no-store',
  });
  response.end();
}

function safeUploadDirectory(sessionId) {
  if (!/^[0-9a-f-]{36}$/i.test(String(sessionId || ''))) {
    throw new Error('发票上传会话无效，请重新选择文件夹。');
  }
  const directory = path.resolve(uploadRoot, sessionId);
  const relative = path.relative(path.resolve(uploadRoot), directory);
  if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) {
    throw new Error('发票上传目录无效。');
  }
  return directory;
}

function cleanupOldUploadDirectories() {
  const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
  for (const entry of fs.readdirSync(uploadRoot, { withFileTypes: true })) {
    if (!entry.isDirectory() || !/^[0-9a-f-]{36}$/i.test(entry.name)) continue;
    const directory = safeUploadDirectory(entry.name);
    if (fs.statSync(directory).mtimeMs < cutoff) {
      fs.rmSync(directory, { recursive: true, force: true });
      uploadSessions.delete(entry.name);
    }
  }
}

function createUploadSession(payload) {
  cleanupOldUploadDirectories();
  const expectedCount = Number(payload.fileCount || 0);
  const expectedBytes = Number(payload.totalBytes || 0);
  if (!Number.isInteger(expectedCount) || expectedCount < 1 || expectedCount > 5000) {
    throw new Error('请选择包含 1 至 5000 个 PDF 的文件夹。');
  }
  if (!Number.isFinite(expectedBytes) || expectedBytes < 1 || expectedBytes > 20 * 1024 ** 3) {
    throw new Error('所选 PDF 文件总大小无效或超过 20 GB。');
  }
  const sessionId = randomUUID();
  const directory = safeUploadDirectory(sessionId);
  fs.mkdirSync(directory, { recursive: false });
  uploadSessions.set(sessionId, {
    directory,
    expectedCount,
    expectedBytes,
    uploadedCount: 0,
    uploadedBytes: 0,
    completed: false,
    createdAt: Date.now(),
  });
  return { sessionId, directory };
}

async function saveUploadedInvoicePdf(request, sessionId, requestedName) {
  const session = uploadSessions.get(sessionId);
  if (!session || session.completed) {
    throw new Error('发票上传会话已失效，请重新选择文件夹。');
  }
  const fileName = path.basename(String(requestedName || '')).trim();
  if (!fileName || fileName.length > 240 || !fileName.toLowerCase().endsWith('.pdf')) {
    throw new Error('只能上传扩展名为 .pdf 的发票文件。');
  }
  if (session.uploadedCount >= session.expectedCount) {
    throw new Error('上传的 PDF 数量超过所选文件夹中的数量。');
  }
  const contentLength = Number(request.headers['content-length'] || 0);
  if (contentLength > 150 * 1024 * 1024) {
    throw new Error(`PDF 文件过大：${fileName}`);
  }
  const filePath = path.join(session.directory, fileName);
  let handle;
  let created = false;
  let size = 0;
  try {
    handle = fs.openSync(filePath, 'wx');
    created = true;
    for await (const chunk of request) {
      size += chunk.length;
      if (size > 150 * 1024 * 1024) {
        throw new Error(`PDF 文件超过 150 MB：${fileName}`);
      }
      fs.writeSync(handle, chunk);
    }
    fs.closeSync(handle);
    handle = null;
    const signature = Buffer.alloc(5);
    const readHandle = fs.openSync(filePath, 'r');
    fs.readSync(readHandle, signature, 0, 5, 0);
    fs.closeSync(readHandle);
    if (signature.toString('ascii') !== '%PDF-') {
      throw new Error(`文件不是有效的 PDF：${fileName}`);
    }
  } catch (error) {
    if (handle !== undefined && handle !== null) {
      try { fs.closeSync(handle); } catch {}
    }
    if (created) {
      try { fs.rmSync(filePath, { force: true }); } catch {}
    }
    throw error;
  }
  session.uploadedCount += 1;
  session.uploadedBytes += size;
  return {
    fileName,
    uploadedCount: session.uploadedCount,
    expectedCount: session.expectedCount,
  };
}

function completeUploadSession(sessionId) {
  const session = uploadSessions.get(sessionId);
  if (!session) {
    throw new Error('发票上传会话已失效，请重新选择文件夹。');
  }
  if (session.uploadedCount !== session.expectedCount) {
    throw new Error(
      `PDF 尚未全部上传：已上传 ${session.uploadedCount} 个，共 ${session.expectedCount} 个。`
    );
  }
  session.completed = true;
  return {
    sessionId,
    directory: session.directory,
    fileCount: session.uploadedCount,
    totalBytes: session.uploadedBytes,
  };
}

function normalizeOnlineInvoiceNumbers(value) {
  const source = Array.isArray(value)
    ? value
    : String(value || '').split(/[\s,，、;；/／]+/);
  const seen = new Set();
  const invoiceNumbers = [];
  const invalidInvoiceNumbers = [];
  for (const item of source) {
    const invoiceNumber = String(item || '').trim();
    if (!invoiceNumber || seen.has(invoiceNumber)) continue;
    seen.add(invoiceNumber);
    if (!/^\d{20}$/.test(invoiceNumber)) {
      invalidInvoiceNumbers.push(invoiceNumber);
      continue;
    }
    invoiceNumbers.push(invoiceNumber);
  }
  if (invoiceNumbers.length + invalidInvoiceNumbers.length > 5000) {
    throw new Error('一次最多在线填写 5000 个发票号。');
  }
  return { invoiceNumbers, invalidInvoiceNumbers };
}

function validateRunRequest(payload) {
  const businessMonth = String(payload.businessMonth || '').trim();
  const organizationNumber = String(payload.organizationNumber || '').trim();
  const accountBookNumber = String(payload.accountBookNumber || '011').trim();
  const voucherGroupNumber = String(payload.voucherGroupNumber || 'PZZ9').trim();
  const salesOrganization = String(payload.salesOrganization || '').trim();
  const pdfDirectory = path.resolve(String(payload.pdfDirectory || '').trim());
  const mode = 'preview';
  const inputWorkbookName = path.basename(
    String(payload.inputWorkbookName || '已填写发票号模板.xlsx').trim()
  );
  const inputWorkbookBase64 = String(payload.inputWorkbookBase64 || '');
  const normalizedInvoiceInput = normalizeOnlineInvoiceNumbers(payload.invoiceNumbers);
  const invoiceNumbers = normalizedInvoiceInput.invoiceNumbers;
  const invalidInvoiceNumbers = Array.from(new Set([
    ...normalizedInvoiceInput.invalidInvoiceNumbers,
    ...(Array.isArray(payload.invalidInvoiceNumbers)
      ? payload.invalidInvoiceNumbers.map((value) => String(value || '').trim()).filter(Boolean)
      : []),
  ]));

  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(businessMonth)) {
    throw new Error('业务月份必须为 yyyy-MM，例如 2025-12。');
  }
  if (!organizationNumber || !accountBookNumber || !voucherGroupNumber) {
    throw new Error('ERP组织编码、账簿编码和凭证字都不能为空。');
  }
  if (!fs.existsSync(pdfDirectory) || !fs.statSync(pdfDirectory).isDirectory()) {
    throw new Error(`PDF 文件夹不存在：${pdfDirectory}`);
  }
  let inputWorkbookBytes = Buffer.alloc(0);
  if (invoiceNumbers.length === 0) {
    if (!inputWorkbookName.toLowerCase().endsWith('.xlsx')) {
      throw new Error('请在线填写发票号。');
    }
    if (!inputWorkbookBase64 || inputWorkbookBase64.length > 7 * 1024 * 1024) {
      throw new Error('请在线填写至少一个发票号。');
    }
    inputWorkbookBytes = Buffer.from(inputWorkbookBase64, 'base64');
    if (
      inputWorkbookBytes.length < 4 ||
      inputWorkbookBytes[0] !== 0x50 ||
      inputWorkbookBytes[1] !== 0x4b
    ) {
      throw new Error('所选文件不是有效的 Excel .xlsx 文件。');
    }
  }
  return {
    businessMonth,
    organizationNumber,
    accountBookNumber,
    voucherGroupNumber,
    salesOrganization,
    pdfDirectory,
    mode,
    inputWorkbookName,
    inputWorkbookBytes,
    invoiceNumbers,
    invalidInvoiceNumbers,
  };
}

function runPowerShellFile(scriptPath, argumentsList) {
  return new Promise((resolve, reject) => {
    const child = spawn(
      powershellCommand,
      [
        '-NoProfile',
        ...(process.platform === 'win32' ? ['-ExecutionPolicy', 'Bypass'] : []),
        '-File',
        scriptPath,
        ...argumentsList,
      ],
      { windowsHide: true, cwd: toolRoot }
    );
    const stdout = [];
    const stderr = [];
    child.stdout.on('data', (chunk) => stdout.push(chunk));
    child.stderr.on('data', (chunk) => stderr.push(chunk));
    child.on('error', reject);
    child.on('close', (code) => {
      const decoder = new TextDecoder(process.platform === 'win32' ? 'gbk' : 'utf-8');
      const output = decoder.decode(Buffer.concat(stdout)).trim();
      const errorOutput = decoder.decode(Buffer.concat(stderr)).trim();
      if (code !== 0) {
        reject(new Error(errorOutput || output || `程序退出代码：${code}`));
        return;
      }
      resolve({ output, errorOutput });
    });
  });
}

function runPowerShell(argumentsList) {
  return runPowerShellFile(workflowScript, argumentsList);
}

function runPythonFile(scriptPath, argumentsList, actionName) {
  return new Promise((resolve, reject) => {
    const child = spawn(
      pythonCommand,
      [scriptPath, ...argumentsList],
      { windowsHide: true, cwd: here }
    );
    const stdout = [];
    const stderr = [];
    child.stdout.on('data', (chunk) => stdout.push(chunk));
    child.stderr.on('data', (chunk) => stderr.push(chunk));
    child.on('error', (error) => {
      reject(
        new Error(
          error.code === 'ENOENT'
            ? `未找到 Python，无法${actionName}。`
            : error.message
        )
      );
    });
    child.on('close', (code) => {
      const output = Buffer.concat(stdout).toString('utf8').trim();
      const errorOutput = Buffer.concat(stderr).toString('utf8').trim();
      if (code !== 0) {
        reject(new Error(errorOutput || output || `${actionName}程序退出代码：${code}`));
        return;
      }
      resolve({ output, errorOutput });
    });
  });
}

function runPythonMerge(argumentsList) {
  return runPythonFile(mergeInvoicePdfsScript, argumentsList, '合并 PDF');
}

function selectFolder(initialPath) {
  if (process.platform !== 'win32') {
    return Promise.reject(
      new Error('服务器版使用服务器上的发票目录，无需在网页中选择文件夹。')
    );
  }
  return new Promise((resolve, reject) => {
    const child = spawn(
      'powershell.exe',
      [
        '-NoProfile',
        '-STA',
        '-ExecutionPolicy',
        'Bypass',
        '-File',
        selectFolderScript,
        '-InitialPath',
        String(initialPath || ''),
      ],
      { windowsHide: false, cwd: toolRoot }
    );
    const stdout = [];
    const stderr = [];
    child.stdout.on('data', (chunk) => stdout.push(chunk));
    child.stderr.on('data', (chunk) => stderr.push(chunk));
    child.on('error', reject);
    child.on('close', (code) => {
      const selectedPath = Buffer.concat(stdout).toString('utf8').trim();
      const errorOutput = new TextDecoder('gbk').decode(Buffer.concat(stderr)).trim();
      if (code === 2) {
        resolve({ cancelled: true, path: '' });
        return;
      }
      if (code !== 0) {
        reject(new Error(errorOutput || `文件夹选择器退出代码：${code}`));
        return;
      }
      if (!selectedPath || !fs.existsSync(selectedPath) || !fs.statSync(selectedPath).isDirectory()) {
        reject(new Error('没有取得有效的文件夹路径。'));
        return;
      }
      resolve({ cancelled: false, path: selectedPath });
    });
  });
}

async function runWorkflow(payload, assistantSession) {
  const kingdeeEnvPath = requireAssistantKingdeeEnvPath(assistantSession);
  if (process.platform !== 'win32' || payload.invoiceNumbers.length > 0) {
    return runLinuxWorkflow(payload, kingdeeEnvPath);
  }
  const timestamp = new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, '')
    .slice(0, 14);
  const jobId = `${timestamp}_${Math.random().toString(16).slice(2, 8)}`;
  const jobDirectory = path.join(resultRoot, jobId);
  fs.mkdirSync(jobDirectory, { recursive: true });
  const generatedFolderPath =
    payload.mode === 'generate'
      ? path.join(payload.pdfDirectory, `凭证号命名后_${jobId}`)
      : '';

  const inputWorkbookPath = path.join(jobDirectory, payload.inputWorkbookName);
  const workingWorkbookPath = path.join(jobDirectory, '运行输入.xlsx');
  const summaryJsonPath = path.join(jobDirectory, '处理汇总.json');
  const resultWorkbookName =
    payload.mode === 'generate' ? '生成文件夹结果.xlsx' : '预览结果.xlsx';
  const resultWorkbookPath = path.join(
    jobDirectory,
    resultWorkbookName
  );
  fs.writeFileSync(inputWorkbookPath, payload.inputWorkbookBytes);

  const args = [
    '-TemplatePath', templatePath,
    '-InputWorkbookPath', inputWorkbookPath,
    '-WorkingWorkbookPath', workingWorkbookPath,
    '-ResultWorkbookPath', resultWorkbookPath,
    '-BusinessMonth', payload.businessMonth,
    '-OrganizationNumber', payload.organizationNumber,
    '-AccountBookNumber', payload.accountBookNumber,
    '-VoucherGroupNumber', payload.voucherGroupNumber,
    '-SalesOrganization', payload.salesOrganization,
    '-PdfDirectory', payload.pdfDirectory,
    '-EnvPath', kingdeeEnvPath,
    '-SummaryJsonPath', summaryJsonPath,
  ];
  if (payload.mode === 'generate') {
    args.push('-GenerateFolder', '-GeneratedFolderPath', generatedFolderPath);
  }

  let execution;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    try {
      execution = await runPowerShell(args);
      break;
    } catch (error) {
      const message = String(error?.message || error);
      const isExcelDisconnected =
        message.includes('RPC_E_DISCONNECTED') ||
        message.includes('0x80010108') ||
        message.includes('对象已与其客户端断开连接');
      if (!isExcelDisconnected || attempt === 3) {
        throw error;
      }

      for (const retryFile of [workingWorkbookPath, resultWorkbookPath, summaryJsonPath]) {
        try {
          fs.rmSync(retryFile, { force: true });
        } catch {
        }
      }
      if (
        generatedFolderPath &&
        path.dirname(generatedFolderPath) === payload.pdfDirectory &&
        path.basename(generatedFolderPath).startsWith('凭证号命名后_')
      ) {
        try {
          fs.rmSync(generatedFolderPath, { recursive: true, force: true });
        } catch {
        }
      }
      await new Promise((resolve) => setTimeout(resolve, attempt * 800));
    }
  }
  if (!fs.existsSync(resultWorkbookPath)) {
    throw new Error('程序已结束，但没有生成结果工作簿。');
  }
  if (!fs.existsSync(summaryJsonPath)) {
    throw new Error('程序已结束，但没有生成处理汇总。');
  }
  const summary = JSON.parse(fs.readFileSync(summaryJsonPath, 'utf8'));

  lastResult = {
    jobId,
    mode: payload.mode,
    resultWorkbookPath,
    resultWorkbookName: path.basename(resultWorkbookPath),
    jobDirectory,
    pdfDirectory: payload.pdfDirectory,
    generatedFolderPath,
    summary,
    output: execution.output,
    createdAt: new Date().toISOString(),
  };
  fs.writeFileSync(statePath, JSON.stringify(lastResult, null, 2), 'utf8');
  return lastResult;
}

function buildLinuxMappings(invoiceNumbers, erpResult, pdfDirectory) {
  const erpItems = Array.isArray(erpResult?.Items) ? erpResult.Items : [];
  const erpByInvoice = new Map(
    erpItems.map((item) => [String(item?.InvoiceNumber || '').trim(), item])
  );
  const sourceFilesByInvoice = new Map();
  for (const entry of fs.readdirSync(pdfDirectory, { withFileTypes: true })) {
    if (!entry.isFile() || !entry.name.toLowerCase().endsWith('.pdf')) continue;
    const match = entry.name.match(/^dzfp_(\d{8,30})(?:_|$)/i);
    if (!match) continue;
    if (!sourceFilesByInvoice.has(match[1])) {
      sourceFilesByInvoice.set(match[1], []);
    }
    sourceFilesByInvoice.get(match[1]).push(entry.name);
  }

  return invoiceNumbers.map((rawInvoiceNumber) => {
    const invoiceNumber = String(rawInvoiceNumber).trim();
    const erpItem = erpByInvoice.get(invoiceNumber);
    const voucherNumbers = Array.isArray(erpItem?.VoucherNumbers)
      ? erpItem.VoucherNumbers.map((value) => String(value).trim()).filter(Boolean)
      : [];
    const files = sourceFilesByInvoice.get(invoiceNumber) || [];
    let note = '';
    if (voucherNumbers.length === 0) {
      note = 'ERP 中未找到对应凭证号。';
    } else if (voucherNumbers.length > 1) {
      note = `ERP 中找到多个凭证号：${voucherNumbers.join('、')}。`;
    } else if (files.length === 0) {
      note = '未找到以 dzfp_发票号 开头的 PDF 文件。';
    } else if (files.length > 1) {
      note = `找到 ${files.length} 个同号 PDF，无法确定打印哪一个。`;
    }
    const success = !note;
    return {
      InvoiceNumber: invoiceNumber,
      VoucherNumber: voucherNumbers.length === 1 ? voucherNumbers[0] : '',
      Success: success,
      Status: success ? '成功' : '需检查',
      FileStatus: success ? '已找到原发票' : '需检查',
      ProcessingResult: success ? '可生成打印包' : '已跳过，不影响其他发票打印',
      Note: note,
    };
  });
}

async function runLinuxWorkflow(payload, kingdeeEnvPath) {
  const timestamp = new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, '')
    .slice(0, 14);
  const jobId = `${timestamp}_${Math.random().toString(16).slice(2, 8)}`;
  const jobDirectory = path.join(resultRoot, jobId);
  fs.mkdirSync(jobDirectory, { recursive: true });

  const onlineInputPath = path.join(jobDirectory, '在线填写发票号.json');
  const inputWorkbookPath = payload.invoiceNumbers.length > 0
    ? onlineInputPath
    : path.join(jobDirectory, payload.inputWorkbookName);
  const extractionPath = path.join(jobDirectory, '发票号提取结果.json');
  const invoiceNumbersPath = path.join(jobDirectory, '待查询发票号.json');
  const erpMappingJsonPath = path.join(jobDirectory, 'ERP直接查询结果.json');
  const summaryJsonPath = path.join(jobDirectory, '处理汇总.json');
  let extraction;
  let invoiceNumbers;
  if (payload.invoiceNumbers.length > 0) {
    invoiceNumbers = payload.invoiceNumbers;
    extraction = {
      Source: '在线填写',
      FilledRowCount: invoiceNumbers.length,
      UniqueInvoiceCount: invoiceNumbers.length,
      InvoiceNumbers: invoiceNumbers,
    };
    fs.writeFileSync(onlineInputPath, JSON.stringify(invoiceNumbers, null, 2), 'utf8');
    fs.writeFileSync(extractionPath, JSON.stringify(extraction, null, 2), 'utf8');
  } else {
    fs.writeFileSync(inputWorkbookPath, payload.inputWorkbookBytes);
    await runPythonFile(
      extractInvoiceNumbersScript,
      ['--input', inputWorkbookPath, '--output', extractionPath],
      '读取发票号模板'
    );
    extraction = JSON.parse(fs.readFileSync(extractionPath, 'utf8'));
    invoiceNumbers = Array.isArray(extraction?.InvoiceNumbers)
      ? extraction.InvoiceNumbers.map((value) => String(value).trim()).filter(Boolean)
      : [];
  }
  if (invoiceNumbers.length === 0) {
    throw new Error('请在线填写至少一个发票号。');
  }
  fs.writeFileSync(invoiceNumbersPath, JSON.stringify(invoiceNumbers), 'utf8');

  let execution;
  if (payload.organizationNumber === '881') {
    execution = await runPythonFile(
      receivableListQueryScript,
      [
        '--business-month', payload.businessMonth,
        '--organization-number', payload.organizationNumber,
        '--account-book-number', payload.accountBookNumber,
        '--voucher-group-number', payload.voucherGroupNumber,
        '--invoice-numbers', invoiceNumbersPath,
        '--output', erpMappingJsonPath,
        '--env', kingdeeEnvPath,
      ],
      '读取 ERP 应收单列表'
    );
  } else {
    execution = await runPowerShellFile(
      path.join(here, 'Query-ErpInvoiceVoucherMappings.ps1'),
      [
        '-BusinessMonth', payload.businessMonth,
        '-OrganizationNumber', payload.organizationNumber,
        '-AccountBookNumber', payload.accountBookNumber,
        '-VoucherGroupNumber', payload.voucherGroupNumber,
        '-InvoiceNumbersPath', invoiceNumbersPath,
        '-OutputJsonPath', erpMappingJsonPath,
        '-EnvPath', kingdeeEnvPath,
      ]
    );
  }
  if (!fs.existsSync(erpMappingJsonPath)) {
    throw new Error('ERP 查询已结束，但没有生成发票与凭证对应结果。');
  }
  const erpResult = JSON.parse(fs.readFileSync(erpMappingJsonPath, 'utf8'));
  const validMappings = buildLinuxMappings(
    invoiceNumbers,
    erpResult,
    payload.pdfDirectory
  );
  const invalidMappings = payload.invalidInvoiceNumbers.map((invoiceNumber) => ({
    InvoiceNumber: invoiceNumber,
    VoucherNumber: '',
    Success: false,
    Status: '需检查',
    FileStatus: '未处理',
    ProcessingResult: '已跳过，不影响其他发票打印',
    Note: '不是20位发票号，已跳过；其他有效号码仍会继续打印。',
  }));
  const mappings = [...validMappings, ...invalidMappings];
  const successfulCount = mappings.filter((item) => item.Success).length;
  const matchedCount = mappings.filter((item) => item.VoucherNumber).length;
  const summary = {
    Mode: 'preview',
    AllSuccessful: successfulCount === mappings.length,
    TotalInvoiceCount: mappings.length,
    SuccessfulCount: successfulCount,
    ProblemCount: mappings.length - successfulCount,
    MatchedCount: matchedCount,
    BusinessMonth: payload.businessMonth,
    GeneratedFolder: '',
    Mappings: mappings,
  };
  fs.writeFileSync(summaryJsonPath, JSON.stringify(summary, null, 2), 'utf8');

  lastResult = {
    jobId,
    mode: 'preview',
    resultWorkbookPath: inputWorkbookPath,
    resultWorkbookName: payload.invoiceNumbers.length > 0
      ? '在线填写发票号.json'
      : payload.inputWorkbookName,
    jobDirectory,
    pdfDirectory: payload.pdfDirectory,
    generatedFolderPath: '',
    summary,
    output:
      `在线读取：${extraction.FilledRowCount || invoiceNumbers.length} 个发票号；` +
      `自动去重后：${invoiceNumbers.length} 个唯一发票号。\n${execution.output}`,
    createdAt: new Date().toISOString(),
  };
  fs.writeFileSync(statePath, JSON.stringify(lastResult, null, 2), 'utf8');
  return lastResult;
}

function validateUploadRequest(payload) {
  const businessMonth = String(payload.businessMonth || '').trim();
  const organizationNumber = String(payload.organizationNumber || '').trim();
  const accountBookNumber = String(payload.accountBookNumber || '011').trim();
  const voucherGroupNumber = String(payload.voucherGroupNumber || 'PZZ9').trim();
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(businessMonth)) {
    throw new Error('业务月份必须为 yyyy-MM，例如 2025-12。');
  }
  if (!organizationNumber || !accountBookNumber || !voucherGroupNumber) {
    throw new Error('ERP 组织编码、账簿编码和凭证字都不能为空。');
  }
  if (!lastResult?.summary || !Array.isArray(lastResult.summary.Mappings)) {
    throw new Error('没有可用的匹配结果，请先生成命名后文件夹。');
  }
  const generatedFolderPath =
    lastResult.generatedFolderPath || lastResult.summary.GeneratedFolder || '';
  if (
    lastResult.mode !== 'generate' ||
    !generatedFolderPath ||
    !fs.existsSync(generatedFolderPath) ||
    !fs.statSync(generatedFolderPath).isDirectory()
  ) {
    throw new Error('当前只有预览结果。请先点击“生成命名后文件夹”，再上传到 ERP。');
  }
  return {
    businessMonth,
    organizationNumber,
    accountBookNumber,
    voucherGroupNumber,
  };
}

function buildPdfIndexes(directories) {
  return directories
    .filter((directory, index, values) => directory && values.indexOf(directory) === index)
    .filter((directory) => fs.existsSync(directory) && fs.statSync(directory).isDirectory())
    .map((directory) => ({
      directory,
      fileNames: fs
        .readdirSync(directory, { withFileTypes: true })
        .filter((entry) => entry.isFile() && entry.name.toLowerCase().endsWith('.pdf'))
        .map((entry) => entry.name),
    }));
}

function findRenamedPdf(indexes, invoiceNumber, voucherNumber) {
  const prefix = `${voucherNumber}_dzfp_${invoiceNumber}`.toLowerCase();
  for (const index of indexes) {
    const matches = index.fileNames.filter((name) => name.toLowerCase().startsWith(prefix));
    if (matches.length === 1) {
      return path.join(index.directory, matches[0]);
    }
    if (matches.length > 1) {
      return path.join(index.directory, `__multiple_matches__${voucherNumber}_${invoiceNumber}.pdf`);
    }
  }
  const fallbackDirectory = indexes[0]?.directory || lastResult.pdfDirectory || defaultPdfDirectory;
  return path.join(fallbackDirectory, `${voucherNumber}_dzfp_${invoiceNumber}__not_found.pdf`);
}

async function runErpUpload(payload, assistantSession) {
  const kingdeeEnvPath = requireAssistantKingdeeEnvPath(assistantSession);
  const timestamp = new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, '')
    .slice(0, 14);
  const jobId = `${timestamp}_erp_${Math.random().toString(16).slice(2, 8)}`;
  const jobDirectory = path.join(resultRoot, jobId);
  fs.mkdirSync(jobDirectory, { recursive: true });

  const successfulMappings = lastResult.summary.Mappings.filter(
    (item) => item?.Success && item.InvoiceNumber && item.VoucherNumber
  );
  if (successfulMappings.length === 0) {
    throw new Error('匹配结果中没有可以上传到 ERP 的发票。');
  }

  const indexes = buildPdfIndexes([
    lastResult.generatedFolderPath,
    lastResult.summary.GeneratedFolder,
  ]);
  if (indexes.length === 0) {
    throw new Error('没有找到改名后 PDF 所在文件夹。');
  }

  const manifestPath = path.join(jobDirectory, 'ERP附件上传输入.json');
  const summaryJsonPath = path.join(jobDirectory, 'ERP附件上传结果.json');
  const manifest = {
    BusinessMonth: payload.businessMonth,
    OrganizationNumber: payload.organizationNumber,
    AccountBookNumber: payload.accountBookNumber,
    VoucherGroupNumber: payload.voucherGroupNumber,
    Items: successfulMappings.map((item) => ({
      InvoiceNumber: String(item.InvoiceNumber),
      VoucherNumber: String(item.VoucherNumber),
      FilePath: findRenamedPdf(
        indexes,
        String(item.InvoiceNumber),
        String(item.VoucherNumber)
      ),
    })),
  };
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf8');

  const execution = await runPowerShellFile(uploadScript, [
    '-ManifestPath', manifestPath,
    '-SummaryJsonPath', summaryJsonPath,
    '-BusinessMonth', payload.businessMonth,
    '-OrganizationNumber', payload.organizationNumber,
    '-AccountBookNumber', payload.accountBookNumber,
    '-VoucherGroupNumber', payload.voucherGroupNumber,
    '-EnvPath', kingdeeEnvPath,
  ]);
  if (!fs.existsSync(summaryJsonPath)) {
    throw new Error('ERP 上传程序已结束，但没有生成上传结果。');
  }
  const uploadSummary = JSON.parse(fs.readFileSync(summaryJsonPath, 'utf8'));
  lastResult.erpUpload = uploadSummary;
  lastResult.erpUploadSummaryPath = summaryJsonPath;
  lastResult.erpUploadOutput = execution.output;
  fs.writeFileSync(statePath, JSON.stringify(lastResult, null, 2), 'utf8');
  return uploadSummary;
}

function parseVoucherNumbers(value) {
  const text = String(value || '').trim();
  if (!text) {
    throw new Error('请输入凭证号，例如 29、29,30,31 或 29-35。');
  }
  const tokens = text
    .replace(/[，；;、／/]/g, ',')
    .split(/[\s,]+/)
    .map((item) => item.trim())
    .filter(Boolean);
  const values = [];
  const seen = new Set();
  const addValue = (number) => {
    const normalized = String(Number(number));
    if (!seen.has(normalized)) {
      seen.add(normalized);
      values.push(normalized);
    }
  };

  for (const token of tokens) {
    const range = token.match(/^(\d+)\s*[-~至]\s*(\d+)$/);
    if (range) {
      const start = Number(range[1]);
      const end = Number(range[2]);
      if (end < start || end - start > 2000) {
        throw new Error(`凭证号范围无效或过大：${token}`);
      }
      for (let current = start; current <= end; current += 1) {
        addValue(current);
      }
      continue;
    }
    if (!/^\d+$/.test(token)) {
      throw new Error(`无法识别凭证号：${token}`);
    }
    addValue(token);
  }
  if (values.length > 2000) {
    throw new Error('一次最多处理 2000 个凭证号。');
  }
  return values;
}

function scanVoucherInvoiceFiles(pdfDirectory, voucherNumbers) {
  const entries = fs
    .readdirSync(pdfDirectory, { withFileTypes: true })
    .filter((entry) => entry.isFile() && entry.name.toLowerCase().endsWith('.pdf'));
  const groupedFiles = new Map(voucherNumbers.map((voucher) => [voucher, []]));

  for (const entry of entries) {
    const match = entry.name.match(/^(\d+)_dzfp_(\d{8,30})(?:_|$)/i);
    if (!match) {
      continue;
    }
    const voucherNumber = String(Number(match[1]));
    if (!groupedFiles.has(voucherNumber)) {
      continue;
    }
    groupedFiles.get(voucherNumber).push({
      VoucherNumber: voucherNumber,
      InvoiceNumber: match[2],
      FileName: entry.name,
      FilePath: path.join(pdfDirectory, entry.name),
      Size: fs.statSync(path.join(pdfDirectory, entry.name)).size,
    });
  }

  const groups = voucherNumbers.map((voucherNumber) => {
    const files = groupedFiles
      .get(voucherNumber)
      .sort((left, right) =>
        left.FileName.localeCompare(right.FileName, 'zh-CN', {
          numeric: true,
          sensitivity: 'base',
        })
      );
    return {
      VoucherNumber: voucherNumber,
      FileCount: files.length,
      Files: files,
    };
  });
  const files = groups.flatMap((group) => group.Files);
  return {
    PdfDirectory: pdfDirectory,
    VoucherNumbers: voucherNumbers,
    VoucherCount: voucherNumbers.length,
    MatchedVoucherCount: groups.filter((group) => group.FileCount > 0).length,
    MissingVoucherNumbers: groups
      .filter((group) => group.FileCount === 0)
      .map((group) => group.VoucherNumber),
    FileCount: files.length,
    TotalBytes: files.reduce((total, file) => total + file.Size, 0),
    Groups: groups,
    Files: files,
  };
}

function parsePrintSelection(value) {
  const text = String(value || '').trim();
  if (!text) {
    throw new Error('请输入本次要打印的发票号或凭证号。');
  }
  const tokens = text
    .replace(/[，；;、／/]/g, ',')
    .split(/[\s,]+/)
    .map((item) => item.trim())
    .filter(Boolean);
  const invoiceNumbers = new Set();
  const voucherNumbers = new Set();
  const orderedSelections = [];
  const invalidSelections = [];
  const addInvoiceNumber = (invoiceNumber) => {
    if (!invoiceNumbers.has(invoiceNumber)) {
      invoiceNumbers.add(invoiceNumber);
      orderedSelections.push({ Type: 'invoice', Value: invoiceNumber });
    }
  };
  const addVoucherNumber = (voucherNumber) => {
    const normalized = String(Number(voucherNumber));
    if (!voucherNumbers.has(normalized)) {
      voucherNumbers.add(normalized);
      orderedSelections.push({ Type: 'voucher', Value: normalized });
    }
  };

  for (const token of tokens) {
    const range = token.match(/^(\d{1,7})\s*[-~至]\s*(\d{1,7})$/);
    if (range) {
      const start = Number(range[1]);
      const end = Number(range[2]);
      if (end < start || end - start > 2000) {
        invalidSelections.push({ Value: token, Reason: '凭证号范围无效或过大，已跳过' });
        continue;
      }
      for (let current = start; current <= end; current += 1) {
        addVoucherNumber(current);
      }
      continue;
    }
    if (!/^\d+$/.test(token)) {
      invalidSelections.push({ Value: token, Reason: '无法识别该打印号码，已跳过' });
      continue;
    }
    if (token.length >= 8) {
      addInvoiceNumber(token);
    } else {
      addVoucherNumber(token);
    }
  }
  if (invoiceNumbers.size + voucherNumbers.size > 2000) {
    throw new Error('一次最多选择 2000 个发票号或凭证号。');
  }
  return { invoiceNumbers, voucherNumbers, orderedSelections, invalidSelections };
}

function scanMatchedInvoiceFiles(selectionValue) {
  const mappings = Array.isArray(lastResult?.summary?.Mappings)
    ? lastResult.summary.Mappings
    : [];
  if (mappings.length === 0) {
    throw new Error('还没有发票匹配结果。请先在线填写发票号并点击“一键查询并生成打印包”。');
  }

  const pdfDirectory = path.resolve(
    String(lastResult?.pdfDirectory || defaultPdfDirectory || '').trim()
  );
  if (!fs.existsSync(pdfDirectory) || !fs.statSync(pdfDirectory).isDirectory()) {
    throw new Error(`原发票 PDF 文件夹不存在：${pdfDirectory}`);
  }

  const selection = parsePrintSelection(selectionValue);
  const sourceFilesByInvoice = new Map();
  const entries = fs
    .readdirSync(pdfDirectory, { withFileTypes: true })
    .filter((entry) => entry.isFile() && entry.name.toLowerCase().endsWith('.pdf'));
  for (const entry of entries) {
    const match = entry.name.match(/^dzfp_(\d{8,30})(?:_|$)/i);
    if (!match) continue;
    const invoiceNumber = match[1];
    if (!sourceFilesByInvoice.has(invoiceNumber)) {
      sourceFilesByInvoice.set(invoiceNumber, []);
    }
    const filePath = path.join(pdfDirectory, entry.name);
    sourceFilesByInvoice.get(invoiceNumber).push({
      InvoiceNumber: invoiceNumber,
      FileName: entry.name,
      FilePath: filePath,
      Size: fs.statSync(filePath).size,
    });
  }

  const groupedFiles = new Map();
  const problemInvoices = selection.invalidSelections.map((item) => ({
    InvoiceNumber: item.Value,
    VoucherNumber: '',
    Reason: `${item.Reason}；其他有效号码继续打印。`,
  }));
  const matchedInvoiceSelections = new Set();
  const matchedVoucherSelections = new Set();
  const voucherBySelectedInvoice = new Map();
  const invoiceSelectionOrder = new Map(
    selection.orderedSelections
      .map((item, index) => [item, index])
      .filter(([item]) => item.Type === 'invoice')
      .map(([item, index]) => [item.Value, index])
  );
  for (const [mappingIndex, item] of mappings.entries()) {
    const invoiceNumber = String(item?.InvoiceNumber || '').trim();
    const voucherNumber = String(item?.VoucherNumber || '').trim();
    const normalizedVoucher = /^\d+$/.test(voucherNumber)
      ? String(Number(voucherNumber))
      : voucherNumber;
    const selectedByInvoice = selection.invoiceNumbers.has(invoiceNumber);
    const selectedByVoucher = selection.voucherNumbers.has(normalizedVoucher);
    if (!selectedByInvoice && !selectedByVoucher) {
      continue;
    }
    if (selectedByInvoice) matchedInvoiceSelections.add(invoiceNumber);
    if (selectedByVoucher) matchedVoucherSelections.add(normalizedVoucher);
    if (selectedByInvoice && normalizedVoucher) {
      voucherBySelectedInvoice.set(invoiceNumber, normalizedVoucher);
    }

    if (!item?.Success || !invoiceNumber || !voucherNumber) {
      problemInvoices.push({
        InvoiceNumber: invoiceNumber,
        VoucherNumber: voucherNumber,
        Reason: String(item?.Note || item?.Status || '未找到对应凭证号').trim(),
      });
      continue;
    }

    const matches = sourceFilesByInvoice.get(invoiceNumber) || [];
    if (matches.length !== 1) {
      problemInvoices.push({
        InvoiceNumber: invoiceNumber,
        VoucherNumber: voucherNumber,
        Reason:
          matches.length === 0
            ? '原发票文件夹中未找到对应 PDF'
            : `原发票文件夹中找到 ${matches.length} 个同号 PDF，无法确定打印哪一个`,
      });
      continue;
    }

    if (!groupedFiles.has(normalizedVoucher)) {
      groupedFiles.set(normalizedVoucher, []);
    }
    groupedFiles.get(normalizedVoucher).push({
      ...matches[0],
      VoucherNumber: normalizedVoucher,
      PrintOrder: selectedByInvoice
        ? invoiceSelectionOrder.get(invoiceNumber)
        : selection.orderedSelections.length + mappingIndex,
    });
  }

  for (const invoiceNumber of selection.invoiceNumbers) {
    if (!matchedInvoiceSelections.has(invoiceNumber)) {
      problemInvoices.push({
        InvoiceNumber: invoiceNumber,
        VoucherNumber: '',
        Reason: '本次在线填写的查询结果中没有这个发票号',
      });
    }
  }
  for (const voucherNumber of selection.voucherNumbers) {
    if (!matchedVoucherSelections.has(voucherNumber)) {
      problemInvoices.push({
        InvoiceNumber: '',
        VoucherNumber: voucherNumber,
        Reason: '本次在线填写的查询结果中没有属于这个凭证号的发票',
      });
    }
  }

  const orderedVoucherNumbers = [];
  const seenVouchers = new Set();
  for (const selectedItem of selection.orderedSelections) {
    const voucherNumber =
      selectedItem.Type === 'voucher'
        ? selectedItem.Value
        : voucherBySelectedInvoice.get(selectedItem.Value);
    if (
      voucherNumber &&
      groupedFiles.has(voucherNumber) &&
      !seenVouchers.has(voucherNumber)
    ) {
      seenVouchers.add(voucherNumber);
      orderedVoucherNumbers.push(voucherNumber);
    }
  }
  for (const voucherNumber of groupedFiles.keys()) {
    if (!seenVouchers.has(voucherNumber)) {
      seenVouchers.add(voucherNumber);
      orderedVoucherNumbers.push(voucherNumber);
    }
  }

  const groups = orderedVoucherNumbers.map((voucherNumber) => {
    const files = groupedFiles
      .get(voucherNumber)
      .sort((left, right) => left.PrintOrder - right.PrintOrder)
      .map(({ PrintOrder, ...file }) => file);
    return {
      VoucherNumber: voucherNumber,
      FileCount: files.length,
      Files: files,
    };
  });
  const files = groups.flatMap((group) => group.Files);
  return {
    PdfDirectory: pdfDirectory,
    VoucherNumbers: groups.map((group) => group.VoucherNumber),
    VoucherCount: groups.length,
    MatchedVoucherCount: groups.length,
    MissingVoucherNumbers: [],
    RequestedInvoiceNumbers: Array.from(selection.invoiceNumbers),
    RequestedVoucherNumbers: Array.from(selection.voucherNumbers),
    ProblemInvoiceCount: problemInvoices.length,
    ProblemInvoices: problemInvoices,
    FileCount: files.length,
    TotalBytes: files.reduce((total, file) => total + file.Size, 0),
    Groups: groups,
    Files: files,
  };
}

async function prepareVoucherInvoicePack(payload, assistantSession) {
  const kingdeeEnvPath = requireAssistantKingdeeEnvPath(assistantSession);
  const scan = scanMatchedInvoiceFiles(payload.selection);
  const voucherNumbers = scan.VoucherNumbers;
  if (scan.FileCount > 5000) {
    throw new Error('匹配到的发票超过 5000 个，请拆分成多次打印。');
  }
  if (payload.mode !== 'generate') {
    return { ...scan, Generated: false };
  }
  if (scan.FileCount === 0) {
    throw new Error('没有可以打印的发票，请先查看发票匹配失败原因。');
  }
  const businessMonth = String(payload.businessMonth || '').trim();
  const organizationNumber = String(payload.organizationNumber || '').trim();
  const accountBookNumber = String(payload.accountBookNumber || '').trim();
  const voucherGroupNumber = String(payload.voucherGroupNumber || '').trim();
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(businessMonth)) {
    throw new Error('业务月份必须使用 yyyy-MM 格式。');
  }
  if (!organizationNumber || !accountBookNumber || !voucherGroupNumber) {
    throw new Error('ERP 组织、账簿和凭证字不能为空。');
  }

  const timestamp = new Date()
    .toISOString()
    .replace(/[-:TZ.]/g, '')
    .slice(0, 14);
  const jobId = `${timestamp}_print_${Math.random().toString(16).slice(2, 8)}`;
  const jobDirectory = path.join(resultRoot, `凭证与发票打印包_${jobId}`);
  fs.mkdirSync(jobDirectory, { recursive: true });
  const manifestPath = path.join(jobDirectory, '打印包输入.json');
  const summaryPath = path.join(jobDirectory, '打印包汇总.json');
  const voucherLabel =
    voucherNumbers.length === 1
      ? voucherNumbers[0]
      : `${voucherNumbers[0]}-${voucherNumbers[voucherNumbers.length - 1]}_共${voucherNumbers.length}个凭证`;
  const outputPath = path.join(
    jobDirectory,
    `发票模板_${voucherLabel}_凭证与发票打印包.pdf`
  );
  const manifestItems = [];
  for (const group of scan.Groups) {
    const voucherNumber = group.VoucherNumber;
    const voucherDataPath = path.join(
      jobDirectory,
      `ERP凭证_${voucherNumber}_数据.json`
    );
    const voucherPdfPath = path.join(
      jobDirectory,
      `ERP凭证_${voucherNumber}.pdf`
    );
    await runPowerShellFile(voucherPrintDataScript, [
      '-BusinessMonth', businessMonth,
      '-OrganizationNumber', organizationNumber,
      '-AccountBookNumber', accountBookNumber,
      '-VoucherGroupNumber', voucherGroupNumber,
      '-VoucherNumber', voucherNumber,
      '-OutputJsonPath', voucherDataPath,
      '-EnvPath', kingdeeEnvPath,
    ]);
    await runPythonFile(
      generateVoucherPdfScript,
      ['--input', voucherDataPath, '--output', voucherPdfPath],
      `生成 ERP 凭证 ${voucherNumber} PDF`
    );
    if (!fs.existsSync(voucherPdfPath) || !fs.statSync(voucherPdfPath).isFile()) {
      throw new Error(`ERP 凭证 ${voucherNumber} PDF 生成完成后未找到文件。`);
    }
    manifestItems.push({
      Type: 'voucher',
      VoucherNumber: voucherNumber,
      FileName: path.basename(voucherPdfPath),
      FilePath: voucherPdfPath,
    });
    manifestItems.push(
      ...group.Files.map((item) => ({ ...item, Type: 'invoice' }))
    );
  }
  fs.writeFileSync(
    manifestPath,
    JSON.stringify({ Items: manifestItems }, null, 2),
    'utf8'
  );
  await runPythonMerge([
    '--manifest', manifestPath,
    '--output', outputPath,
    '--summary', summaryPath,
  ]);
  if (!fs.existsSync(outputPath) || !fs.statSync(outputPath).isFile()) {
    throw new Error('PDF 合并完成后未找到打印包。');
  }
  const mergeSummary = JSON.parse(fs.readFileSync(summaryPath, 'utf8'));
  const pack = {
    ...scan,
    ...mergeSummary,
    Generated: true,
    JobId: jobId,
    JobDirectory: jobDirectory,
    PackUrl: `/api/print-pack?jobId=${encodeURIComponent(jobId)}`,
  };
  printPacks.set(jobId, { outputPath, jobDirectory, pack });
  while (printPacks.size > 20) {
    const oldestKey = printPacks.keys().next().value;
    printPacks.delete(oldestKey);
  }
  return pack;
}

const server = http.createServer(async (request, response) => {
  const requestUrl = new URL(request.url || '/', `http://${host}:${port}`);

  try {
    if (request.method === 'GET' && requestUrl.pathname === '/favicon.ico') {
      response.writeHead(204);
      response.end();
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/auth/callback') {
      await handleAssistantAuthCallback(request, response, requestUrl);
      return;
    }
    const assistantSession = getAssistantSession(request, requestUrl);
    if (!assistantSession) {
      sendAssistantForbidden(response);
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/') {
      sendFile(response, path.join(publicDirectory, 'index.html'), 'text/html; charset=utf-8');
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/api/config') {
      sendJson(response, 200, {
        ok: true,
        busy,
        serverMode: process.platform !== 'win32',
        defaults: {
          businessMonth: lastResult?.summary?.BusinessMonth || '2025-12',
          organizationNumber: '892',
          accountBookNumber: '011',
          voucherGroupNumber: 'PZZ9',
          salesOrganization: '上海璞霖医疗器械有限公司',
          pdfDirectory: defaultPdfDirectory,
        },
        lastResult,
      });
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/api/template') {
      sendFile(
        response,
        importTemplatePath,
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        '发票号导入模板.xlsx'
      );
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/upload-session') {
      const session = createUploadSession(await readJson(request));
      sendJson(response, 200, { ok: true, ...session });
      return;
    }
    if (request.method === 'PUT' && requestUrl.pathname === '/api/upload-invoice-pdf') {
      const result = await saveUploadedInvoicePdf(
        request,
        requestUrl.searchParams.get('sessionId'),
        requestUrl.searchParams.get('name')
      );
      sendJson(response, 200, { ok: true, ...result });
      return;
    }
    if (
      request.method === 'POST' &&
      requestUrl.pathname === '/api/complete-upload-session'
    ) {
      const payload = await readJson(request);
      const result = completeUploadSession(String(payload.sessionId || ''));
      sendJson(response, 200, { ok: true, ...result });
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/run') {
      if (busy) {
        sendJson(response, 409, { ok: false, error: '程序正在处理上一项任务，请稍候。' });
        return;
      }
      const payload = validateRunRequest(await readJson(request));
      busy = true;
      try {
        const result = await runWorkflow(payload, assistantSession);
        sendJson(response, 200, { ok: true, result });
      } finally {
        busy = false;
      }
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/voucher-invoice-pack') {
      if (busy) {
        sendJson(response, 409, { ok: false, error: '程序正在处理上一项任务，请稍候。' });
        return;
      }
      const payload = await readJson(request);
      busy = true;
      try {
        const result = await prepareVoucherInvoicePack(payload, assistantSession);
        sendJson(response, 200, { ok: true, result });
      } finally {
        busy = false;
      }
      return;
    }
    if (request.method === 'GET' && requestUrl.pathname === '/api/print-pack') {
      const jobId = String(requestUrl.searchParams.get('jobId') || '');
      const printPack = printPacks.get(jobId);
      if (!printPack) {
        sendJson(response, 404, {
          ok: false,
          error: '打印包不存在或程序已经重新启动，请重新生成。',
        });
        return;
      }
      sendFile(response, printPack.outputPath, 'application/pdf');
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/select-folder') {
      const payload = await readJson(request);
      const selection = await selectFolder(payload.initialPath);
      sendJson(response, 200, { ok: true, ...selection });
      return;
    }
    if (request.method === 'POST' && requestUrl.pathname === '/api/shutdown') {
      sendJson(response, 200, { ok: true });
      setTimeout(() => server.close(() => process.exit(0)), 100);
      return;
    }
    sendJson(response, 404, { ok: false, error: '页面不存在。' });
  } catch (error) {
    sendJson(response, 400, {
      ok: false,
      error: String(error?.message || error),
    });
  }
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    process.exit(0);
  }
  throw error;
});

server.listen(port, host, () => {
  console.log(`Invoice renamer running at http://${host}:${port}/`);
});
