﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$BusinessMonth,
    [Parameter(Mandatory = $true)][string]$OrganizationNumber,
    [Parameter(Mandatory = $true)][string]$AccountBookNumber,
    [Parameter(Mandatory = $true)][string]$VoucherGroupNumber,
    [Parameter(Mandatory = $true)][string]$InvoiceNumbersPath,
    [Parameter(Mandatory = $true)][string]$OutputJsonPath,
    [Parameter(Mandatory = $true)][string]$EnvPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-DotEnv {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "ERP配置文件不存在：$Path"
    }
    $settings = @{}
    foreach ($line in Get-Content -LiteralPath $Path -Encoding UTF8) {
        if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') {
            $settings[$Matches[1]] = $Matches[2].Trim()
        }
    }
    return $settings
}

function Require-Setting {
    param([hashtable]$Settings, [string]$Name)
    $value = [string]$Settings[$Name]
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "ERP配置缺少：$Name"
    }
    return $value
}

function Get-ServiceRoot {
    param([string]$BaseUrl)
    $root = $BaseUrl.TrimEnd('/')
    if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) {
        $root += '/K3Cloud'
    }
    return $root + '/'
}

function Escape-FilterValue {
    param([string]$Value)
    return $Value.Replace("'", "''")
}

function Get-ResponseErrorMessage {
    param($Status)
    $messages = @(
        @($Status.Errors) |
            ForEach-Object { [string]$_.Message } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
    if ($messages.Count -eq 0) {
        return '金蝶未返回具体错误信息。'
    }
    return $messages -join '；'
}

function Invoke-KingdeeJson {
    param(
        [string]$Uri,
        [string]$Body,
        [Microsoft.PowerShell.Commands.WebRequestSession]$Session,
        [hashtable]$Headers
    )
    return Invoke-RestMethod `
        -Method Post `
        -Uri $Uri `
        -ContentType 'application/json;charset=UTF-8' `
        -Body $Body `
        -WebSession $Session `
        -Headers $Headers `
        -TimeoutSec 60
}

if ($BusinessMonth -notmatch '^(\d{4})-(0[1-9]|1[0-2])$') {
    throw '业务月份必须使用 yyyy-MM 格式。'
}
if (-not (Test-Path -LiteralPath $InvoiceNumbersPath -PathType Leaf)) {
    throw "发票号输入文件不存在：$InvoiceNumbersPath"
}

$year = [int]$Matches[1]
$period = [int]$Matches[2]
$rawInvoiceNumbers = Get-Content -LiteralPath $InvoiceNumbersPath -Encoding UTF8 -Raw |
    ConvertFrom-Json
$invoiceNumbers = @(
    @(
        foreach ($rawInvoiceNumber in @($rawInvoiceNumbers)) {
            $value = ([string]$rawInvoiceNumber).Trim()
            if ($value -match '^\d{8,30}$') {
                $value
            }
        }
    ) | Sort-Object -Unique
)
if ($invoiceNumbers.Count -eq 0) {
    throw '模板中没有可查询的有效发票号。'
}

$settings = Read-DotEnv -Path $EnvPath
$baseUrl = Require-Setting -Settings $settings -Name 'KINGDEE_BASE_URL'
$acctId = Require-Setting -Settings $settings -Name 'KINGDEE_ACCT_ID'
$username = Require-Setting -Settings $settings -Name 'KINGDEE_USERNAME'
$password = Require-Setting -Settings $settings -Name 'KINGDEE_PASSWORD'
$lcid = [string]$settings['KINGDEE_LCID']
if ([string]::IsNullOrWhiteSpace($lcid)) {
    $lcid = '2052'
}
$authPath = [string]$settings['KINGDEE_AUTH_PATH']
if ([string]::IsNullOrWhiteSpace($authPath)) {
    $authPath = 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc'
}
$switchOrgPath = [string]$settings['KINGDEE_SWITCH_ORG_PATH']
if ([string]::IsNullOrWhiteSpace($switchOrgPath)) {
    $switchOrgPath = 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc'
}
$serviceRoot = Get-ServiceRoot -BaseUrl $baseUrl

$loginResponse = Invoke-WebRequest `
    -UseBasicParsing `
    -Method Post `
    -Uri ($serviceRoot + $authPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{
        acctID = $acctId
        username = $username
        password = $password
        lcid = $lcid
    } `
    -SessionVariable kingdeeSession `
    -TimeoutSec 30
$loginBody = $loginResponse.Content | ConvertFrom-Json
if (-not ($loginBody.LoginResultType -eq 1 -or $loginBody.IsSuccessByAPI -eq $true)) {
    throw 'ERP登录失败，请检查本机ERP账号配置。'
}

$sessionHeaders = @{}
if ($null -ne $loginBody.Context -and $loginBody.Context.SessionId) {
    $sessionHeaders['SessionId'] = [string]$loginBody.Context.SessionId
}
if ($loginBody.KDSVCSessionId) {
    $sessionHeaders['KDSVCSessionId'] = [string]$loginBody.KDSVCSessionId
}

# ExecuteBillQuery uses the organization in the current ERP session for data
# permissions. Filtering by organization number alone is not sufficient: when
# the user selects organization 881 while the login session is still on 892,
# Kingdee returns an empty result even though the receivable is visible in 881.
$switchResponse = Invoke-WebRequest `
    -UseBasicParsing `
    -Method Post `
    -Uri ($serviceRoot + $switchOrgPath) `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{
        data = (@{ OrgNumber = $OrganizationNumber } | ConvertTo-Json -Compress)
    } `
    -WebSession $kingdeeSession `
    -Headers $sessionHeaders `
    -TimeoutSec 30
if ($switchResponse.Content) {
    try {
        $switchPayload = $switchResponse.Content | ConvertFrom-Json
        $switchStatus = $switchPayload.Result.ResponseStatus
        if ($null -ne $switchStatus -and -not $switchStatus.IsSuccess) {
            throw "ERP组织切换失败（$OrganizationNumber）：$(Get-ResponseErrorMessage -Status $switchStatus)"
        }
    }
    catch {
        if ($_.Exception.Message -like 'ERP组织切换失败*') {
            throw
        }
        # Some Kingdee versions return an empty/non-JSON body after a successful
        # switch. The subsequent query is the authoritative verification.
    }
}

$safeOrg = Escape-FilterValue $OrganizationNumber
$safeBook = Escape-FilterValue $AccountBookNumber
$safeGroup = Escape-FilterValue $VoucherGroupNumber
$baseFilter = (
    "FYEAR={0} AND FPERIOD={1} AND FACCBOOKORGID.FNUMBER='{2}' " +
    "AND FACCOUNTBOOKID.FNUMBER='{3}' AND FVOUCHERGROUPID.FNUMBER='{4}'"
) -f $year, $period, $safeOrg, $safeBook, $safeGroup

$maps = @{}
foreach ($invoiceNumber in $invoiceNumbers) {
    $maps[$invoiceNumber] = @{
        Rows = 0
        Vouchers = [System.Collections.Generic.HashSet[string]]::new(
            [System.StringComparer]::OrdinalIgnoreCase
        )
        BillNumbers = [System.Collections.Generic.HashSet[string]]::new(
            [System.StringComparer]::OrdinalIgnoreCase
        )
        Dates = [System.Collections.Generic.HashSet[string]]::new(
            [System.StringComparer]::OrdinalIgnoreCase
        )
    }
}

$queriedRows = 0
$batchSize = 40
for ($batchStart = 0; $batchStart -lt $invoiceNumbers.Count; $batchStart += $batchSize) {
    $batchEnd = [math]::Min($batchStart + $batchSize - 1, $invoiceNumbers.Count - 1)
    $batch = @($invoiceNumbers[$batchStart..$batchEnd])
    $invoiceFilter = (
        $batch |
            ForEach-Object {
                $safeInvoice = Escape-FilterValue $_
                "FEXPLANATION LIKE '%$safeInvoice%'"
            }
    ) -join ' OR '
    $startRow = 0
    $limit = 2000

    while ($true) {
        $voucherQuery = @{
            FormId = 'GL_VOUCHER'
            FieldKeys = 'FVOUCHERID,FBillNo,FVOUCHERGROUPNO,FDATE,FEXPLANATION'
            FilterString = "$baseFilter AND ($invoiceFilter)"
            OrderString = 'FVOUCHERGROUPNO ASC'
            TopRowCount = 0
            StartRow = $startRow
            Limit = $limit
        }
        $queryBody = @{
            data = ($voucherQuery | ConvertTo-Json -Depth 8 -Compress)
        } | ConvertTo-Json -Compress
        $rows = Invoke-KingdeeJson `
            -Uri ($serviceRoot + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.ExecuteBillQuery.common.kdsvc') `
            -Body $queryBody `
            -Session $kingdeeSession `
            -Headers $sessionHeaders

        $rowArray = @($rows)
        $firstRow = $null
        if ($rowArray.Count -gt 0) {
            $firstRow = $rowArray[0]
        }
        if ($null -ne $firstRow -and
            $firstRow -isnot [System.Array] -and
            $null -ne $firstRow.PSObject.Properties['Result']) {
            $status = $firstRow.Result.ResponseStatus
            if (-not $status.IsSuccess) {
                throw "ERP凭证查询失败：$(Get-ResponseErrorMessage -Status $status)"
            }
        }

        $validRowCount = 0
        foreach ($row in $rowArray) {
            if ($row -isnot [System.Array] -or $row.Count -lt 5) {
                continue
            }
            $validRowCount++
            $queriedRows++
            $voucherNumber = ([string]$row[2]).Trim()
            $dateText = ([string]$row[3]).Trim()
            $explanation = ([string]$row[4]).Trim()
            if ([string]::IsNullOrWhiteSpace($voucherNumber) -or
                [string]::IsNullOrWhiteSpace($explanation)) {
                continue
            }
            foreach ($invoiceNumber in $batch) {
                if ($explanation.IndexOf(
                    $invoiceNumber,
                    [System.StringComparison]::OrdinalIgnoreCase
                ) -lt 0) {
                    continue
                }
                $entry = $maps[$invoiceNumber]
                $entry.Rows++
                [void]$entry.Vouchers.Add($voucherNumber)
                if (-not [string]::IsNullOrWhiteSpace([string]$row[1])) {
                    [void]$entry.BillNumbers.Add(([string]$row[1]).Trim())
                }
                if (-not [string]::IsNullOrWhiteSpace($dateText)) {
                    [void]$entry.Dates.Add($dateText.Substring(0, [math]::Min(10, $dateText.Length)))
                }
            }
        }

        if ($validRowCount -lt $limit) {
            break
        }
        $startRow += $limit
    }
}

$items = @(
    foreach ($invoiceNumber in $invoiceNumbers) {
        $entry = $maps[$invoiceNumber]
        [pscustomobject]@{
            InvoiceNumber = $invoiceNumber
            Rows = $entry.Rows
            VoucherNumbers = @($entry.Vouchers | Sort-Object)
            BillNumbers = @($entry.BillNumbers | Sort-Object)
            Dates = @($entry.Dates | Sort-Object)
        }
    }
)
$summary = [ordered]@{
    Source = 'ERP_DIRECT'
    BusinessMonth = $BusinessMonth
    OrganizationNumber = $OrganizationNumber
    AccountBookNumber = $AccountBookNumber
    VoucherGroupNumber = $VoucherGroupNumber
    InputInvoiceCount = $invoiceNumbers.Count
    MatchedInvoiceCount = @($items | Where-Object { $_.VoucherNumbers.Count -gt 0 }).Count
    QueriedVoucherEntryRows = $queriedRows
    Items = $items
}
[System.IO.File]::WriteAllText(
    [System.IO.Path]::GetFullPath($OutputJsonPath),
    ($summary | ConvertTo-Json -Depth 8),
    [System.Text.UTF8Encoding]::new($false)
)

[pscustomobject]$summary
