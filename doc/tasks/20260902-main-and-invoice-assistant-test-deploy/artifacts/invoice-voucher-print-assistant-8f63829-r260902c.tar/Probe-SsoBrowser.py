import argparse
import asyncio
import base64
import gzip
import json
from pathlib import Path
from urllib.parse import parse_qs, quote, urlsplit

from playwright.async_api import async_playwright


def read_env(path: str) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw_line in Path(path).read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        result[key.strip()] = value.strip()
    return result


def decode_gzip_argument(value: str) -> str:
    return gzip.decompress(base64.b64decode(__import__("urllib.parse").parse.unquote(value))).decode("utf-8")


def encode_gzip_argument(value: str) -> str:
    compressed = gzip.compress(value.encode("utf-8"), mtime=0)
    return quote(base64.b64encode(compressed).decode("ascii"), safe="")


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", required=True)
    parser.add_argument("--form-id", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    env = read_env(args.env)
    base_url = env["KINGDEE_BASE_URL"].rstrip("/")
    if not base_url.lower().endswith("/k3cloud"):
        base_url += "/K3Cloud"
    dbid = env["KINGDEE_ACCT_ID"]
    username = env["KINGDEE_USERNAME"]
    appid = env["KINGDEE_APP_ID"]
    signeddata = env["KINGDEE_SIGNED_DATA"]
    timestamp = env["KINGDEE_TIMESTAMP"]
    login_arg = {
        "dbid": dbid,
        "username": username,
        "appid": appid,
        "signeddata": signeddata,
        "timestamp": timestamp,
        "lcid": env.get("KINGDEE_LCID", "2052"),
        "origintype": "SimPas",
        "entryrole": "",
        "formid": args.form_id,
        "formtype": "list",
        "pkid": "",
        "otherargs": "",
        "openmode": None,
        "loginthen": "",
    }
    encoded = base64.b64encode(
        json.dumps(login_arg, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    ).decode("ascii")
    login_url = f"{base_url}/html5/index.aspx?ud={quote(encoded)}"
    service_base_url = base_url[:-8] + "/k3cloud" if base_url.lower().endswith("/k3cloud") else base_url
    service_url = (
        f"{service_base_url}/Service.aspx?servicename=FormMetaDataService"
        f"&methodname=GetListMetadata&pageid={quote(args.form_id)}"
        f"&paramtype=url&paramdata=%5B%5D&dbid={quote(dbid)}"
        f"&lang={quote(env.get('KINGDEE_LCID', '2052'))}"
    )

    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(
            executable_path=r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            headless=True,
            args=["--disable-gpu", "--no-sandbox"],
        )
        context = await browser.new_context()
        page = await context.new_page()
        network_requests: list[dict[str, str | None]] = []
        network_responses: list[dict[str, str | int | None]] = []

        def record_request(request) -> None:
            url_lower = request.url.lower()
            if request.resource_type in {"xhr", "fetch", "script"} or "service.aspx" in url_lower:
                network_requests.append(
                    {
                        "method": request.method,
                        "url": request.url,
                        "postData": request.post_data,
                        "resourceType": request.resource_type,
                    }
                )

        async def record_response(response) -> None:
            if response.request.resource_type not in {"xhr", "fetch"}:
                return
            try:
                body = await response.text()
            except Exception:
                body = ""
            network_responses.append(
                {
                    "url": response.url,
                    "status": response.status,
                    "postData": response.request.post_data,
                    "body": body[:5_000_000],
                }
            )

        page.on("request", record_request)
        page.on("response", lambda response: asyncio.create_task(record_response(response)))
        await page.goto(login_url, wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(15000)
        target_org = "上海瑛泰医疗器械股份有限公司"
        await page.mouse.click(511, 23)
        await page.wait_for_timeout(1200)
        await page.screenshot(path=args.output + ".org-menu.png", full_page=True)
        org_locator = page.get_by_text(target_org, exact=False)
        org_count = await org_locator.count()
        await page.mouse.click(420, 96)
        await page.wait_for_timeout(12000)
        default_scheme = page.get_by_text("默认方案（个人）", exact=True)
        if await default_scheme.count():
            await default_scheme.first.click()
            await page.wait_for_timeout(8000)
        shared_scheme_name = "\u4e0a\u6d77\u745b\u6cf0\u6bdb\u5229\u5927\u8868\uff08\u5408\u5e76\uff09(\u674e\u5e72\u71d5\u5171\u4eab)"
        shared_scheme = page.get_by_text(shared_scheme_name, exact=True)
        shared_scheme_count = await shared_scheme.count()
        # Search the receivable list by the exact invoice number.  This avoids
        # the date restriction saved in the shared gross-profit scheme.
        invoice_filter_count = 0
        field_picker = page.locator(
            "input.k-input.defaultQuikerRowEmptyShow.kd-defaultQuikerRow-partFileds"
        ).first
        await field_picker.click()
        await page.wait_for_timeout(500)
        invoice_choices = page.locator("li.k-item:visible").filter(has_text="发票号")
        if await invoice_choices.count():
            await invoice_choices.last.click()
        value_input = page.locator("input[id*='FQKFILTERPANEL'][id$='_c']").last
        await value_input.fill("26312000004458897376")
        search_button = page.locator("a[id$='FQKFILTERPANEL_search']").last
        await search_button.click()
        await page.wait_for_timeout(15000)

        invoice_cell = page.get_by_text("26312000004458897376", exact=True)
        selected_row = False
        if await invoice_cell.count():
            await invoice_cell.first.click()
            selected_row = True
        else:
            if await shared_scheme.count():
                await shared_scheme.first.click()
                await page.wait_for_timeout(10000)
            # A visible row is enough to let the list form initialize the
            # voucher toolbar action.  The request is replayed below with the
            # target receivable FID, so the seed row itself is irrelevant.
            seed_row = page.locator("div[id$='FLIST-c'] tbody tr").first
            if await seed_row.count():
                await seed_row.click()
                selected_row = True
        if selected_row:
            voucher_menu = page.get_by_text("凭证", exact=True).filter(visible=True)
            if await voucher_menu.count():
                await voucher_menu.first.click()
                await page.wait_for_timeout(800)
                gl_action = page.get_by_text("查看总账凭证", exact=True).filter(visible=True)
                if await gl_action.count():
                    await gl_action.last.click()
                    await page.wait_for_timeout(8000)

        voucher_action_result = {"status": 0, "text": "No toolbar request was available."}
        toolbar_request = None
        for captured in reversed(network_requests):
            post_data = captured.get("postData")
            if not post_data or "DynamicFormService.Call.common.kdsvc" not in captured["url"]:
                continue
            try:
                envelope = json.loads(post_data)
                if decode_gzip_argument(envelope.get("ap2", "")) == "ToolBarItemClick":
                    toolbar_request = (captured["url"], envelope)
                    break
            except Exception:
                continue
        if toolbar_request:
            toolbar_url, envelope = toolbar_request
            action_args = [
                "BILLMENU_TOOLBAR",
                "tbViewGlVoucher",
                [
                    {"_GetMessage_": True},
                    {
                        "FLIST": {
                            "fieldKey": "SELECTED",
                            "row": 0,
                            "selRows": "259917",
                            "isClientNewRow": False,
                            "clientNewRows": "",
                        }
                    },
                ],
            ]
            envelope["ap3"] = encode_gzip_argument(
                quote(json.dumps(action_args, ensure_ascii=False, separators=(",", ":")), safe="")
            )
            voucher_action_result = await page.evaluate(
                """async ({url, body}) => {
                    const response = await fetch(url, {
                        method: 'POST',
                        credentials: 'include',
                        headers: {'Content-Type': 'application/json;charset=UTF-8'},
                        body,
                    });
                    return {status: response.status, text: await response.text()};
                }""",
                {"url": toolbar_url, "body": json.dumps(envelope, ensure_ascii=False, separators=(",", ":"))},
            )
        action_text = voucher_action_result["text"]
        try:
            if action_text.startswith("H4sI"):
                action_text = gzip.decompress(base64.b64decode(action_text)).decode("utf-8")
        except Exception:
            pass
        Path(args.output + ".voucher-action.txt").write_text(action_text, encoding="utf-8")
        await page.screenshot(path=args.output + ".png", full_page=True)
        frame_info = []
        for frame in page.frames:
            try:
                body_text = (await frame.locator("body").inner_text(timeout=3000))[:1000]
            except Exception:
                body_text = ""
            frame_info.append({"url": frame.url, "bodyText": body_text})
        dom_fields = await page.evaluate(
            """() => Array.from(document.querySelectorAll('*'))
                .map((element) => {
                    const attrs = {};
                    for (const attr of Array.from(element.attributes || [])) {
                        if (/field|key|column|header|cell|model|index/i.test(attr.name)) {
                            attrs[attr.name] = attr.value;
                        }
                    }
                    return {
                        tag: element.tagName,
                        text: String(element.innerText || element.textContent || '').trim().slice(0, 120),
                        id: element.id || '',
                        className: String(element.className || '').slice(0, 160),
                        attrs,
                    };
                })
                .filter((item) => Object.keys(item.attrs).length > 0 || /grid|header|cell/i.test(item.className))
                .slice(0, 10000)"""
        )
        global_matches = await page.evaluate(
            """() => {
                const pattern = /VCHINFO|VOUCHERGROUPNO|VOUCHERBILLNO|F_PAEZ_Text/i;
                const matches = [];
                const seen = new WeakSet();
                const stack = [];
                for (const key of Object.getOwnPropertyNames(window)) {
                    let value;
                    try { value = window[key]; } catch (_) { continue; }
                    stack.push({ value, path: `window.${key}`, depth: 0 });
                }
                let visited = 0;
                while (stack.length && visited < 250000 && matches.length < 5000) {
                    const item = stack.pop();
                    const value = item.value;
                    visited += 1;
                    if (typeof value === 'string') {
                        if (pattern.test(value)) matches.push({ path: item.path, value: value.slice(0, 500) });
                        continue;
                    }
                    if (!value || typeof value !== 'object' || item.depth >= 7) continue;
                    if (value === window || value instanceof Node || seen.has(value)) continue;
                    seen.add(value);
                    let keys;
                    try { keys = Object.keys(value).slice(0, 1000); } catch (_) { continue; }
                    for (const key of keys) {
                        let child;
                        try { child = value[key]; } catch (_) { continue; }
                        const childPath = `${item.path}.${key}`;
                        if (pattern.test(key)) {
                            matches.push({
                                path: childPath,
                                value: typeof child === 'string' ? child.slice(0, 500) : String(child).slice(0, 500),
                            });
                        }
                        if (typeof child === 'string') {
                            if (pattern.test(child)) matches.push({ path: childPath, value: child.slice(0, 500) });
                        } else if (child && typeof child === 'object') {
                            stack.push({ value: child, path: childPath, depth: item.depth + 1 });
                        }
                    }
                }
                return { visited, matches };
            }"""
        )
        metadata = await page.evaluate(
            """async (url) => {
                const response = await fetch(url, { credentials: 'include' });
                return { status: response.status, text: await response.text() };
            }""",
            service_url,
        )
        Path(args.output).write_text(metadata["text"], encoding="utf-8")
        Path(args.output + ".network.json").write_text(
            json.dumps(network_requests, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        Path(args.output + ".responses.json").write_text(
            json.dumps(network_responses, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        Path(args.output + ".frames.json").write_text(
            json.dumps(frame_info, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        Path(args.output + ".dom-fields.json").write_text(
            json.dumps(dom_fields, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        Path(args.output + ".global-matches.json").write_text(
            json.dumps(global_matches, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(
            json.dumps(
                {
                    "pageUrl": page.url,
                    "title": await page.title(),
                    "metadataStatus": metadata["status"],
                    "metadataLength": len(metadata["text"]),
                    "networkRequestCount": len(network_requests),
                    "invoiceFilterCount": invoice_filter_count,
                    "orgCount": org_count,
                },
                ensure_ascii=False,
            )
        )
        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())
