from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree


MAIN_NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"


def cell_column(reference: str) -> str:
    match = re.match(r"([A-Z]+)", reference.upper())
    return match.group(1) if match else ""


def shared_strings(archive: zipfile.ZipFile) -> list[str]:
    try:
        root = ElementTree.fromstring(archive.read("xl/sharedStrings.xml"))
    except KeyError:
        return []
    return [
        "".join(node.text or "" for node in item.iter(f"{{{MAIN_NS}}}t"))
        for item in root.findall(f"{{{MAIN_NS}}}si")
    ]


def first_worksheet_path(archive: zipfile.ZipFile) -> str:
    workbook = ElementTree.fromstring(archive.read("xl/workbook.xml"))
    sheet = workbook.find(f".//{{{MAIN_NS}}}sheet")
    if sheet is None:
        raise RuntimeError("Excel 文件中没有工作表。")
    relationship_id = sheet.attrib.get(f"{{{REL_NS}}}id", "")
    relationships = ElementTree.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
    for relationship in relationships.findall(f"{{{PACKAGE_REL_NS}}}Relationship"):
        if relationship.attrib.get("Id") != relationship_id:
            continue
        target = relationship.attrib.get("Target", "")
        return target.lstrip("/") if target.startswith("/") else f"xl/{target}"
    raise RuntimeError("无法读取 Excel 第一张工作表。")


def cell_text(cell: ElementTree.Element, strings: list[str]) -> str:
    data_type = cell.attrib.get("t", "")
    if data_type == "inlineStr":
        return "".join(node.text or "" for node in cell.iter(f"{{{MAIN_NS}}}t")).strip()
    value = cell.find(f"{{{MAIN_NS}}}v")
    if value is None or value.text is None:
        return ""
    text = value.text.strip()
    if data_type == "s":
        index = int(text)
        return strings[index].strip() if 0 <= index < len(strings) else ""
    return text


def extract_invoice_numbers(workbook_path: Path) -> tuple[list[str], int]:
    with zipfile.ZipFile(workbook_path) as archive:
        strings = shared_strings(archive)
        worksheet = ElementTree.fromstring(archive.read(first_worksheet_path(archive)))
        rows = worksheet.findall(f".//{{{MAIN_NS}}}row")
        if not rows:
            raise RuntimeError("Excel 第一张工作表没有内容。")

        header_column = ""
        for cell in rows[0].findall(f"{{{MAIN_NS}}}c"):
            if cell_text(cell, strings).strip() == "发票号":
                header_column = cell_column(cell.attrib.get("r", ""))
                break
        if not header_column:
            raise RuntimeError("所选模板第1行缺少“发票号”表头。")

        values: list[str] = []
        filled_count = 0
        seen: set[str] = set()
        for row in rows[1:]:
            current = ""
            for cell in row.findall(f"{{{MAIN_NS}}}c"):
                if cell_column(cell.attrib.get("r", "")) == header_column:
                    current = cell_text(cell, strings).strip()
                    break
            if not current:
                continue
            filled_count += 1
            normalized = re.sub(r"\.0$", "", current)
            if normalized not in seen:
                seen.add(normalized)
                values.append(normalized)
        if not values:
            raise RuntimeError("所选模板中没有填写发票号。")
        return values, filled_count


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    values, filled_count = extract_invoice_numbers(Path(args.input))
    payload = {"InvoiceNumbers": values, "FilledRowCount": filled_count}
    Path(args.output).write_text(
        json.dumps(payload, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps({"count": len(values), "filled": filled_count}, ensure_ascii=False))


if __name__ == "__main__":
    main()
