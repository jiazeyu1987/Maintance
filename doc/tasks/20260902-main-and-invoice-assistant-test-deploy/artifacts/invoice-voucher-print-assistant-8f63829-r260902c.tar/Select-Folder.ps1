﻿[CmdletBinding()]
param(
    [string]$InitialPath = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$owner = New-Object System.Windows.Forms.Form
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
try {
    $owner.ShowInTaskbar = $false
    $owner.TopMost = $true
    $owner.WindowState = [System.Windows.Forms.FormWindowState]::Minimized
    $owner.Opacity = 0
    $owner.Show()

    $dialog.Description = '请选择需要处理的 PDF 文件夹'
    $dialog.ShowNewFolderButton = $false
    if (-not [string]::IsNullOrWhiteSpace($InitialPath) -and
        (Test-Path -LiteralPath $InitialPath -PathType Container)) {
        $dialog.SelectedPath = [System.IO.Path]::GetFullPath($InitialPath)
    }

    $result = $dialog.ShowDialog($owner)
    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        Write-Output $dialog.SelectedPath
        exit 0
    }
    exit 2
}
finally {
    $dialog.Dispose()
    $owner.Close()
    $owner.Dispose()
}
