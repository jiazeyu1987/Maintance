# ERP 发票与凭证打印助手

根据发票号查询金蝶云星空 ERP 应收单及对应凭证号，并生成“凭证在前、发票在后”的 PDF 打印包。

## 主要功能

- 在线填写一个或多个发票号
- 从 ERP 应收单列表匹配凭证号
- 选择包含原始发票 PDF 的文件夹
- 自动生成 ERP 记账凭证 PDF
- 按凭证归组，合并凭证与对应发票
- A5 打印版式及发票横竖方向自动适配
- 单条失败不影响其他成功记录继续生成

## 本地运行

1. 安装 Node.js、Python 3.12、PowerShell 7 和 Chromium/Chrome。
2. 安装 Python 依赖：

   ```powershell
   pip install -r requirements.txt
   playwright install chromium
   ```

3. 复制 `.env.example` 为 `.env`，填写 ERP 接口配置。
4. 启动程序：

   ```powershell
   node server.js
   ```

5. 浏览器访问 `http://127.0.0.1:18733/`。

## 容器运行

测试或服务器环境可使用项目内 `Dockerfile` 构建镜像。容器内已安装 Node.js、Python 虚拟环境、Playwright Chromium 和 PowerShell 7；服务默认监听 `0.0.0.0:18733`。

```bash
docker build -t erp-invoice-voucher-print-assistant:<tag> .
docker run --rm --network host \
  -e INVOICE_VOUCHER_PRINT_TICKET_VALIDATE_URL=http://127.0.0.1:48081/admin-api/system/auth/invoice-voucher-print-ticket/validate \
  -v /opt/intruoyi/runtime/erp-invoice-voucher-print-assistant/runtime:/opt/invoice-voucher-print-assistant/runtime \
  -v /opt/intruoyi/runtime/erp-invoice-voucher-print-assistant/results:/opt/invoice-voucher-print-assistant/浏览器运行结果 \
  -v /opt/intruoyi/runtime/erp-invoice-voucher-print-assistant/uploads:/opt/invoice-voucher-print-assistant/服务器上传发票 \
  erp-invoice-voucher-print-assistant:<tag>
```

如需执行完整 ERP 查询和打印包生成，必须从 IntRuoyi 的“发票凭证打印”入口进入。IntRuoyi 后端会在短期票据校验成功后把当前生效 Kingdee 配置快照发给助手，助手再生成会话专用 `runtime/<session>.env.kingdee` 文件供查询、凭证生成和上传脚本使用。服务器不要再配置或依赖全局 `runtime/.env.kingdee` / `KINGDEE_ENV_PATH`。

如果测试服务器仍提示 `ERP配置文件不存在：/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`，说明运行中的助手包仍是旧版本，或容器/Node 进程没有重启到新版；新版请求脚本时路径应为 `runtime/<session>.env.kingdee`，不是固定 `.env.kingdee`。

## 安全说明

ERP 密码、应用密钥、运行结果和本地依赖不会提交到 Git 仓库。正式环境的 Kingdee 连接信息由 IntRuoyi 当前生效配置统一管理，助手只保存短期会话配置文件。

