# Task: 销售组织名称改为上海瑛泰

## Goal
将界面中销售组织名称里的“上海璞泰”改为“上海瑛泰”，并确认旧名称不再作为用户可见选项出现。

## Milestones
1. 定位现有销售组织名称来源。- completed
2. 添加名称替换的静态回归校验。- completed
3. 更新前端展示文案。- completed
4. 运行验证并完成收尾。- completed

## Expected Verification
- 静态校验先在旧文案下失败。
- 更新后静态校验通过。
- 项目页面仍可返回 HTTP 200。

## Current Status
completed
