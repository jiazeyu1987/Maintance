# 验证报告：打通 ERP 配置到发票打印模块

## 当前结果

- 助手侧代码验证通过；ERP 配置传递链路已打通到会话专用配置文件。测试服仍出现固定 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`，判定为远端助手包或运行进程未刷新到新版。

## 命令记录

- `node --check server.js` -> PASS。
- `node tests\assistant-auth-static.cjs` -> PASS。
- `node tests\container-deploy-static.cjs` -> PASS。
- `node tests\kingdee-env-missing-regression.cjs` -> PASS。
- `node script\tests\invoice-voucher-print-kingdee-config-bridge-static.test.mjs`（workdir=`E:\IntRuoyi\IntRuoyiBackend`）-> PASS。
- `mvn.cmd -pl yudao-module-system "-Dtest=InvoiceVoucherPrintAssistantErpConfigBridgeContractTest,AuthControllerTest" test` -> PASS，20 tests。
- `mvn.cmd -pl yudao-module-erp -am "-Dtest=ErpInvoiceVoucherPrintKingdeeConfigProviderTest,ErpKingdeeConfigServiceImplTest" "-Dsurefire.failIfNoSpecifiedTests=false" test` -> PASS，20 tests。

## 阻塞项

- 测试服必须重新部署新版助手包并重启助手进程/容器。
- 测试服 IntRuoyi 后端必须部署包含 `kingdeeConfig` 票据响应字段的新版 Jar。
- 测试服当前生效 ERP 配置必须完整包含 `baseUrl/acctId/username/password/appId/appSecret/lcid`。
