# Bug Regression Evidence: 测试服助手仍使用旧全局 ERP 配置路径

## Bug Summary

测试服务器运行发票凭证打印助手时，`Query-ErpInvoiceVoucherMappings.ps1` 收到固定旧路径 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`，导致提示 `ERP配置文件不存在`。新版正式行为应从 IntRuoyi 入口进入，短期票据校验成功后由助手生成会话专用 `runtime/<session>.env.kingdee` 文件，并把该文件路径传给 ERP 查询、凭证生成和上传脚本。

## Expected Behavior

- 助手不依赖全局 `.env.kingdee` 或 `KINGDEE_ENV_PATH`。
- ERP 查询、凭证生成和上传只使用当前授权会话的配置文件。
- 会话配置缺失时在助手服务层 fail fast，提示重新从 ERP 入口进入，不把旧全局路径当作正常路径。

## Reproduction Command Or Path

- 用户复现场景：测试服务器点击“一键查询”后，页面显示 PowerShell 异常，报错路径为 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`。
- 本地合同复现：`node tests\assistant-auth-static.cjs` 在新增会话配置预检断言前不能证明业务调用已经统一经过 `requireAssistantKingdeeEnvPath`。

## Root Cause

测试服务器正在运行的助手包或进程仍按旧契约把固定全局 `.env.kingdee` 传给 PowerShell 查询脚本；当前源码正式链路已经改为 `assistantSession -> kingdeeEnvPath -> runtime/<session>.env.kingdee`，因此固定 `.env.kingdee` 出现在测试服日志时，说明测试服未加载新版助手包，或旧 Node/容器进程未重启。

## Regression Test

- `tests\assistant-auth-static.cjs`：增加 `requireAssistantKingdeeEnvPath`、`-EnvPath/--env kingdeeEnvPath`、禁止 `runtime/.env.kingdee` 的合同。
- `tests\container-deploy-static.cjs`：增加 README 部署说明合同，明确不再配置全局 `.env.kingdee` / `KINGDEE_ENV_PATH`。

## RED

RED:

- `node tests\assistant-auth-static.cjs` -> FAIL，旧断言只检查 `assistantSession.kingdeeEnvPath` 直接引用，未覆盖服务层会话配置文件预检和旧路径禁用。

## GREEN

GREEN:

- `node --check server.js` -> PASS。
- `node tests\assistant-auth-static.cjs` -> PASS。
- `node tests\container-deploy-static.cjs` -> PASS。
- `node tests\kingdee-env-missing-regression.cjs` -> PASS。
- `node script\tests\invoice-voucher-print-kingdee-config-bridge-static.test.mjs` -> PASS。
- `mvn.cmd -pl yudao-module-system "-Dtest=InvoiceVoucherPrintAssistantErpConfigBridgeContractTest,AuthControllerTest" test` -> PASS，20 tests。
- `mvn.cmd -pl yudao-module-erp -am "-Dtest=ErpInvoiceVoucherPrintKingdeeConfigProviderTest,ErpKingdeeConfigServiceImplTest" "-Dsurefire.failIfNoSpecifiedTests=false" test` -> PASS，20 tests。

## Verification

Verification covered assistant syntax, assistant static auth/session contract, container deployment contract, missing env regression, IntRuoyi backend bridge static contract, system ticket validation tests, and ERP config provider tests.

## Risk And Regression Scope

风险集中在发票凭证打印助手的授权会话、ERP 查询、凭证数据生成和 ERP 上传脚本调用。此次修复没有增加 fallback，不改变 ERP 查询字段、登录方式或上传业务逻辑。

## Blockers And Follow-Up Actions

- 测试服务器必须重新部署新版助手包并重启助手进程/容器；否则仍会运行旧代码。
- 测试服务器 IntRuoyi 后端也必须部署包含 `kingdeeConfig` 票据响应字段的新版 Jar。
- 当前 ERP 生效配置必须完整包含 `baseUrl/acctId/username/password/appId/appSecret/lcid`；缺少任一必需字段时会 fail fast。
