# 执行日志：打通 ERP 配置到发票打印模块

- 用户意图：修复当前 ERP 配置信息未能传给发票打印模块使用的问题，并确认本机是否可验证。
- BDD: 当前会话 ERP 配置传递 -> Given 已通过入口提供 Kingdee 配置 When 发票打印模块执行一键查询 Then 查询脚本收到的是当前会话生成的 ERP 配置文件路径。
- BDD: 缺少 ERP 配置时失败透明 -> Given 当前会话没有有效 Kingdee 配置 When 发票打印模块执行查询 Then 系统应明确失败并提示缺少正式配置，不使用默认成功或 mock 数据。

## 进度

- in_progress: 正在核对配置链路和现有改动。
- RED: 复用 IntRuoyi 主任务 `doc/tasks/20260831-invoice-voucher-print-erp-config-bridge/` 记录，修复前票据校验响应缺少 `KingdeeConfig`，助手会话未保存 `kingdeeConfig`。
- GREEN: `node --check server.js` -> PASS。
- GREEN: `node tests\assistant-auth-static.cjs` -> PASS，授权会话和会话级 Kingdee 配置静态合同通过。
- GREEN: `node tests\container-deploy-static.cjs` -> PASS，容器只保留 `KINGDEE_RUNTIME_DIR`，不再依赖 `KINGDEE_ENV_PATH`。
- GREEN: `node tests\kingdee-env-missing-regression.cjs` -> PASS，缺全局 `.env.kingdee` 时不再泄露 Python traceback。
- VERIFY: IntRuoyi 本机基础 ERP 登录环境已通过脱敏 `ValidateUser` 探针；当前运行库仍缺发票助手 881 查询路径需要的 `appId/appSecret`。
- BLOCKED: 完整本机点击验证等待 IntRuoyi 运行库补齐 `appId/appSecret`，并刷新 `48081` 后端运行 Jar。
- BDD: 测试服不得走旧全局路径 -> Given 用户从 IntRuoyi 发票凭证打印入口进入测试服务器助手 When 点击一键查询 Then 查询脚本收到会话专用 `runtime/<session>.env.kingdee`，不得收到固定 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`。
- RED: `node tests\assistant-auth-static.cjs` -> FAIL，旧合同不能证明 ERP 调用统一经过服务层会话配置文件预检，也未禁止固定 `runtime/.env.kingdee` 路径。
- GREEN: `node --check server.js` -> PASS。
- GREEN: `node tests\assistant-auth-static.cjs` -> PASS，助手业务调用已统一使用 `requireAssistantKingdeeEnvPath` 预检后的 `kingdeeEnvPath`。
- GREEN: `node tests\container-deploy-static.cjs` -> PASS，容器和 README 均明确不再依赖全局 `.env.kingdee` / `KINGDEE_ENV_PATH`。
- GREEN: `node tests\kingdee-env-missing-regression.cjs` -> PASS，缺失 env 文件时仍不泄露 Python traceback。
- GREEN: `node script\tests\invoice-voucher-print-kingdee-config-bridge-static.test.mjs`（workdir=`E:\IntRuoyi\IntRuoyiBackend`）-> PASS，IntRuoyi 后端桥接静态合同通过。
- GREEN: `mvn.cmd -pl yudao-module-system "-Dtest=InvoiceVoucherPrintAssistantErpConfigBridgeContractTest,AuthControllerTest" test` -> PASS，20 tests。
- GREEN: `mvn.cmd -pl yudao-module-erp -am "-Dtest=ErpInvoiceVoucherPrintKingdeeConfigProviderTest,ErpKingdeeConfigServiceImplTest" "-Dsurefire.failIfNoSpecifiedTests=false" test` -> PASS，20 tests。
- DIAGNOSIS: 测试服报错路径仍是 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`，与当前源码 `runtime/<session>.env.kingdee` 契约不一致，判定为远端助手包或运行进程未刷新到新版。
