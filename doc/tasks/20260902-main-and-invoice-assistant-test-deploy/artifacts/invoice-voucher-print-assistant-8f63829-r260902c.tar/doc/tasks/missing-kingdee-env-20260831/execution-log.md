# Execution Log

- BDD: 缺少 ERP 配置文件 -> Given 测试服务器未提供 Kingdee 配置文件, When 用户点击“一键查询并生成打印包”, Then 后端失败并返回明确的配置文件缺失提示且不暴露 Python traceback
- RED: `node tests\kingdee-env-missing-regression.cjs` -> FAIL, Python stderr 暴露 FileNotFoundError traceback
- GREEN: `node tests\kingdee-env-missing-regression.cjs` -> PASS
- GREEN: `Get-ChildItem tests\*.cjs | Sort-Object Name | ForEach-Object { node $_.FullName }` -> PASS
- GREEN: `task_closeout.py --task-id missing-kingdee-env-20260831 --mode preview` -> PASS, keep includes bug-regression-evidence.md
- GREEN: `task_closeout.py --task-id missing-kingdee-env-20260831 --mode apply` -> PASS, deleted_paths=<none>
- GREEN: `validate_bug_regression.py --evidence doc/tasks/missing-kingdee-env-20260831/bug-regression-evidence.md` -> PASS
- GREEN: `validate_bug_regression.py --self-test` -> PASS
