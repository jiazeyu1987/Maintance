# Bug Regression Evidence

## Bug Summary
测试服务器点击“一键查询”时，`Query-ErpInvoiceVoucherMappings-List.py` 直接读取缺失的 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`，导致 Python traceback 暴露到页面。

## Expected Behavior
缺少 ERP 配置文件属于部署前提缺失，应失败并明确提示配置文件路径，不输出 Python traceback。

## Reproduction
Run:
`node tests\kingdee-env-missing-regression.cjs`

It spawns `Query-ErpInvoiceVoucherMappings-List.py` with `--env` pointing at a missing temp `.env.kingdee` file.

## Root Cause
`Query-ErpInvoiceVoucherMappings-List.py` called `Path(path).read_text(...)` directly in `read_env()` without checking whether the configured Kingdee env file existed. When the Docker runtime did not mount `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee`, Python raised `FileNotFoundError` and printed a full traceback.

## Verification
Regression test:
`tests/kingdee-env-missing-regression.cjs`

## RED:
`node tests\kingdee-env-missing-regression.cjs` -> FAIL, stderr contained a Python traceback with `FileNotFoundError`

## GREEN:
`node tests\kingdee-env-missing-regression.cjs` -> PASS, stderr contains `ERP配置文件不存在：...` and no traceback

## Risk And Scope
Scope is limited to the Kingdee env-file validation path used by the ERP mapping query script. Existing container and auth behavior are unchanged.

## Blockers And Follow-Up
No blocker. Deployment still needs the Kingdee env file mounted for the feature to function, but the failure is now explicit and user-facing.
