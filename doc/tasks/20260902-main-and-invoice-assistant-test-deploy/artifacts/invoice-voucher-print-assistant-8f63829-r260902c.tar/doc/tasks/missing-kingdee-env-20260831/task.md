# Task: 测试服务器缺少 ERP 配置时报错优化

## Goal
修复测试服务器点击“一键查询”时因缺少 `/opt/invoice-voucher-print-assistant/runtime/.env.kingdee` 导致页面显示 Python traceback 的问题，改为明确提示缺少 ERP 配置文件。

## Milestones
1. 复现缺少 ERP 配置文件时的报错。- completed
2. 添加回归测试覆盖缺失配置文件。- completed
3. 实现最小修复，保留失败快路径。- completed
4. 运行目标与相关静态验证。- completed
5. 记录证据并完成收尾。- completed

## Expected Verification
- 缺少 ERP 配置文件时，脚本退出非零并输出明确的“ERP配置文件不存在”错误，不输出 Python traceback。
- 现有静态测试继续通过。

## Current Status
completed

## Cleanup Keep
- doc/tasks/missing-kingdee-env-20260831/bug-regression-evidence.md
