﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$TemplatePath,
    [Parameter(Mandatory = $true)][string]$InputWorkbookPath,
    [Parameter(Mandatory = $true)][string]$WorkingWorkbookPath,
    [Parameter(Mandatory = $true)][string]$ResultWorkbookPath,
    [Parameter(Mandatory = $true)][string]$BusinessMonth,
    [Parameter(Mandatory = $true)][string]$OrganizationNumber,
    [Parameter(Mandatory = $true)][string]$AccountBookNumber,
    [Parameter(Mandatory = $true)][string]$VoucherGroupNumber,
    [Parameter(Mandatory = $true)][string]$SalesOrganization,
    [Parameter(Mandatory = $true)][string]$PdfDirectory,
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [string]$SummaryJsonPath,
    [switch]$Apply,
    [switch]$GenerateFolder,
    [string]$GeneratedFolderPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Apply -and $GenerateFolder) {
    throw '-Apply 与 -GenerateFolder 不能同时使用。'
}
if ($GenerateFolder -and [string]::IsNullOrWhiteSpace($GeneratedFolderPath)) {
    throw '生成命名后文件夹时必须提供 GeneratedFolderPath。'
}

$toolRoot = Split-Path -Parent $PSScriptRoot
$renameScript = Join-Path $toolRoot 'Invoke-InvoiceVoucherRename.ps1'
$queryScript = Join-Path $PSScriptRoot 'Query-ErpInvoiceVoucherMappings.ps1'
$jobDirectory = Split-Path -Parent $ResultWorkbookPath
$invoiceNumbersJsonPath = Join-Path $jobDirectory '待查询发票号.json'
$erpMappingJsonPath = Join-Path $jobDirectory 'ERP直接查询结果.json'
Copy-Item -LiteralPath $TemplatePath -Destination $WorkingWorkbookPath -Force

function New-WpsSpreadsheetApplication {
    try {
        return New-Object -ComObject 'ket.Application'
    }
    catch {
        throw '无法启动 WPS 表格，请确认 WPS Office 已安装并可正常打开表格。'
    }
}

$excel = $null
$inputWorkbook = $null
$workbook = $null
$inputSheet = $null
$usedRange = $null
$configSheet = $null
$invoiceSheet = $null
$resultTable = $null
$resultTableRange = $null
$inputDataRange = $null
$invoiceDestinationRange = $null
try {
    $excel = New-WpsSpreadsheetApplication
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.ScreenUpdating = $false

    $inputWorkbook = $excel.Workbooks.Open($InputWorkbookPath, 0, $true)
    $inputSheet = $inputWorkbook.Worksheets.Item(1)
    $usedRange = $inputSheet.UsedRange
    $headerColumn = 0
    $maximumHeaderColumn = [math]::Min(20, $usedRange.Columns.Count)
    for ($column = 1; $column -le $maximumHeaderColumn; $column++) {
        if (([string]$inputSheet.Cells(1, $column).Text).Trim() -eq '发票号') {
            $headerColumn = $column
            break
        }
    }
    if ($headerColumn -eq 0) {
        throw '所选模板第1行缺少“发票号”表头。'
    }

    $lastInputRow = $inputSheet.Cells($inputSheet.Rows.Count, $headerColumn).End(-4162).Row
    $invoiceNumbers = [System.Collections.Generic.List[object]]::new()
    $seenInvoiceNumbers = [System.Collections.Generic.HashSet[string]]::new(
        [System.StringComparer]::OrdinalIgnoreCase
    )
    $filledInvoiceRowCount = 0
    $inputDataRange = $inputSheet.Range(
        $inputSheet.Cells(2, $headerColumn),
        $inputSheet.Cells($lastInputRow, $headerColumn)
    )
    $inputValues = $inputDataRange.Value2
    $inputValueCount = $inputDataRange.Rows.Count
    for ($index = 1; $index -le $inputValueCount; $index++) {
        $value = if ($inputValueCount -eq 1) {
            $inputValues
        }
        else {
            $inputValues[$index, 1]
        }
        if ($null -ne $value -and -not [string]::IsNullOrWhiteSpace([string]$value)) {
            $filledInvoiceRowCount++
            $deduplicationKey = ([string]$value).Trim()
            if ($seenInvoiceNumbers.Add($deduplicationKey)) {
                $invoiceNumbers.Add($value)
            }
        }
    }
    if ($invoiceNumbers.Count -eq 0) {
        throw '所选模板中没有填写发票号。'
    }
    $inputWorkbook.Close($false)
    $inputWorkbook = $null

    $workbook = $excel.Workbooks.Open($WorkingWorkbookPath, 0, $false)
    $configSheet = $workbook.Worksheets.Item('配置')
    $invoiceSheet = $workbook.Worksheets.Item('发票清单')

    $configSheet.Range('B5:B10').NumberFormat = '@'
    $configSheet.Range('B5').Value2 = $BusinessMonth
    $configSheet.Range('B6').Value2 = $OrganizationNumber
    $configSheet.Range('B7').Value2 = $SalesOrganization
    $configSheet.Range('B8').Value2 = $erpMappingJsonPath
    $configSheet.Range('B9').Value2 = $PdfDirectory
    $configSheet.Range('B10').Value2 = if ($Apply) {
        '执行改名'
    }
    elseif ($GenerateFolder) {
        '生成命名后文件夹'
    }
    else {
        '仅预览'
    }

    $invoiceSheet.Range('A5:K504').ClearContents()
    $lastResultRow = 4 + $invoiceNumbers.Count
    if ($invoiceSheet.ListObjects.Count -gt 0 -and $lastResultRow -gt 504) {
        $resultTable = $invoiceSheet.ListObjects.Item(1)
        $resultTableRange = $invoiceSheet.Range("A4:K${lastResultRow}")
        $resultTable.Resize($resultTableRange)
    }
    $invoiceDestinationRange = $invoiceSheet.Range("A5:A${lastResultRow}")
    $invoiceDestinationRange.NumberFormat = '@'
    for ($index = 0; $index -lt $invoiceNumbers.Count; $index++) {
        $invoiceSheet.Cells(5 + $index, 1).Value2 = [string]$invoiceNumbers[$index]
    }

    $workbook.Save()
}
finally {
    if ($null -ne $workbook) {
        try { $workbook.Close($true) } catch {}
    }
    if ($null -ne $inputWorkbook) {
        try { $inputWorkbook.Close($false) } catch {}
    }
    if ($null -ne $excel) {
        try { $excel.Quit() } catch {}
    }
    foreach ($comObject in @($invoiceDestinationRange, $inputDataRange, $resultTableRange, $resultTable, $invoiceSheet, $configSheet, $usedRange, $inputSheet, $workbook, $inputWorkbook, $excel)) {
        if ($null -ne $comObject -and [Runtime.InteropServices.Marshal]::IsComObject($comObject)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($comObject) } catch {}
        }
    }
    [gc]::Collect()
    [gc]::WaitForPendingFinalizers()
}

[System.IO.File]::WriteAllText(
    $invoiceNumbersJsonPath,
    (@($invoiceNumbers | ForEach-Object { [string]$_ }) | ConvertTo-Json),
    [System.Text.UTF8Encoding]::new($false)
)
$queryArguments = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', $queryScript,
    '-BusinessMonth', $BusinessMonth,
    '-OrganizationNumber', $OrganizationNumber,
    '-AccountBookNumber', $AccountBookNumber,
    '-VoucherGroupNumber', $VoucherGroupNumber,
    '-InvoiceNumbersPath', $invoiceNumbersJsonPath,
    '-OutputJsonPath', $erpMappingJsonPath,
    '-EnvPath', $EnvPath
)
& powershell.exe @queryArguments | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "ERP直接查询失败，退出代码：$LASTEXITCODE"
}

$processArguments = @(
    '-NoProfile',
    '-ExecutionPolicy', 'Bypass',
    '-File', $renameScript,
    '-TemplatePath', $WorkingWorkbookPath,
    '-OutputPath', $ResultWorkbookPath
)
if (-not [string]::IsNullOrWhiteSpace($SummaryJsonPath)) {
    $processArguments += '-SummaryJsonPath'
    $processArguments += $SummaryJsonPath
}
if ($Apply) {
    $processArguments += '-Apply'
}
if ($GenerateFolder) {
    $processArguments += '-GenerateFolder'
    $processArguments += '-GeneratedFolderPath'
    $processArguments += $GeneratedFolderPath
}

Write-Output (
    '模板读取：{0} 行发票号；自动去重后：{1} 个唯一发票号。' -f
    $filledInvoiceRowCount,
    $invoiceNumbers.Count
)
& powershell.exe @processArguments
if ($LASTEXITCODE -ne 0) {
    throw "匹配程序运行失败，退出代码：$LASTEXITCODE"
}
