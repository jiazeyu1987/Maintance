[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$settings = @{}
foreach ($line in Get-Content -LiteralPath $EnvPath -Encoding UTF8) {
    if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') {
        $settings[$Matches[1]] = $Matches[2].Trim()
    }
}
$root = ([string]$settings.KINGDEE_BASE_URL).TrimEnd('/')
if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) { $root += '/K3Cloud' }
$root += '/'
$login = Invoke-WebRequest -UseBasicParsing -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.AuthService.ValidateUser.common.kdsvc') `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{ acctID=$settings.KINGDEE_ACCT_ID; username=$settings.KINGDEE_USERNAME; password=$settings.KINGDEE_PASSWORD; lcid='2052' } `
    -SessionVariable session -TimeoutSec 30
$loginBody = $login.Content | ConvertFrom-Json
$headers = @{}
if ($loginBody.Context.SessionId) { $headers.SessionId = [string]$loginBody.Context.SessionId }
if ($loginBody.KDSVCSessionId) { $headers.KDSVCSessionId = [string]$loginBody.KDSVCSessionId }
Invoke-WebRequest -UseBasicParsing -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.SwitchOrg.common.kdsvc') `
    -ContentType 'application/x-www-form-urlencoded;charset=UTF-8' `
    -Body @{ data='{"OrgNumber":"881"}' } -WebSession $session -Headers $headers -TimeoutSec 30 | Out-Null
$request = @{ CreateOrgId=0; Number='BizVch100029'; Id=''; IsSortBySeq=$false } | ConvertTo-Json -Compress
$body = @{ formid='BAS_BizVoucherLink'; data = $request } | ConvertTo-Json -Compress
$result = Invoke-RestMethod -Method Post `
    -Uri ($root + 'Kingdee.BOS.WebApi.ServicesStub.DynamicFormService.View.common.kdsvc') `
    -ContentType 'application/json;charset=UTF-8' -Body $body `
    -WebSession $session -Headers $headers -TimeoutSec 60
$result | ConvertTo-Json -Depth 100 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
