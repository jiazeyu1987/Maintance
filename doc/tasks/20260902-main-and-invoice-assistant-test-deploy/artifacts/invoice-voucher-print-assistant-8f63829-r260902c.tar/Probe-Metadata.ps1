[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$EnvPath,
    [Parameter(Mandatory = $true)][string]$FormId,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$settings = @{}
foreach ($line in Get-Content -LiteralPath $EnvPath -Encoding UTF8) {
    if ($line -match '^\s*([^#][A-Za-z0-9_]*)=(.*)$') {
        $settings[$Matches[1]] = $Matches[2].Trim()
    }
}
$root = ([string]$settings.KINGDEE_BASE_URL).TrimEnd('/')
if (-not $root.EndsWith('/K3Cloud', [System.StringComparison]::OrdinalIgnoreCase)) {
    $root += '/K3Cloud'
}
$root += '/'
$dbid = [string]$settings.KINGDEE_ACCT_ID
$lang = if ($settings.KINGDEE_LCID) { [string]$settings.KINGDEE_LCID } else { '2052' }
$username = [string]$settings.KINGDEE_USERNAME
$appId = [string]$settings.KINGDEE_APP_ID
$signedData = [string]$settings.KINGDEE_SIGNED_DATA
$timestamp = [string]$settings.KINGDEE_TIMESTAMP
if ([string]::IsNullOrWhiteSpace($appId) -or [string]::IsNullOrWhiteSpace($signedData) -or
    [string]::IsNullOrWhiteSpace($timestamp)) {
    throw 'ERP SSO settings are missing.'
}
$loginArg = [ordered]@{
    dbid = $dbid
    username = $username
    appid = $appId
    signeddata = $signedData
    timestamp = $timestamp
    lcid = $lang
    origintype = 'SimPas'
    entryrole = ''
    formid = ''
    formtype = ''
    pkid = ''
    otherargs = ''
    openmode = $null
    loginthen = ''
}
$loginJson = $loginArg | ConvertTo-Json -Compress
$loginBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($loginJson))
$loginUrl = $root + 'html5/index.aspx?ud=' + [uri]::EscapeDataString($loginBase64)
$login = Invoke-WebRequest -UseBasicParsing -Method Get -Uri $loginUrl `
    -SessionVariable session -MaximumRedirection 10 -TimeoutSec 60
if ($login.Content -match '登录失败|签名.*错误|参数.*错误') {
    throw 'ERP SSO login failed.'
}
$url = $root + 'Service.aspx?servicename=FormMetaDataService&methodname=GetListMetadata&pageid=' + `
    [uri]::EscapeDataString($FormId) + '&paramtype=url&paramdata=%5B%5D&dbid=' + `
    [uri]::EscapeDataString($dbid) + '&lang=' + [uri]::EscapeDataString($lang)
$response = Invoke-WebRequest -UseBasicParsing -Method Get -Uri $url -WebSession $session -TimeoutSec 60
$response.Content | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Output $response.StatusCode
