import asyncio
import json
import os
from pathlib import Path
from playwright.async_api import async_playwright


def read_env(path):
    result = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.strip() and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            result[key.strip()] = value.strip()
    return result


async def main():
    env = read_env(os.environ["ERP_ENV_PATH"])
    base = env["KINGDEE_BASE_URL"].rstrip("/")
    if not base.lower().endswith("/k3cloud"):
        base += "/K3Cloud"
    async with async_playwright() as pw:
        exe = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
        browser = await pw.chromium.launch(headless=True, executable_path=exe)
        page = await browser.new_page(viewport={"width": 1440, "height": 900})
        await page.goto(base + "/html5/index.aspx", wait_until="domcontentloaded", timeout=60000)
        await page.wait_for_timeout(8000)
        fields = await page.evaluate("""() => Array.from(document.querySelectorAll('input,button,a,select')).map(el => ({tag:el.tagName,id:el.id,name:el.name,type:el.type,placeholder:el.placeholder,value:el.value,text:(el.innerText||el.textContent||'').trim(),cls:String(el.className||'')})).filter(x=>x.id||x.name||x.placeholder||x.text)""")
        Path(os.environ["ERP_NORMAL_LOGIN_OUTPUT"] + ".json").write_text(json.dumps(fields, ensure_ascii=False, indent=2), encoding="utf-8")
        await page.screenshot(path=os.environ["ERP_NORMAL_LOGIN_OUTPUT"] + ".png", full_page=True)
        await page.locator("#datacenter").evaluate(
            """el => { const option = Array.from(el.options).find(o => o.textContent.includes('20260728')); if (!option) throw new Error('datacenter not found'); el.value = option.value; el.dispatchEvent(new Event('change', {bubbles:true})); }"""
        )
        await page.fill("#user", env["KINGDEE_USERNAME"])
        await page.fill("#password", env["KINGDEE_PASSWORD"])
        await page.click("#btnLogin")
        await page.wait_for_timeout(20000)
        await page.screenshot(path=os.environ["ERP_NORMAL_LOGIN_OUTPUT"] + ".after.png", full_page=True)
        Path(os.environ["ERP_NORMAL_LOGIN_OUTPUT"] + ".after.txt").write_text(
            (await page.locator("body").inner_text())[:10000], encoding="utf-8"
        )
        print(page.url)
        await browser.close()


asyncio.run(main())
